"""Componente TTS de ElevenLabs (DART_14-1.6, responsabilidad de David).

Responsabilidad de este modulo, dentro del pipeline confirmado
``LiveKit -> Speechmatics (STT) -> LLM -> ElevenLabs (TTS) -> LiveKit``:

- **Entrada:** texto de la respuesta destinada al usuario (completo via
  ``synthesize(text)``, o incremental via ``stream().push_text(...)``
  mientras el LLM genera tokens).
- **Salida:** audio sintetizado como ``livekit.rtc.AudioFrame`` dentro de
  ``SynthesizedAudio``, que es lo que ``AgentSession`` publica en la sala
  LiveKit.
- **No** implementa STT (Speechmatics, a cargo de Juan) ni LLM (DeepSeek, a
  cargo de Fernando), ni transporte WebRTC propio, ni la conversacion E2E.

Integracion oficial utilizada: el plugin ``livekit-plugins-elevenlabs``
(extra ``livekit-agents[elevenlabs]``), clase ``elevenlabs.TTS``. Soporta
streaming (``capabilities.streaming=True``) via WebSocket de ElevenLabs.

La configuracion (credenciales, modelo, voz) vive exclusivamente en
``alloxentric_real_time_agent.config``; este modulo solo construye el
objeto TTS a partir de esa configuracion ya validada. Modelo y voz se pasan
siempre de forma EXPLICITA: nunca se depende del default propio del plugin
("eleven_turbo_v2_5"), que ElevenLabs marca como deprecado (ver
``alloxentric_real_time_agent.config.DEFAULT_ELEVENLABS_TTS_MODEL``).
"""

from __future__ import annotations

import os
from typing import TYPE_CHECKING, Mapping

from livekit.plugins import elevenlabs

from alloxentric_real_time_agent.config import (
    ELEVENLABS_VOICE_ID_VAR,
    load_elevenlabs_settings,
)

if TYPE_CHECKING:
    import aiohttp


def build_elevenlabs_tts(
    env: Mapping[str, str] | None = None,
    *,
    http_session: aiohttp.ClientSession | None = None,
    voice_id: str | None = None,
) -> elevenlabs.TTS:
    """Construye el componente TTS de ElevenLabs listo para una ``AgentSession``.

    El objeto devuelto es una instancia de ``livekit.plugins.elevenlabs.TTS``,
    por lo que es directamente compatible con
    ``AgentSession(tts=build_elevenlabs_tts())``.

    No realiza ninguna llamada de red: la conexion (WebSocket/HTTP) se abre
    recien al sintetizar. ``http_session`` solo es necesario fuera de un job
    de LiveKit (por ejemplo en ``scripts/check_elevenlabs_tts.py``); dentro
    de un job el plugin usa la sesion HTTP del propio framework.

    Errores en tiempo de sintesis (los lanza el plugin, no este modulo):
    ``APIStatusError`` (p. ej. 401 por API key invalida, o voz/modelo
    inexistente), ``APIConnectionError`` y ``APITimeoutError``, todos de
    ``livekit.agents``. ``AgentSession`` los reintenta segun
    ``APIConnectOptions``.

    Voz (DART-14-5.1), de mayor a menor prioridad: ``ELEVEN_VOICE_ID`` explicita
    en el entorno (override del operador), el ``voice_id`` recibido (la voz de la
    persona) y la voz por defecto del proyecto.

    Raises
    ------
    alloxentric_real_time_agent.config.MissingConfigurationError
        Si falta ``ELEVEN_API_KEY`` en el entorno.
    """

    settings = load_elevenlabs_settings(env)
    source = env if env is not None else os.environ
    explicit_voice = bool((source.get(ELEVENLABS_VOICE_ID_VAR) or "").strip())
    chosen_voice = settings.voice_id if explicit_voice else (voice_id or settings.voice_id)
    extra: dict[str, str] = {"language": settings.language} if settings.language else {}
    return elevenlabs.TTS(
        api_key=settings.api_key,
        model=settings.model,
        voice_id=chosen_voice,
        http_session=http_session,
        **extra,
    )
