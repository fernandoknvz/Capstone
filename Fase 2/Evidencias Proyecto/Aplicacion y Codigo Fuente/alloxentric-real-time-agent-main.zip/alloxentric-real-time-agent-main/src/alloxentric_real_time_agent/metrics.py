"""Instrumentacion local de metricas de latencia del pipeline (DART-14-3.1).

Recolector pequeno que se engancha a una ``AgentSession`` con los eventos
oficiales de livekit-agents 1.8.4 y escribe lineas de log estructuradas (JSON)
con nivel INFO en el logger local ``alloxentric_real_time_agent.metrics``.
No guarda archivos, no envia nada fuera del proceso y no activa observabilidad
remota.

Fuentes (verificadas en livekit-agents 1.8.4):

- ``conversation_item_added`` -> ``ChatMessage.metrics`` (``MetricsReport``):
  del mensaje del USUARIO se leen ``transcription_delay`` y
  ``end_of_turn_delay``; del mensaje del AGENTE ``llm_node_ttft``,
  ``tts_node_ttfb``, ``playback_latency`` y ``e2e_latency``.
- ``agent_state_changed``: tiempo de inicializacion.
- ``session_usage_updated``: uso acumulado (tokens, caracteres, segundos de
  audio); el SDK lo emite tras CADA metrica, por eso solo se guarda el ultimo
  valor y se informa una vez, al cerrar.
- ``error`` y ``close``: contadores y resumen final.

NO se usa ``metrics_collected``: esta marcado como obsoleto por el SDK y
suscribirse genera una advertencia.

Privacidad: solo se leen campos numericos. Nunca se registra el contenido de
los mensajes, transcripciones, audio, credenciales, identificadores de
solicitud de los proveedores, identidades de participantes ni nombres de sala.

Los valores ausentes se OMITEN del registro (no se convierten en cero). Los
valores no numericos, no finitos o negativos tambien se tratan como ausentes.
Todos los tiempos estan en segundos (sufijo ``_s``).
"""

from __future__ import annotations

import json
import logging
import math
import re
import time
from typing import Any

from livekit.agents import AgentSession
from livekit.agents.llm import ChatMessage

logger = logging.getLogger("alloxentric_real_time_agent.metrics")

#: Campos de ``MetricsReport`` leidos del mensaje del usuario.
USER_TURN_FIELDS: tuple[str, ...] = ("transcription_delay", "end_of_turn_delay")

#: Campos de ``MetricsReport`` leidos del mensaje del agente.
AGENT_TURN_FIELDS: tuple[str, ...] = (
    "llm_node_ttft",
    "tts_node_ttfb",
    "playback_latency",
    "e2e_latency",
)

#: Campos de uso (``ModelUsage``) que se incluyen en el resumen. Lista blanca:
#: solo contadores numericos y el nombre del proveedor y del modelo.
_USAGE_NUMERIC_FIELDS: tuple[str, ...] = (
    "input_tokens",
    "output_tokens",
    "output_reasoning_tokens",
    "characters_count",
    "audio_duration",
)

_MARKER = "_alloxentric_session_metrics"

#: Tolerancia (s) al comparar marcas de tiempo del SDK entre mensajes.
_TIME_EPS = 0.005
#: Maximo de mensajes de usuario pendientes de emparejar con una respuesta.
_MAX_PENDING_USERS = 8
_SAFE_LABEL = re.compile(r"^[A-Za-z0-9._:/-]{1,64}$")
_UNKNOWN = "desconocido"


def _clean(value: Any) -> float | None:
    """Devuelve el valor como ``float`` si es un tiempo valido; si no, ``None``."""

    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    if not math.isfinite(value) or value < 0:
        return None
    return round(float(value), 4)


def _label(value: Any) -> str:
    """Etiqueta segura (tipo, proveedor, modelo, motivo): estructura acotada o ``desconocido``.

    Rechaza cualquier valor que no sea un identificador corto sin espacios, para
    que un texto inesperado nunca llegue al log.
    """

    text = getattr(value, "value", value)  # enums (p. ej. CloseReason) -> su valor
    if isinstance(text, str) and _SAFE_LABEL.match(text):
        return text
    return _UNKNOWN


def _pick(metrics: Any, fields: tuple[str, ...]) -> dict[str, float]:
    """Extrae de ``metrics`` solo los campos presentes y validos (sufijo ``_s``)."""

    out: dict[str, float] = {}
    if not isinstance(metrics, dict):
        return out
    for name in fields:
        value = _clean(metrics.get(name))
        if value is not None:
            out[f"{name}_s"] = value
    return out


def _usage_summary(usage: Any) -> list[dict[str, Any]]:
    """Resume ``AgentSessionUsage`` con una lista blanca de campos."""

    summary: list[dict[str, Any]] = []
    for item in getattr(usage, "model_usage", None) or []:
        entry: dict[str, Any] = {
            "type": _label(getattr(item, "type", None)),
            "provider": _label(getattr(item, "provider", None)),
            "model": _label(getattr(item, "model", None)),
        }
        for name in _USAGE_NUMERIC_FIELDS:
            value = _clean(getattr(item, name, None))
            if value:  # omite ausentes y ceros: el SDK usa 0 como "sin dato"
                entry[name] = value
        summary.append(entry)
    return summary


def _pairs(stopped: float | None, started: float | None, e2e: float | None) -> bool:
    """Indica si un mensaje de usuario puede ser el origen de una respuesta.

    Sin marcas de tiempo se usa el orden de llegada. Con ellas se exige que el
    usuario haya terminado de hablar antes de que empezara la respuesta y, si el
    SDK informa ``e2e_latency`` (= inicio de la respuesta - fin del habla del
    usuario al que respondio), que ambas cifras coincidan.
    """

    if stopped is None or started is None:
        return True
    if stopped > started + _TIME_EPS:
        return False
    if e2e is not None and abs((started - stopped) - e2e) > _TIME_EPS:
        return False
    return True


class SessionMetrics:
    """Acumula metricas de una sesion y las escribe en el log local."""

    def __init__(self, *, started_at: float | None = None) -> None:
        self._started_at = time.time() if started_at is None else started_at
        self._startup_s: float | None = None
        self._turns = 0
        self._seen_items: set[str] = set()
        # Mensajes de usuario sin emparejar: (stopped_speaking_at | None, campos).
        self._pending_users: list[tuple[float | None, dict[str, float]]] = []
        self._last_agent_started: float | None = None
        self._errors: dict[str, int] = {}
        self._usage: Any = None
        self._closed = False

    # -- manejadores de eventos ------------------------------------------------

    def on_agent_state_changed(self, ev: Any) -> None:
        if self._startup_s is not None:
            return
        if getattr(ev, "old_state", None) == "initializing" and getattr(
            ev, "new_state", None
        ) != "initializing":
            created_at = _clean(getattr(ev, "created_at", None))
            if created_at is not None and created_at >= self._started_at:
                self._startup_s = round(created_at - self._started_at, 4)
                self._emit("startup", {"startup_s": self._startup_s})

    def on_conversation_item_added(self, ev: Any) -> None:
        item = getattr(ev, "item", None)
        if not isinstance(item, ChatMessage):
            return
        if item.id in self._seen_items:  # evita duplicados por turno
            return
        self._seen_items.add(item.id)

        if item.role == "user":
            self._on_user_message(item)
        elif item.role == "assistant":
            self._on_assistant_message(item)

    def _on_user_message(self, item: ChatMessage) -> None:
        stopped = _clean(item.metrics.get("stopped_speaking_at")) if isinstance(item.metrics, dict) else None
        if (
            stopped is not None
            and self._last_agent_started is not None
            and stopped <= self._last_agent_started + _TIME_EPS
        ):
            # El SDK puede entregar el mensaje del usuario DESPUES de la respuesta
            # que provoco. Esa respuesta ya se registro: sus metricas de usuario
            # se omiten en vez de asignarse a otro turno.
            return
        self._pending_users.append((stopped, _pick(item.metrics, USER_TURN_FIELDS)))
        del self._pending_users[:-_MAX_PENDING_USERS]

    def _on_assistant_message(self, item: ChatMessage) -> None:
        metrics = item.metrics if isinstance(item.metrics, dict) else {}
        started = _clean(metrics.get("started_speaking_at"))
        e2e = _clean(metrics.get("e2e_latency"))

        # Empareja con el mensaje de usuario mas reciente que pueda ser su origen.
        chosen: int | None = None
        for i in range(len(self._pending_users) - 1, -1, -1):
            if _pairs(self._pending_users[i][0], started, e2e):
                chosen = i
                break
        user_fields = self._pending_users[chosen][1] if chosen is not None else {}

        # Descarta lo ya respondido o vencido; conserva los mensajes posteriores
        # a esta respuesta (pertenecen al turno siguiente).
        self._pending_users = [
            entry
            for i, entry in enumerate(self._pending_users)
            if not (chosen is not None and i <= chosen)
            and not (entry[0] is not None and started is not None and entry[0] <= started + _TIME_EPS)
        ]
        if started is not None:
            self._last_agent_started = max(started, self._last_agent_started or started)

        self._turns += 1
        payload: dict[str, Any] = {"turn": self._turns, **user_fields}
        payload.update(_pick(metrics, AGENT_TURN_FIELDS))
        payload["interrupted"] = bool(item.interrupted)
        self._emit("turn", payload)

    def on_usage_updated(self, ev: Any) -> None:
        # Acumulado: solo se conserva el ultimo y se informa al cerrar.
        self._usage = getattr(ev, "usage", None)

    def on_error(self, ev: Any) -> None:
        err = getattr(ev, "error", None)
        kind = _label(getattr(err, "type", None))
        self._errors[kind] = self._errors.get(kind, 0) + 1

    def on_close(self, ev: Any) -> None:
        if self._closed:
            return
        self._closed = True
        reason = getattr(ev, "reason", None)
        payload: dict[str, Any] = {
            "turns": self._turns,
            "errors": dict(sorted(self._errors.items())),
            "close_reason": _label(reason),
        }
        if self._startup_s is not None:
            payload["startup_s"] = self._startup_s
        usage = _usage_summary(self._usage)
        if usage:
            payload["usage"] = usage
        self._emit("session_summary", payload)

    # -- salida ----------------------------------------------------------------

    @staticmethod
    def _emit(kind: str, payload: dict[str, Any]) -> None:
        logger.info("metrics %s %s", kind, json.dumps(payload, sort_keys=True))


def attach_metrics(session: AgentSession, *, started_at: float | None = None) -> SessionMetrics:
    """Engancha el recolector a ``session``. Idempotente: si ya hay uno, lo devuelve.

    ``started_at`` (``time.time()``) marca el inicio para medir la
    inicializacion; por defecto es el instante de esta llamada, que en
    ``agent.entrypoint`` ocurre justo antes de ``session.start``. El tiempo de
    espera previo a la asignacion del job NO esta incluido.
    """

    existing = getattr(session, _MARKER, None)
    if isinstance(existing, SessionMetrics):
        return existing

    metrics = SessionMetrics(started_at=started_at)
    setattr(session, _MARKER, metrics)
    session.on("agent_state_changed", metrics.on_agent_state_changed)
    session.on("conversation_item_added", metrics.on_conversation_item_added)
    session.on("session_usage_updated", metrics.on_usage_updated)
    session.on("error", metrics.on_error)
    session.on("close", metrics.on_close)
    return metrics
