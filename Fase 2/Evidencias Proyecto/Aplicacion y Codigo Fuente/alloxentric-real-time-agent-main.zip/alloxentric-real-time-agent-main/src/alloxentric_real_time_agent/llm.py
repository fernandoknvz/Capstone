"""Componente LLM de DeepSeek (DART_14-1.6).

Responsabilidad de este modulo, dentro del pipeline confirmado
``LiveKit -> Speechmatics (STT) -> LLM -> ElevenLabs (TTS) -> LiveKit``:

- **Entrada:** contexto conversacional en texto (``livekit.agents.llm.ChatContext``).
- **Salida:** respuesta generada por DeepSeek, en streaming cuando el
  llamador lo consume como tal (``LLMStream``/``to_str_iterable``).
- **No** implementa STT (Speechmatics, a cargo de Juan) ni TTS (ElevenLabs,
  a cargo de David), ni logica de negocio, ni un servidor/REST propio.

Integracion oficial utilizada (ver informe DART_14-1.6 para el detalle de
la verificacion): LiveKit expone DeepSeek a traves del plugin ``openai``
-DeepSeek habla el protocolo HTTP compatible con OpenAI-, mediante el
metodo de fabrica ``openai.LLM.with_deepseek()``. No existe ni se agrega un
paquete `livekit-plugins-deepseek` separado porque LiveKit Agents ya
resuelve esta integracion mediante el plugin `openai` (extra
`livekit-agents[openai]`).

La configuracion (credenciales, nombre de modelo) vive exclusivamente en
``alloxentric_real_time_agent.config``; este modulo solo construye el
objeto LLM a partir de esa configuracion ya validada. El modelo se pasa
siempre de forma EXPLICITA a `with_deepseek(model=...)`: nunca se depende
del default propio de LiveKit ("deepseek-chat"), que la documentacion
oficial vigente de DeepSeek marca como retirado (ver
`alloxentric_real_time_agent.config.DEFAULT_DEEPSEEK_MODEL` y el README).
"""

from __future__ import annotations

from typing import Mapping

from livekit.plugins import openai as livekit_openai

from alloxentric_real_time_agent.config import load_deepseek_settings


def build_deepseek_llm(env: Mapping[str, str] | None = None) -> livekit_openai.LLM:
    """Construye el componente LLM de DeepSeek listo para una ``AgentSession``.

    El objeto devuelto es una instancia de ``livekit.plugins.openai.LLM``,
    por lo que es directamente compatible con
    ``AgentSession(llm=build_deepseek_llm())``.

    No realiza ninguna llamada de red: la construccion del cliente es
    perezosa. La primera llamada de red ocurre al invocar ``.chat()`` sobre
    el objeto devuelto (ver ``scripts/check_deepseek_llm.py`` para una
    verificacion real, manual y de bajo costo).

    Raises
    ------
    alloxentric_real_time_agent.config.MissingConfigurationError
        Si falta ``DEEPSEEK_API_KEY`` en el entorno.
    """

    settings = load_deepseek_settings(env)
    return livekit_openai.LLM.with_deepseek(
        model=settings.model,
        api_key=settings.api_key,
    )
