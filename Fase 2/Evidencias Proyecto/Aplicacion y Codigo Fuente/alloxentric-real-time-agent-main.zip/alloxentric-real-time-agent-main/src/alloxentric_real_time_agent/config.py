"""Configuracion de entorno del agente.

Centraliza la lectura y validacion de variables de entorno por proveedor:

- LiveKit (CONFIRMADO: forma parte del flujo conversacional requerido, ver
  CLAUDE.md seccion 2).
- DeepSeek (CONFIRMADO desde DART_14-1.6: responsabilidad del LLM en el
  pipeline, ver CLAUDE.md seccion 2 y el informe de DART_14-1.6).
- ElevenLabs (TTS, rama feature/DART-14-1.6-elevenlabs-tts).

- Gemini (LLM alternativo a DeepSeek, DART-14-2.1).
- Google Cloud Speech-to-Text / Chirp 3 (STT, DART_14-2.2). Reemplaza a
  Speechmatics por indicacion del cliente. Se autentica con Application
  Default Credentials (ADC), NO con una API key.
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass
from typing import Mapping

#: Variables de entorno requeridas para conectar con un proyecto LiveKit.
#: Nombres verificados contra la documentacion oficial de LiveKit
#: (https://docs.livekit.io/agents/start/voice-ai, seccion de credenciales).
REQUIRED_LIVEKIT_VARS: tuple[str, ...] = (
    "LIVEKIT_URL",
    "LIVEKIT_API_KEY",
    "LIVEKIT_API_SECRET",
)


class MissingConfigurationError(RuntimeError):
    """Se lanza cuando falta una o mas variables de entorno requeridas."""

    def __init__(self, missing: list[str]) -> None:
        self.missing = missing
        joined = ", ".join(missing)
        super().__init__(
            "Faltan variable(s) de entorno requeridas: "
            f"{joined}. Copia .env.example a .env.local (o .env) y completa "
            "las credenciales correspondientes antes de iniciar el agente."
        )


@dataclass(frozen=True)
class LiveKitSettings:
    """Configuracion minima necesaria para que el worker se conecte a LiveKit."""

    url: str
    api_key: str
    api_secret: str


def load_livekit_settings(env: Mapping[str, str] | None = None) -> LiveKitSettings:
    """Lee y valida la configuracion de LiveKit desde el entorno.

    Parameters
    ----------
    env:
        Mapeo desde donde leer las variables. Por defecto usa ``os.environ``;
        las pruebas pasan un mapeo explicito en vez de mutar el entorno real
        del proceso.

    Raises
    ------
    MissingConfigurationError
        Si falta alguna variable requerida o esta vacia.
    """

    source = env if env is not None else os.environ
    missing = [name for name in REQUIRED_LIVEKIT_VARS if not source.get(name)]
    if missing:
        raise MissingConfigurationError(missing)

    return LiveKitSettings(
        url=source["LIVEKIT_URL"],
        api_key=source["LIVEKIT_API_KEY"],
        api_secret=source["LIVEKIT_API_SECRET"],
    )


# --- DeepSeek (LLM) ---------------------------------------------------------
#
# Variable requerida verificada contra el docstring de
# ``livekit.plugins.openai.LLM.with_deepseek`` (livekit-plugins-openai
# 1.8.4, instalada en este ticket): "api_key must be set to your DeepSeek
# API key, either using the argument or by setting the DEEPSEEK_API_KEY
# environmental variable."
REQUIRED_DEEPSEEK_VARS: tuple[str, ...] = ("DEEPSEEK_API_KEY",)

#: Modelo por defecto si no se fija DEEPSEEK_MODEL.
#:
#: NO coincide con el default de `with_deepseek()` en el SDK instalado
#: (livekit-plugins-openai==1.8.4 sigue usando "deepseek-chat" como
#: ejemplo/default). Se fija explicitamente a "deepseek-flash" porque la
#: documentacion oficial VIGENTE de DeepSeek (fuente primaria) confirma:
#:   - "deepseek-chat" y "deepseek-reasoner" fueron retirados el
#:     2026-07-24;
#:   - "DeepSeek-V4.1-Flash" se publico el 2026-09-10;
#:   - el identificador de API actual para ese modelo es "deepseek-flash".
#: Ver README (seccion "Integracion DeepSeek") para el detalle completo de
#: esta discrepancia entre LiveKit y DeepSeek, y el informe de DART_14-1.6.
DEFAULT_DEEPSEEK_MODEL = "deepseek-flash"

#: Nombre de la variable de entorno opcional para sobreescribir el modelo
#: sin tocar codigo, ante la evolucion de nombres de modelo de DeepSeek.
DEEPSEEK_MODEL_VAR = "DEEPSEEK_MODEL"


@dataclass(frozen=True)
class DeepSeekSettings:
    """Configuracion minima para construir el LLM de DeepSeek."""

    api_key: str
    model: str


def load_deepseek_settings(env: Mapping[str, str] | None = None) -> DeepSeekSettings:
    """Lee y valida la configuracion de DeepSeek desde el entorno.

    Parameters
    ----------
    env:
        Mapeo desde donde leer las variables. Por defecto usa ``os.environ``.

    Raises
    ------
    MissingConfigurationError
        Si falta ``DEEPSEEK_API_KEY`` o esta vacia.
    """

    source = env if env is not None else os.environ
    missing = [name for name in REQUIRED_DEEPSEEK_VARS if not source.get(name)]
    if missing:
        raise MissingConfigurationError(missing)

    model = source.get(DEEPSEEK_MODEL_VAR) or DEFAULT_DEEPSEEK_MODEL

    return DeepSeekSettings(api_key=source["DEEPSEEK_API_KEY"], model=model)


# --- ElevenLabs (TTS) -------------------------------------------------------
#
# Variable requerida verificada contra el codigo de
# ``livekit.plugins.elevenlabs.TTS`` (livekit-plugins-elevenlabs 1.8.4,
# instalada en este ticket): "ElevenLabs API key is required, either as
# argument or set ELEVEN_API_KEY environmental variable", y contra la
# documentacion oficial del plugin
# (https://docs.livekit.io/agents/models/tts/plugins/elevenlabs/).
# Ojo: el SDK propio de ElevenLabs usa ELEVENLABS_API_KEY; el plugin de
# LiveKit NO lee ese nombre, por eso aqui se usa ELEVEN_API_KEY.
REQUIRED_ELEVENLABS_VARS: tuple[str, ...] = ("ELEVEN_API_KEY",)

#: Modelo TTS por defecto si no se fija ELEVEN_TTS_MODEL (PROPUESTA).
#:
#: NO coincide con el default de ``elevenlabs.TTS()`` en el SDK instalado
#: (livekit-plugins-elevenlabs==1.8.4 usa "eleven_turbo_v2_5"). La
#: documentacion oficial vigente de ElevenLabs (https://elevenlabs.io/docs/models)
#: marca "eleven_turbo_v2_5" como deprecado y su reemplazo es
#: "eleven_flash_v2_5": baja latencia (~75 ms de inferencia segun ElevenLabs),
#: multilingue (incluye espanol) y servido por el WebSocket de
#: Text-to-Speech clasico. "eleven_v4_turbo" (recomendado por ElevenLabs para
#: agentes, publicado 2026-09-28) usa otro endpoint (Text-to-Dialogue) y queda
#: disponible via ELEVEN_TTS_MODEL. Ver README, seccion "Integracion ElevenLabs".
#:
#: DART-14-5.1: el default pasa a "eleven_v4_turbo" (PROPUESTA). Medicion real con
#: la cuenta del equipo (2026-10-30, plugin de LiveKit en streaming, misma frase
#: y voz): primer audio 0,50-0,52 s con eleven_v4_turbo frente a 0,48-0,49 s con
#: eleven_flash_v2_5, es decir una diferencia insignificante con mayor calidad
#: de voz. eleven_v3 y eleven_v4 NO se usan: la documentacion de ElevenLabs indica
#: que no soportan el WebSocket de tiempo real, y por HTTP tardaron 0,67 y 0,75 s.
DEFAULT_ELEVENLABS_TTS_MODEL = "eleven_v4_turbo"

#: Voz de PRUEBA por defecto si no se fija ELEVEN_VOICE_ID.
#:
#: PROPUESTA temporal: es el ``DEFAULT_VOICE_ID`` del propio plugin
#: (livekit-plugins-elevenlabs 1.8.4). NO es la voz definitiva del producto,
#: que sigue PENDIENTE de requerimiento confirmado. Se fija aqui de forma
#: explicita para no depender en silencio de un default interno del SDK.
DEFAULT_ELEVENLABS_VOICE_ID = "oJIuRMopN0sojGjwD6rQ"

#: Idioma de sintesis (normalizacion de texto y pronunciacion). El producto habla
#: espanol (PROPUESTA, el idioma definitivo sigue PENDIENTE). "off" no lo envia.
DEFAULT_ELEVENLABS_LANGUAGE = "es"
ELEVENLABS_LANGUAGE_VAR = "ELEVEN_LANGUAGE"

#: Variables opcionales (propias del proyecto, no del plugin) para cambiar
#: modelo y voz sin tocar codigo.
ELEVENLABS_TTS_MODEL_VAR = "ELEVEN_TTS_MODEL"
ELEVENLABS_VOICE_ID_VAR = "ELEVEN_VOICE_ID"


@dataclass(frozen=True)
class ElevenLabsSettings:
    """Configuracion minima para construir el TTS de ElevenLabs."""

    api_key: str
    model: str
    voice_id: str
    #: ``None`` = no enviar idioma.
    language: str | None = DEFAULT_ELEVENLABS_LANGUAGE

    def __repr__(self) -> str:
        # Nunca exponer la API key en logs ni en tracebacks.
        return (
            f"ElevenLabsSettings(api_key='***', model={self.model!r}, "
            f"voice_id={self.voice_id!r}, language={self.language!r})"
        )


def load_elevenlabs_settings(env: Mapping[str, str] | None = None) -> ElevenLabsSettings:
    """Lee y valida la configuracion de ElevenLabs desde el entorno.

    Parameters
    ----------
    env:
        Mapeo desde donde leer las variables. Por defecto usa ``os.environ``.

    Raises
    ------
    MissingConfigurationError
        Si falta ``ELEVEN_API_KEY`` o esta vacia.
    """

    source = env if env is not None else os.environ
    missing = [name for name in REQUIRED_ELEVENLABS_VARS if not source.get(name)]
    if missing:
        raise MissingConfigurationError(missing)

    model = source.get(ELEVENLABS_TTS_MODEL_VAR) or DEFAULT_ELEVENLABS_TTS_MODEL
    voice_id = source.get(ELEVENLABS_VOICE_ID_VAR) or DEFAULT_ELEVENLABS_VOICE_ID

    raw_language = (source.get(ELEVENLABS_LANGUAGE_VAR) or "").strip()
    if not raw_language:
        language: str | None = DEFAULT_ELEVENLABS_LANGUAGE
    elif raw_language.lower() in ("off", "none", "false"):
        language = None
    else:
        language = raw_language

    return ElevenLabsSettings(
        api_key=source["ELEVEN_API_KEY"], model=model, voice_id=voice_id, language=language
    )


# --- Gemini (LLM alternativo, DART-14-2.1) ----------------------------------
#
# Gemini se usa temporalmente como alternativa a DeepSeek (autorizado por
# Alloxentric). Autenticacion: Gemini Developer API con GOOGLE_API_KEY
# (PROPUESTA; Vertex AI queda fuera de esta iteracion). La variable es la que
# documenta LiveKit para el plugin de Google
# (https://docs.livekit.io/agents/models/llm/plugins/gemini/).
REQUIRED_GEMINI_VARS: tuple[str, ...] = ("GOOGLE_API_KEY",)

#: Modelo por defecto si no se fija GEMINI_MODEL (PROPUESTA).
#:
#: NO coincide con el default de ``google.LLM()`` en livekit-plugins-google
#: 1.8.4 ("gemini-2.5-flash"), que Google solo mantiene para usuarios que ya
#: lo usaban. "gemini-3.8-flash" figura como modelo estable de texto en la
#: lista oficial de modelos de Google (https://ai.google.dev/gemini-api/docs/models,
#: consultada el 2026-10-14), sin fecha de retiro en la pagina de deprecaciones,
#: y tambien aparece en la documentacion de LiveKit. La eleccion final
#: (p. ej. "gemini-3.5-flash-lite" para menor latencia) es PENDIENTE de
#: mediciones; se cambia con GEMINI_MODEL sin tocar codigo.
#:
#: DART-14-5.1: el default pasa a "gemini-3.1-flash-lite" por latencia. Medicion
#: real (2026-10-30, misma key y prompt, mediana de 4 corridas, tiempo al primer
#: token): gemini-3.8-flash 3,64 s; gemini-3.6-flash 2,44 s (1,99 s con thinking
#: minimo); gemini-3.5-flash-lite 1,80 s; gemini-3.1-flash-lite 1,82 s (1,55 s
#: con thinking minimo). Valores orientativos desde Chile, no un benchmark.
DEFAULT_GEMINI_MODEL = "gemini-3.1-flash-lite"

GEMINI_MODEL_VAR = "GEMINI_MODEL"

#: Nivel de "thinking" de Gemini 3 (PROPUESTA). "MINIMAL" reduce el tiempo al
#: primer token y es suficiente para dialogo por voz. No todos los modelos lo
#: soportan (gemini-3.8-flash responde 400): con esos modelos use
#: GEMINI_THINKING_LEVEL=off para no enviarlo.
DEFAULT_GEMINI_THINKING_LEVEL = "MINIMAL"
GEMINI_THINKING_LEVEL_VAR = "GEMINI_THINKING_LEVEL"
_THINKING_LEVELS = ("MINIMAL", "LOW", "MEDIUM", "HIGH")


@dataclass(frozen=True)
class GeminiSettings:
    """Configuracion minima para construir el LLM de Gemini."""

    api_key: str
    model: str
    #: ``None`` = no enviar thinking_config.
    thinking_level: str | None = DEFAULT_GEMINI_THINKING_LEVEL

    def __repr__(self) -> str:
        # Nunca exponer la API key en logs ni en tracebacks.
        return (
            f"GeminiSettings(api_key='***', model={self.model!r}, "
            f"thinking_level={self.thinking_level!r})"
        )


def load_gemini_settings(env: Mapping[str, str] | None = None) -> GeminiSettings:
    """Lee y valida la configuracion de Gemini desde el entorno.

    Raises
    ------
    MissingConfigurationError
        Si falta ``GOOGLE_API_KEY`` o esta vacia.
    """

    source = env if env is not None else os.environ
    missing = [name for name in REQUIRED_GEMINI_VARS if not source.get(name)]
    if missing:
        raise MissingConfigurationError(missing)

    model = source.get(GEMINI_MODEL_VAR) or DEFAULT_GEMINI_MODEL

    raw_level = (source.get(GEMINI_THINKING_LEVEL_VAR) or "").strip()
    if not raw_level:
        thinking_level: str | None = DEFAULT_GEMINI_THINKING_LEVEL
    elif raw_level.lower() in ("off", "none", "false"):
        thinking_level = None
    elif raw_level.upper() in _THINKING_LEVELS:
        thinking_level = raw_level.upper()
    else:
        raise InvalidConfigurationError(
            f"{GEMINI_THINKING_LEVEL_VAR} debe ser uno de "
            f"{', '.join(_THINKING_LEVELS)} u off."
        )

    return GeminiSettings(
        api_key=source["GOOGLE_API_KEY"], model=model, thinking_level=thinking_level
    )


# --- Google Cloud Speech-to-Text / Chirp 3 (STT) ----------------------------
#
# Autenticacion: Application Default Credentials (ADC), configuradas con
# ``gcloud auth application-default login`` (o una cuenta de servicio via
# GOOGLE_APPLICATION_CREDENTIALS). No existe ni se usa una API key de Google
# para este componente. Por eso la unica variable requerida es el ID del
# proyecto de Google Cloud; las credenciales nunca pasan por este modulo.
GOOGLE_CLOUD_PROJECT_VAR = "GOOGLE_CLOUD_PROJECT"
REQUIRED_GOOGLE_STT_VARS: tuple[str, ...] = (GOOGLE_CLOUD_PROJECT_VAR,)

#: Modelo de Google STT (CONFIRMADO por el equipo: ``chirp_3``).
GOOGLE_STT_MODEL = "chirp_3"

#: Ubicacion por defecto (PROPUESTA). Chirp 3 NO se sirve desde "global": la
#: documentacion de Google lo lista en multi-regiones ("us", "eu") y en
#: regiones concretas (p. ej. asia-northeast1). "us" es una ubicacion GA.
#: Cambiable con GOOGLE_STT_LOCATION.
DEFAULT_GOOGLE_STT_LOCATION = "us"
GOOGLE_STT_LOCATION_VAR = "GOOGLE_STT_LOCATION"

#: Idioma por defecto (PROPUESTA; el idioma definitivo del producto es
#: PENDIENTE). Chirp 3 lista es-ES y es-US como GA; es-MX figura como Preview.
DEFAULT_GOOGLE_STT_LANGUAGE = "es-US"
GOOGLE_STT_LANGUAGE_VAR = "GOOGLE_STT_LANGUAGE"


@dataclass(frozen=True)
class GoogleSTTSettings:
    """Configuracion minima para construir el STT de Google (Chirp 3)."""

    project: str
    location: str
    language: str
    model: str = GOOGLE_STT_MODEL


def load_google_stt_settings(env: Mapping[str, str] | None = None) -> GoogleSTTSettings:
    """Lee y valida la configuracion de Google STT desde el entorno.

    Las credenciales (ADC) NO se validan aqui: se resuelven al construir el
    componente, ver ``alloxentric_real_time_agent.stt``.

    Raises
    ------
    MissingConfigurationError
        Si falta ``GOOGLE_CLOUD_PROJECT`` o esta vacia.
    """

    source = env if env is not None else os.environ
    missing = [name for name in REQUIRED_GOOGLE_STT_VARS if not (source.get(name) or "").strip()]
    if missing:
        raise MissingConfigurationError(missing)

    return GoogleSTTSettings(
        project=source[GOOGLE_CLOUD_PROJECT_VAR].strip(),
        location=(source.get(GOOGLE_STT_LOCATION_VAR) or "").strip()
        or DEFAULT_GOOGLE_STT_LOCATION,
        language=(source.get(GOOGLE_STT_LANGUAGE_VAR) or "").strip()
        or DEFAULT_GOOGLE_STT_LANGUAGE,
    )


# --- Seleccion del proveedor LLM del pipeline (DART-14-2.4) -----------------
#
# El pipeline usa un unico LLM, elegido de forma explicita entre los ya
# integrados (DeepSeek: DART_14-1.6, Gemini: DART-14-2.1).
LLM_PROVIDER_VAR = "LLM_PROVIDER"
SUPPORTED_LLM_PROVIDERS: tuple[str, ...] = ("gemini", "deepseek")

#: Proveedor por defecto si no se fija LLM_PROVIDER (PROPUESTA; la eleccion
#: definitiva del LLM es PENDIENTE de mediciones de rendimiento).
DEFAULT_LLM_PROVIDER = "gemini"


class InvalidConfigurationError(ValueError):
    """Se lanza cuando una variable de entorno tiene un valor no permitido.

    El mensaje nunca incluye el valor recibido: podria ser una credencial
    pegada por error en la variable equivocada.
    """


def load_llm_provider(env: Mapping[str, str] | None = None) -> str:
    """Lee y valida ``LLM_PROVIDER`` (``gemini`` o ``deepseek``).

    Ignora mayusculas y espacios alrededor. Si falta o esta vacia, usa
    ``DEFAULT_LLM_PROVIDER``.

    Raises
    ------
    InvalidConfigurationError
        Si el valor no es uno de ``SUPPORTED_LLM_PROVIDERS``.
    """

    source = env if env is not None else os.environ
    provider = (source.get(LLM_PROVIDER_VAR) or "").strip().lower()
    if not provider:
        return DEFAULT_LLM_PROVIDER
    if provider not in SUPPORTED_LLM_PROVIDERS:
        allowed = ", ".join(SUPPORTED_LLM_PROVIDERS)
        raise InvalidConfigurationError(
            f"{LLM_PROVIDER_VAR} tiene un valor no soportado. "
            f"Valores permitidos: {allowed}."
        )
    return provider


#: Nombre de despacho explicito con el que se registra el worker (el mismo que
#: usa la Web Demo publicada). Es el valor por defecto: sin variable no cambia
#: nada.
DEFAULT_AGENT_NAME = "alloxentric-real-time-agent"

AGENT_NAME_VAR = "LIVEKIT_AGENT_NAME"

_AGENT_NAME_PATTERN = re.compile(r"[a-z0-9][a-z0-9-]{0,62}")


def resolve_agent_name(env: Mapping[str, str] | None = None) -> str:
    """Nombre con el que el worker se registra para despacho explicito.

    DART-14-5.1: permite aislar un worker de desarrollo (p. ej.
    ``alloxentric-real-time-agent-dev``) de la Web Demo publicada. El argumento
    ``agent_name`` del decorador tiene precedencia sobre ``LIVEKIT_AGENT_NAME``
    dentro de livekit-agents 1.8.4, por eso el valor se resuelve aqui y se
    pasa explicitamente. Variable ausente o vacia -> ``DEFAULT_AGENT_NAME``.

    Raises
    ------
    InvalidConfigurationError
        Si el valor no es un nombre en minusculas, digitos y guiones. Falla
        rapido en vez de registrarse con un nombre inesperado; el mensaje no
        incluye el valor recibido.
    """

    source = env if env is not None else os.environ
    value = (source.get(AGENT_NAME_VAR) or "").strip()
    if not value:
        return DEFAULT_AGENT_NAME
    if not _AGENT_NAME_PATTERN.fullmatch(value):
        raise InvalidConfigurationError(
            f"{AGENT_NAME_VAR} debe usar solo minusculas, digitos y guiones "
            "(maximo 63 caracteres)."
        )
    return value
