"""Componente STT de Google Chirp 3 (DART_14-2.2, responsabilidad de Juan).

Responsabilidad dentro del pipeline
``LiveKit -> STT -> LLM -> ElevenLabs (TTS) -> LiveKit``:

- **Entrada:** frames de audio de LiveKit (``rtc.AudioFrame``, PCM 16-bit,
  16 kHz) que ``AgentSession`` (o ``stt.stream()``) empuja al stream.
- **Salida:** ``SpeechEvent`` de LiveKit: ``INTERIM_TRANSCRIPT`` (parciales) y
  ``FINAL_TRANSCRIPT`` (finales). ``AgentSession`` los consume directamente;
  no hay API propia entre STT y agente.
- **No** implementa LLM ni TTS ni la conversacion E2E.

Integracion oficial: ``livekit-plugins-google`` (extra
``livekit-agents[google]``), clase ``google.STT``, con el modelo ``chirp_3``
(Speech-to-Text API v2, streaming por gRPC).

Autenticacion: Application Default Credentials (ADC), sin API key. El runner
las resuelve durante setup desde ``gcloud auth application-default login`` o
``GOOGLE_APPLICATION_CREDENTIALS`` y las inyecta explicitamente en Google STT.

Notas de configuracion verificadas contra el plugin 1.8.4:

- ``chirp_3`` no admite word timestamps (el plugin los desactiva).
- ``detect_language=False``: se transcribe en un idioma fijo y configurable.
- ``location`` debe ser regional (``us``, ``eu``...); ``global`` no sirve
  para Chirp 3.
"""

from __future__ import annotations

from collections.abc import Mapping

from google.auth import default as google_auth_default
from google.auth.credentials import Credentials
from google.auth.exceptions import DefaultCredentialsError
from livekit.plugins import google

from alloxentric_real_time_agent.config import (
    GoogleSTTSettings,
    load_google_stt_settings,
)


#: Sensibilidad de fin de habla de Chirp 3 (PROPUESTA): "SHORT" entrega el
#: resultado final antes que "STANDARD", a costa de poder cortar pausas largas.
ENDPOINTING_SENSITIVITY = "ENDPOINTING_SENSITIVITY_SHORT"


class MissingCredentialsError(RuntimeError):
    """No hay Application Default Credentials disponibles para Google STT."""

    def __init__(self) -> None:
        super().__init__(
            "No se encontraron Application Default Credentials (ADC) de Google "
            "Cloud. Instala Google Cloud CLI y ejecuta "
            "`gcloud auth application-default login` con tu cuenta, o define "
            "GOOGLE_APPLICATION_CREDENTIALS. No se usa ninguna API key."
        )


def resolve_google_adc() -> Credentials:
    """Resuelve ADC de forma sincrona para ejecutarse en el setup del proceso."""

    try:
        credentials, _ = google_auth_default()
    except DefaultCredentialsError as exc:
        raise MissingCredentialsError() from exc
    return credentials


def build_google_stt(
    settings: GoogleSTTSettings,
    *,
    credentials: Credentials | None = None,
) -> google.STT:
    """Construye Google STT con configuracion y credenciales ya resueltas.

    Si ``credentials`` es ``None``, conserva el fallback ADC del plugin para
    usos aislados. No hace llamadas de red: la conexion gRPC se abre al iniciar
    un stream.

    Errores durante el stream (los lanza el plugin): ``APIConnectionError`` /
    ``APIStatusError`` de ``livekit.agents`` (p. ej. permisos IAM faltantes,
    API deshabilitada, ubicacion/idioma no soportados).

    Raises
    ------
    MissingCredentialsError
        Si no se entregaron credenciales y el fallback ADC no esta disponible.
    """

    try:
        kwargs = {"credentials": credentials} if credentials is not None else {}
        return google.STT(
            model=settings.model,
            languages=settings.language,
            detect_language=False,
            location=settings.location,
            project=settings.project,
            interim_results=True,
            punctuate=True,
            # Menor latencia de fin de habla (solo chirp_3). DART-14-5.1.
            endpointing_sensitivity=ENDPOINTING_SENSITIVITY,
            **kwargs,
        )
    except ValueError as exc:
        if "Application default credentials" in str(exc):
            raise MissingCredentialsError() from exc
        raise


def create_google_stt(
    env: Mapping[str, str] | None = None,
    *,
    credentials: Credentials | None = None,
) -> google.STT:
    """Lee la configuracion y construye STT con credenciales explicitas.

    Raises
    ------
    alloxentric_real_time_agent.config.MissingConfigurationError
        Si falta ``GOOGLE_CLOUD_PROJECT``.
    MissingCredentialsError
        Si no se entregaron credenciales y el fallback ADC no esta disponible.
    """

    return build_google_stt(load_google_stt_settings(env), credentials=credentials)
