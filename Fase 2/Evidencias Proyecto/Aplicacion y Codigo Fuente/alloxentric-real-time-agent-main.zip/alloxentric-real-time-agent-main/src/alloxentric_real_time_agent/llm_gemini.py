"""Componente LLM de Gemini (DART-14-2.1), alternativo a DeepSeek.

Mismo contrato que ``llm.build_deepseek_llm``: devuelve un
``livekit.agents.llm.LLM`` compatible con ``AgentSession(llm=...)``. Gemini
se autoriza solo como alternativa temporal; DeepSeek (``llm.py``) no se toca.

Integracion oficial: plugin ``livekit-plugins-google`` (fijado a 1.8.4, igual
que ``livekit-agents``), clase ``google.LLM``. Se usa la Gemini Developer API
(``vertexai=False`` explicito, para no caer en Vertex por variables de
entorno ajenas). Modelo y credencial se pasan siempre de forma explicita.
"""

from __future__ import annotations

from typing import Mapping

from google.genai import types as genai_types
from livekit.plugins import google as livekit_google

from alloxentric_real_time_agent.config import load_gemini_settings


#: Tope de tokens de salida por turno de voz (PROPUESTA).
MAX_OUTPUT_TOKENS = 220


def build_gemini_llm(env: Mapping[str, str] | None = None) -> livekit_google.LLM:
    """Construye el LLM de Gemini listo para una ``AgentSession``.

    No realiza llamadas de red al construirse; la primera ocurre en ``.chat()``.

    Raises
    ------
    alloxentric_real_time_agent.config.MissingConfigurationError
        Si falta ``GOOGLE_API_KEY`` en el entorno.
    """

    settings = load_gemini_settings(env)
    extra: dict[str, object] = {}
    if settings.thinking_level is not None:
        # Menor tiempo al primer token (DART-14-5.1, ver config.py).
        extra["thinking_config"] = genai_types.ThinkingConfig(
            thinking_level=settings.thinking_level
        )
    return livekit_google.LLM(
        model=settings.model,
        api_key=settings.api_key,
        vertexai=False,
        # Respuestas de voz cortas: acota la generacion (el prompt ya pide
        # 1-2 frases). No recorta el historial ni el contexto de entrada.
        max_output_tokens=MAX_OUTPUT_TOKENS,
        **extra,
    )
