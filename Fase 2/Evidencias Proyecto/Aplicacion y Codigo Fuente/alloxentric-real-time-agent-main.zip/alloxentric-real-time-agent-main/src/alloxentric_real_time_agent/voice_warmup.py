"""Precalentamiento de las voces de ElevenLabs (DART-14-5.1).

Medicion real (2026-10-30, cuenta del equipo): la PRIMERA sintesis con cada voz
de la biblioteca tarda 4-6 s (carga en frio); desde la segunda baja a ~0,3 s.
Sin precalentar, el saludo de cada agente llegaria 4-6 s tarde la primera vez.

Al iniciar cada proceso del worker se envia, en segundo plano, una sintesis de
una sola palabra por voz de persona. Es un costo minimo (``len("Hola.")``
caracteres por voz) y nunca bloquea ni hace fallar el arranque: cualquier error
se ignora y solo se registra su tipo. Se desactiva con ``ELEVEN_VOICE_WARMUP=off``.
"""

from __future__ import annotations

import json
import logging
import os
import threading
import urllib.request
from collections.abc import Mapping

from alloxentric_real_time_agent.config import (
    ELEVENLABS_LANGUAGE_VAR,
    ELEVENLABS_TTS_MODEL_VAR,
    DEFAULT_ELEVENLABS_LANGUAGE,
    DEFAULT_ELEVENLABS_TTS_MODEL,
)
from alloxentric_real_time_agent.personas import PERSONAS

logger = logging.getLogger("alloxentric_real_time_agent.voice_warmup")

WARMUP_VAR = "ELEVEN_VOICE_WARMUP"
WARMUP_TEXT = "Hola."
_URL = "https://api.elevenlabs.io/v1/text-to-speech/{voice_id}/stream?output_format=pcm_16000"


def _enabled(source: Mapping[str, str]) -> bool:
    return (source.get(WARMUP_VAR) or "").strip().lower() not in ("off", "false", "0", "no")


def warm_up_voice(voice_id: str, env: Mapping[str, str] | None = None, timeout: float = 30.0) -> bool:
    """Sintetiza una palabra con la voz indicada. Devuelve si tuvo exito."""

    source = env if env is not None else os.environ
    api_key = (source.get("ELEVEN_API_KEY") or "").strip()
    if not api_key:
        return False
    payload: dict[str, str] = {
        "text": WARMUP_TEXT,
        "model_id": (source.get(ELEVENLABS_TTS_MODEL_VAR) or DEFAULT_ELEVENLABS_TTS_MODEL),
    }
    language = (source.get(ELEVENLABS_LANGUAGE_VAR) or DEFAULT_ELEVENLABS_LANGUAGE).strip()
    if language and language.lower() not in ("off", "none", "false"):
        payload["language_code"] = language
    request = urllib.request.Request(
        _URL.format(voice_id=voice_id),
        data=json.dumps(payload).encode("utf-8"),
        headers={"xi-api-key": api_key, "Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:  # noqa: S310 - URL fija https
            response.read()
        return True
    except Exception as exc:  # noqa: BLE001 - el precalentamiento nunca debe romper el arranque
        # Solo el tipo: el mensaje podria incluir detalles del proveedor.
        logger.warning("Precalentamiento de voz fallido: %s", type(exc).__name__)
        return False


def start_voice_warmup(env: Mapping[str, str] | None = None) -> list[threading.Thread]:
    """Lanza un hilo daemon por voz de persona y regresa de inmediato."""

    source = env if env is not None else os.environ
    if not _enabled(source) or not (source.get("ELEVEN_API_KEY") or "").strip():
        return []
    voice_ids = sorted({persona.voice_id for persona in PERSONAS.values()})
    threads = [
        threading.Thread(
            target=warm_up_voice, args=(voice_id, source), name=f"voice-warmup-{index}", daemon=True
        )
        for index, voice_id in enumerate(voice_ids)
    ]
    for thread in threads:
        thread.start()
    return threads
