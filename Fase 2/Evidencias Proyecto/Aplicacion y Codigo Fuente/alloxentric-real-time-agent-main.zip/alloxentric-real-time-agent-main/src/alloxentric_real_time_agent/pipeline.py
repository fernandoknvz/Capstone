"""Composicion del pipeline de voz (DART-14-2.4).

Flujo logico::

    audio de la sala LiveKit
        -> STT   Google Chirp 3          (stt.create_google_stt)
        -> LLM   Gemini o DeepSeek       (llm_gemini / llm, segun LLM_PROVIDER)
        -> TTS   ElevenLabs              (tts.build_elevenlabs_tts)
        -> audio publicado en la sala

Este modulo solo COMPONE los builders existentes en una ``AgentSession``; no
reimplementa STT, LLM ni TTS ni duplica su configuracion. Construir la sesion
no abre conexiones de red: la primera llamada a cada proveedor ocurre cuando
la sesion se inicia dentro de un job de LiveKit.

VAD y turnos: se usa el valor por defecto de livekit-agents 1.8.4, que
incluye un VAD silero local (``livekit.agents.inference.VAD``). No se agrega
``livekit-plugins-silero`` ni ``turn_detector``.
"""

from __future__ import annotations

import logging
from typing import Callable, Mapping

from google.auth.credentials import Credentials
from livekit.agents import Agent, AgentSession, CloseEvent, ErrorEvent
from livekit.agents.llm import LLM

from alloxentric_real_time_agent.config import (
    MissingConfigurationError,
    load_llm_provider,
)
from alloxentric_real_time_agent.llm import build_deepseek_llm
from alloxentric_real_time_agent.llm_gemini import build_gemini_llm
from alloxentric_real_time_agent.metrics import attach_metrics
from alloxentric_real_time_agent.personas import Persona, build_instructions
from alloxentric_real_time_agent.stt import create_google_stt
from alloxentric_real_time_agent.tts import build_elevenlabs_tts

logger = logging.getLogger("alloxentric_real_time_agent.pipeline")

#: PROPUESTA TEMPORAL, solo para pruebas tecnicas del pipeline. No define un
#: caso de uso empresarial (el caso de uso de Alloxentric es PENDIENTE).
AGENT_INSTRUCTIONS = (
    "Eres un asistente de voz de prueba del proyecto Alloxentric Real Time "
    "Agent. Responde en español de forma breve, clara y natural. No solicites "
    "información personal."
)

_LLM_BUILDERS: dict[str, Callable[[Mapping[str, str] | None], LLM]] = {
    "gemini": build_gemini_llm,
    "deepseek": build_deepseek_llm,
}


def build_llm(env: Mapping[str, str] | None = None) -> LLM:
    """Construye el LLM elegido por ``LLM_PROVIDER`` (por defecto ``gemini``).

    Raises
    ------
    alloxentric_real_time_agent.config.InvalidConfigurationError
        Si ``LLM_PROVIDER`` no es un proveedor soportado.
    alloxentric_real_time_agent.config.MissingConfigurationError
        Si falta la credencial del proveedor elegido.
    """

    return _build_llm_for(load_llm_provider(env), env)


def _build_llm_for(provider: str, env: Mapping[str, str] | None) -> LLM:
    return _LLM_BUILDERS[provider](env)


def build_agent(persona: Persona | None = None) -> Agent:
    """Agente de la persona elegida, o el de prueba si no hay persona."""

    if persona is None:
        return Agent(instructions=AGENT_INSTRUCTIONS)
    return Agent(instructions=build_instructions(persona))


#: Manejo de turnos orientado a baja latencia (DART-14-5.1, PROPUESTA).
#:
#: - ``preemptive_generation`` (activo por defecto en livekit-agents 1.8.4):
#:   el LLM empieza con la transcripcion parcial, antes de confirmar el fin de
#:   turno. ``preemptive_tts=True`` ademas inicia el TTS en paralelo.
#: - ``endpointing`` dinamico con ``min_delay`` 0,3 s (default 0,5 s): espera
#:   menos tras el silencio y se adapta al ritmo de quien habla.
#: El historial de la conversacion NO se recorta: se conserva el contexto.
TURN_HANDLING = {
    "endpointing": {"mode": "dynamic", "min_delay": 0.3, "max_delay": 1.5},
    "preemptive_generation": {"enabled": True, "preemptive_tts": True},
}


def build_agent_session(
    env: Mapping[str, str] | None = None,
    *,
    google_credentials: Credentials | None = None,
    persona: Persona | None = None,
) -> AgentSession:
    """Arma la ``AgentSession`` con STT, LLM y TTS desde el entorno.

    Valida primero el proveedor LLM y luego construye los tres componentes,
    acumulando TODAS las variables faltantes en un unico
    ``MissingConfigurationError`` para corregirlas de una vez. En el worker,
    ADC llega resuelto desde ``setup_process`` y se inyecta de forma explicita
    en Google STT; el builder conserva su fallback ADC para usos aislados.

    No realiza llamadas de red.
    """

    # Se lee y valida una sola vez, antes de construir nada.
    provider = load_llm_provider(env)

    missing: list[str] = []
    built: dict[str, object] = {}
    factories: tuple[tuple[str, Callable[[], object]], ...] = (
        ("stt", lambda: create_google_stt(env, credentials=google_credentials)),
        ("llm", lambda: _build_llm_for(provider, env)),
        (
            "tts",
            lambda: build_elevenlabs_tts(
                env, voice_id=persona.voice_id if persona else None
            ),
        ),
    )
    for name, factory in factories:
        try:
            built[name] = factory()
        except MissingConfigurationError as exc:
            missing.extend(exc.missing)

    if missing:
        raise MissingConfigurationError(missing)

    return AgentSession(
        stt=built["stt"],
        llm=built["llm"],
        tts=built["tts"],
        turn_handling=TURN_HANDLING,
    )


def attach_observability(session: AgentSession) -> None:
    """Registra errores y cierre de la sesion SIN exponer datos sensibles.

    Solo se registran categoria, etiqueta del proveedor, nombre de la clase de
    la excepcion y si es recuperable. Nunca el mensaje ni el detalle de la
    excepcion, que podrian contener credenciales o contenido del usuario.

    Tambien engancha el recolector local de metricas de latencia
    (``metrics.attach_metrics``, DART-14-3.1), que solo registra tiempos y
    contadores numericos.
    """

    attach_metrics(session)

    @session.on("error")
    def _on_error(ev: ErrorEvent) -> None:
        err = ev.error
        logger.error(
            "Error de sesion: tipo=%s origen=%s excepcion=%s recuperable=%s",
            getattr(err, "type", "desconocido"),
            getattr(err, "label", "desconocido"),
            type(getattr(err, "error", err)).__name__,
            getattr(err, "recoverable", None),
        )

    @session.on("close")
    def _on_close(ev: CloseEvent) -> None:
        logger.info("Sesion cerrada: motivo=%s", getattr(ev.reason, "value", ev.reason))
