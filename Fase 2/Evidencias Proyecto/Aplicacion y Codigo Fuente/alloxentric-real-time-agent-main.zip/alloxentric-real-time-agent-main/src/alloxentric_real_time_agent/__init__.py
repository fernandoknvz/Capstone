"""Alloxentric Real Time Agent.

Base de entorno Python/LiveKit del proyecto (ticket DART_14-1.5), con los
componentes LLM (DeepSeek, ``llm.py``) y TTS (ElevenLabs, ``tts.py``) de
DART_14-1.6 invocables de forma aislada. STT (Speechmatics) y el pipeline
conversacional E2E siguen PENDIENTE (ver CLAUDE.md, seccion 6).
"""

__version__ = "0.1.0"
