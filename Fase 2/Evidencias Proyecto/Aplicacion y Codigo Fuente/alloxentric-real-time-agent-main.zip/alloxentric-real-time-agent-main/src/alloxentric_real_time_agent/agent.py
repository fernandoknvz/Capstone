"""Entrypoint de LiveKit Agents.

DART_14-1.5 definio el patron ``AgentServer`` / ``@server.rtc_session``
(https://docs.livekit.io/agents/start/voice-ai, verificado contra
livekit-agents==1.8.4). DART-14-2.4 conecta a ese entrypoint la
``AgentSession`` compuesta en ``pipeline.py``:
STT (Chirp 3) -> LLM (Gemini o DeepSeek) -> TTS (ElevenLabs).

ADC se resuelve durante el setup/prewarm de cada runner y se conserva en su
``JobProcess.userdata``. El resto de la configuracion se valida al llegar un
job real. Este modulo no abre conexiones de red al importarse.
"""

from __future__ import annotations

import logging

from dotenv import load_dotenv
from livekit import agents
from livekit.agents import AgentServer, JobProcess

from alloxentric_real_time_agent.config import load_livekit_settings, resolve_agent_name
from alloxentric_real_time_agent.pipeline import (
    attach_observability,
    build_agent,
    build_agent_session,
)
from alloxentric_real_time_agent.personas import persona_from_job_metadata
from alloxentric_real_time_agent.stt import resolve_google_adc
from alloxentric_real_time_agent.voice_warmup import start_voice_warmup

# Carga variables de entorno locales si existen (no se versionan, ver
# .gitignore y docs/GIT_WORKFLOW.md, seccion "Tratamiento de secretos").
load_dotenv(".env.local")
load_dotenv(".env")

logger = logging.getLogger("alloxentric_real_time_agent")

GOOGLE_ADC_USERDATA_KEY = "google_adc_credentials"


def setup_process(proc: JobProcess) -> None:
    """Resuelve ADC antes del event loop y lo guarda en el runner."""

    proc.userdata[GOOGLE_ADC_USERDATA_KEY] = resolve_google_adc()
    # La primera sintesis de cada voz tarda 4-6 s; se precalientan en segundo
    # plano para que el saludo de cada agente no llegue tarde (no bloquea).
    start_voice_warmup()


# Este timeout corresponde solo a la inicializacion/prewarm del runner. La
# resolucion local mediante Google Cloud CLI supero 10 s en una medicion real;
# el margen evita que el setup correcto expire con el default de 10 s.
server = AgentServer(setup_fnc=setup_process, initialize_process_timeout=30.0)


# El nombre se resuelve al importar (tras load_dotenv): por defecto es el de la
# Web Demo publicada; un worker de desarrollo define LIVEKIT_AGENT_NAME en su
# propio proceso para no atender sus despachos (DART-14-5.1).
@server.rtc_session(agent_name=resolve_agent_name())
async def entrypoint(ctx: agents.JobContext) -> None:
    """Inicia la sesion usando las credenciales resueltas por el runner."""

    # Falla rapido y con un mensaje comprensible si falta configuracion.
    load_livekit_settings()
    # La persona llega en el metadato de despacho que fija el servidor de
    # tokens (solo un identificador de una lista cerrada); si falta o es
    # invalido se usa el agente de prueba.
    persona = persona_from_job_metadata(ctx.job.metadata)
    session = build_agent_session(
        google_credentials=ctx.proc.userdata[GOOGLE_ADC_USERDATA_KEY],
        persona=persona,
    )
    attach_observability(session)

    # Con ``room=`` la sesion usa RoomIO y conecta el job a la sala por si
    # misma (verificado en livekit-agents 1.8.4). ``ctx.connect()`` es
    # idempotente (retorna si ya esta conectado), por lo que la llamada
    # explicita es redundante pero inocua y deja clara la intencion.
    #
    # ``record=False``: sin ella el SDK delega en el ajuste del servidor
    # (``job.enable_recording``). Se desactiva de forma explicita para las
    # pruebas de desarrollo (audio, transcripcion, trazas y logs de la sesion).
    await session.start(build_agent(persona), room=ctx.room, record=False)
    await ctx.connect()
    logger.info(
        "Pipeline de voz iniciado en la sala '%s' (persona=%s).",
        ctx.room.name,
        persona.id if persona else "prueba",
    )
    if persona is not None:
        # TTS directo, sin pasar por el LLM: el saludo es lo mas rapido posible.
        session.say(persona.greeting)


def run() -> None:
    """Punto de entrada usado por el script de consola `alloxentric-agent`."""

    agents.cli.run_app(server)


if __name__ == "__main__":
    run()
