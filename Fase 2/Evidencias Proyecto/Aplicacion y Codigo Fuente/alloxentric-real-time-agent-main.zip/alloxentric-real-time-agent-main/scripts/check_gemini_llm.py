"""Verificacion manual y real: texto sintetico -> Gemini -> respuesta (DART-14-2.1).

NO es un test automatizado y NO se ejecuta con `pytest` (ver
tests/test_llm_gemini.py para las pruebas sin red). Hace UNA unica solicitud
real y breve a la Gemini Developer API, que puede generar un costo minimo
segun el plan de la cuenta de Google.

Uso:
    1. Define GOOGLE_API_KEY en tu .env.local (nunca lo commitees).
    2. py -3.12 -m uv run python scripts/check_gemini_llm.py

Usa solo texto sintetico. No imprime la API key; imprime modelo, latencias,
tokens informados por la API (si los informa) y la respuesta.
"""

from __future__ import annotations

import asyncio
import sys
import time

from dotenv import load_dotenv
from livekit.agents import APIConnectOptions
from livekit.agents.llm import ChatContext

from alloxentric_real_time_agent.config import MissingConfigurationError, load_gemini_settings
from alloxentric_real_time_agent.llm_gemini import build_gemini_llm

load_dotenv(".env.local")
load_dotenv(".env")

PROMPT = "Responde en una sola frase corta: ¿qué es LiveKit?"


async def main() -> int:
    """Devuelve 0 si la solicitud tuvo exito y 1 si fallo o falta configuracion."""

    try:
        settings = load_gemini_settings()
    except MissingConfigurationError as exc:
        print(f"[CONFIGURACION FALTANTE] {exc}")
        return 1

    llm = build_gemini_llm()

    chat_ctx = ChatContext.empty()
    chat_ctx.add_message(role="user", content=PROMPT)

    print(f"Modelo solicitado: {settings.model}")
    print("Enviando una unica solicitud real a la Gemini Developer API...")

    started_at = time.monotonic()
    first_token_at: float | None = None
    chunks: list[str] = []
    usage = None

    try:
        # max_retry=0: el default del SDK reintenta hasta 3 veces; aqui debe
        # hacerse una unica solicitud real.
        async with llm.chat(
            chat_ctx=chat_ctx,
            conn_options=APIConnectOptions(max_retry=0, timeout=30.0),
        ) as stream:
            async for chunk in stream:
                if first_token_at is None:
                    first_token_at = time.monotonic()
                if chunk.delta and chunk.delta.content:
                    chunks.append(chunk.delta.content)
                if chunk.usage is not None:
                    usage = chunk.usage
    except Exception as exc:  # noqa: BLE001 - reportar cualquier error de la API
        elapsed = time.monotonic() - started_at
        print(f"[ERROR] La llamada a Gemini fallo despues de {elapsed:.2f}s.")
        print(f"[ERROR] Tipo: {type(exc).__name__}")
        # No se imprime la API key: solo el mensaje de la excepcion.
        print(f"[ERROR] Detalle: {exc}")
        print(
            "Si el error indica modelo invalido/no encontrado, revisa "
            "GEMINI_MODEL contra https://ai.google.dev/gemini-api/docs/models"
        )
        return 1

    total_elapsed = time.monotonic() - started_at
    ttft = (first_token_at - started_at) if first_token_at else None

    print("\n--- Resultado ---")
    print(f"Modelo usado:         {settings.model}")
    print(f"Latencia total:       {total_elapsed:.2f}s")
    if ttft is not None:
        print(f"Latencia 1er token:   {ttft:.2f}s")
    if usage is not None:
        print(
            "Tokens (prompt/completion/total): "
            f"{usage.prompt_tokens}/{usage.completion_tokens}/{usage.total_tokens}"
        )
    else:
        print("Tokens: la API no informo 'usage' en el stream.")
    print(f"Respuesta: {''.join(chunks).strip()!r}")
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
