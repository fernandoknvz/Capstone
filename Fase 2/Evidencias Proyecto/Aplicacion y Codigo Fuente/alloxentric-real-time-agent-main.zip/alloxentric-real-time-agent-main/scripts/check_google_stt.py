"""Verificacion manual y real de bajo costo: audio -> Google Chirp 3 -> texto.

Este script NO es un test automatizado y NO se ejecuta con `pytest` (ver
tests/test_stt.py para las pruebas que no consumen la API real). Envia UN
audio corto a Google Speech-to-Text (chirp_3) usando el mismo objeto STT que
recibiria `AgentSession(stt=...)`.

Prerrequisitos (ver README): Google Cloud CLI, ADC configuradas con tu cuenta
(`gcloud auth application-default login`) y GOOGLE_CLOUD_PROJECT en .env.local.

Uso:
    uv run python scripts/check_google_stt.py ruta/audio.wav

El WAV debe ser PCM 16-bit, mono, 16 kHz, con una frase NO sensible. Se envia
en tiempo real (frames de 20 ms) mas 2 s de silencio final para que el
servicio cierre el turno. Imprime cada evento (parcial/final) con el tiempo
transcurrido desde el inicio del envio, y la duracion del audio.

Codigo de salida: 0 si llego una transcripcion final con texto; 1 si la
solicitud fallo o no hubo transcripcion final; 2 si el WAV o la configuracion
son invalidos. Ante errores solo se imprime el tipo de excepcion (y su codigo
de estado), nunca el mensaje del proveedor.

No imprime credenciales. Google no informa consumo por llamada: el costo se
revisa en la consola de facturacion (aprox. segun la duracion de audio).
"""

from __future__ import annotations

import asyncio
import logging
import sys
import time
import wave

from dotenv import load_dotenv
from livekit import rtc
from livekit.agents import stt

from alloxentric_real_time_agent.config import MissingConfigurationError
from alloxentric_real_time_agent.stt import MissingCredentialsError, create_google_stt

load_dotenv(".env.local")
load_dotenv(".env")

# El plugin registra el mensaje completo del proveedor al reintentar (puede
# incluir endpoints o detalles de la solicitud). Este script solo muestra el
# tipo de error, asi que se silencian los loggers de LiveKit.
for _name in ("livekit", "livekit.agents", "livekit.plugins.google"):
    logging.getLogger(_name).setLevel(logging.CRITICAL)

FRAME_MS = 20
TAIL_SILENCE_S = 2


#: Codigos de salida: 0 = transcripcion final recibida; 1 = fallo de la
#: solicitud o sin transcripcion final; 2 = entrada o configuracion invalida.
EXIT_OK = 0
EXIT_REQUEST_FAILED = 1
EXIT_BAD_INPUT_OR_CONFIG = 2


def _safe_error(exc: BaseException) -> str:
    """Describe un error SIN reproducir el mensaje del proveedor.

    Los mensajes de Google pueden incluir identificadores de proyecto, rutas
    de recursos o detalles de la solicitud; solo se muestran el tipo y, si
    existe, el codigo de estado HTTP.
    """

    status = getattr(exc, "status_code", None)
    return f"{type(exc).__name__}" + (f" (status {status})" if status else "")


async def main(path: str) -> int:
    try:
        with wave.open(path, "rb") as wav:
            if (wav.getframerate(), wav.getnchannels(), wav.getsampwidth()) != (16000, 1, 2):
                print("[ENTRADA INVALIDA] El WAV debe ser PCM 16-bit, mono, 16000 Hz.")
                return EXIT_BAD_INPUT_OR_CONFIG
            pcm = wav.readframes(wav.getnframes())
    except (OSError, EOFError, wave.Error):
        print("[ENTRADA INVALIDA] No se pudo leer el archivo WAV indicado.")
        return EXIT_BAD_INPUT_OR_CONFIG

    try:
        google_stt = create_google_stt()
    except (MissingConfigurationError, MissingCredentialsError) as exc:
        # Estos mensajes son propios del proyecto (no del proveedor).
        print(f"[CONFIGURACION FALTANTE] {exc}")
        return EXIT_BAD_INPUT_OR_CONFIG

    cfg = google_stt._config
    print(f"Modelo:    {google_stt.model}")
    print(f"Idioma:    {[str(lang) for lang in cfg.languages]}")
    print(f"Ubicacion: {google_stt._location}")
    print(f"Duracion del audio: {len(pcm) / 32000:.2f}s (+{TAIL_SILENCE_S}s de silencio)")
    print("Enviando una unica solicitud real a Google Speech-to-Text...")

    samples = 16000 * FRAME_MS // 1000
    step = samples * 2
    data = pcm + b"\x00" * 32000 * TAIL_SILENCE_S
    t0 = time.monotonic()
    audio_end_at: float | None = None
    first_event_at: float | None = None
    final_at: float | None = None
    finals: list[str] = []

    stream = google_stt.stream()

    async def send() -> None:
        nonlocal audio_end_at
        for i in range(0, len(data), step):
            chunk = data[i : i + step].ljust(step, b"\x00")
            stream.push_frame(rtc.AudioFrame(chunk, 16000, 1, samples))
            # Reloj absoluto: evita acumular deriva (sleep en Windows ~15 ms).
            await asyncio.sleep(max(0.0, t0 + (i // step + 1) * FRAME_MS / 1000 - time.monotonic()))
            if audio_end_at is None and i + step >= len(pcm):
                audio_end_at = time.monotonic() - t0
        stream.end_input()

    async def receive() -> None:
        nonlocal first_event_at, final_at
        async for ev in stream:
            now = time.monotonic() - t0
            if ev.type in (
                stt.SpeechEventType.INTERIM_TRANSCRIPT,
                stt.SpeechEventType.FINAL_TRANSCRIPT,
            ):
                text = ev.alternatives[0].text if ev.alternatives else ""
                print(f"[{now:6.2f}s] {ev.type.name}: {text!r}")
                first_event_at = first_event_at or now
                if ev.type == stt.SpeechEventType.FINAL_TRANSCRIPT:
                    final_at = now
                    finals.append(text)
            else:
                print(f"[{now:6.2f}s] {ev.type.name}")

    sender = asyncio.create_task(send())
    try:
        await asyncio.wait_for(receive(), timeout=60)
        await sender
    except Exception as exc:  # noqa: BLE001 - cualquier fallo de la solicitud
        print(f"[ERROR] La solicitud a Google Speech-to-Text fallo: {_safe_error(exc)}")
        print(
            "[ERROR] Revisa ADC, el rol 'Cliente de Cloud Speech', que la API este "
            "habilitada y GOOGLE_CLOUD_PROJECT / GOOGLE_STT_LOCATION / GOOGLE_STT_LANGUAGE."
        )
        sender.cancel()
        return EXIT_REQUEST_FAILED
    finally:
        await stream.aclose()
        await google_stt.aclose()

    transcript = " ".join(finals).strip()
    print("\n--- Resultado ---")
    print(f"Transcripcion final: {transcript!r}")
    if first_event_at is not None:
        print(f"Primer evento (parcial/final): {first_event_at:.2f}s desde el inicio del envio")
    if final_at is not None and audio_end_at is not None:
        print(
            f"Fin del habla enviado en {audio_end_at:.2f}s; ultimo final en {final_at:.2f}s "
            f"(~{final_at - audio_end_at:.2f}s tras el fin del habla)"
        )

    if final_at is None or not transcript:
        print("[ERROR] No se recibio una transcripcion final con texto.")
        return EXIT_REQUEST_FAILED
    return EXIT_OK


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print(__doc__)
        sys.exit(EXIT_BAD_INPUT_OR_CONFIG)
    sys.exit(asyncio.run(main(sys.argv[1])))
