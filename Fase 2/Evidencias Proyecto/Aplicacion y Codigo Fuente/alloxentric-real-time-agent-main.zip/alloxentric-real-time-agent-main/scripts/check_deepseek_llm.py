"""Verificacion manual, real y de bajo costo: texto -> DeepSeek -> respuesta.

Este script NO es un test automatizado y NO se ejecuta con `pytest`
(ver tests/test_llm.py para las pruebas que no consumen la API real).
Hace una unica llamada real a la API de DeepSeek para demostrar
tecnicamente el contrato de DART_14-1.6.

Uso:
    1. Completa DEEPSEEK_API_KEY en tu .env.local (nunca lo commitees).
    2. uv run python scripts/check_deepseek_llm.py

No imprime la API key ni ningun otro secreto. Imprime: modelo usado,
latencia aproximada, tokens informados por la API (si los informa) y la
respuesta de texto generada.
"""

from __future__ import annotations

import asyncio
import time

from dotenv import load_dotenv
from livekit.agents.llm import ChatContext

from alloxentric_real_time_agent.config import MissingConfigurationError, load_deepseek_settings
from alloxentric_real_time_agent.llm import build_deepseek_llm

load_dotenv(".env.local")
load_dotenv(".env")


async def main() -> None:
    try:
        settings = load_deepseek_settings()
    except MissingConfigurationError as exc:
        print(f"[CONFIGURACION FALTANTE] {exc}")
        return

    llm = build_deepseek_llm()

    chat_ctx = ChatContext.empty()
    chat_ctx.add_message(
        role="user",
        content="Responde en una sola frase corta: ¿qué es LiveKit?",
    )

    print(f"Modelo solicitado: {settings.model}")
    print("Enviando una unica solicitud real a la API de DeepSeek...")

    started_at = time.monotonic()
    first_token_at: float | None = None
    chunks: list[str] = []
    usage = None

    try:
        async with llm.chat(chat_ctx=chat_ctx) as stream:
            async for chunk in stream:
                if first_token_at is None:
                    first_token_at = time.monotonic()
                if chunk.delta and chunk.delta.content:
                    chunks.append(chunk.delta.content)
                if chunk.usage is not None:
                    usage = chunk.usage
    except Exception as exc:  # noqa: BLE001 - queremos reportar cualquier error de la API tal cual
        elapsed = time.monotonic() - started_at
        print(f"[ERROR] La llamada a DeepSeek fallo despues de {elapsed:.2f}s.")
        print(f"[ERROR] Tipo: {type(exc).__name__}")
        print(f"[ERROR] Detalle: {exc}")
        print(
            "Si el error indica modelo invalido/no encontrado, es evidencia "
            f"real de que '{settings.model}' ya no es un modelo valido en la "
            "API de DeepSeek (ver discrepancia 'DeepSeek Flash' en el informe "
            "de DART_14-1.6). Ajusta DEEPSEEK_MODEL y vuelve a ejecutar."
        )
        return

    total_elapsed = time.monotonic() - started_at
    ttft = (first_token_at - started_at) if first_token_at else None
    response_text = "".join(chunks).strip()

    print("\n--- Resultado ---")
    print(f"Modelo usado:         {settings.model}")
    print(f"Latencia total:       {total_elapsed:.2f}s")
    if ttft is not None:
        print(f"Latencia 1er token:   {ttft:.2f}s")
    if usage is not None:
        print(
            "Tokens (prompt/completion/total): "
            f"{usage.prompt_tokens}/{usage.completion_tokens}/{usage.total_tokens}"
        )
    else:
        print("Tokens: la API no informo 'usage' en el stream.")
    print(f"Respuesta: {response_text!r}")


if __name__ == "__main__":
    asyncio.run(main())
