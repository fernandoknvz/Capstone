"""Verificacion manual, real y de bajo costo: texto -> ElevenLabs -> audio.

Este script NO es un test automatizado y NO se ejecuta con `pytest`
(ver tests/test_tts.py para las pruebas que no consumen la API real).
Hace una unica sintesis real con ElevenLabs para demostrar tecnicamente el
contrato TTS de DART_14-1.6, usando el mismo objeto que recibiria
`AgentSession(tts=...)`.

Uso:
    1. Completa ELEVEN_API_KEY en tu .env.local (nunca lo commitees).
    2. uv run python scripts/check_elevenlabs_tts.py [--mode stream|http]
       [--text "..."] [--out ruta.wav]

`--mode stream` (default) usa `tts.stream()` (WebSocket de ElevenLabs, el
modo que usa AgentSession con un LLM en streaming). `--mode http` usa
`tts.synthesize()` (endpoint HTTP, texto completo).

No imprime la API key ni ningun otro secreto. Imprime: modelo, voz,
modo, latencia aproximada al primer audio y total, duracion del audio
recibido y, si la API key tiene permiso de lectura de usuario, los
caracteres consumidos segun la suscripcion de ElevenLabs.
"""

from __future__ import annotations

import argparse
import asyncio
import time
import wave
from pathlib import Path

import aiohttp
from dotenv import load_dotenv
from livekit import rtc

from alloxentric_real_time_agent.config import (
    ElevenLabsSettings,
    MissingConfigurationError,
    load_elevenlabs_settings,
)
from alloxentric_real_time_agent.tts import build_elevenlabs_tts

load_dotenv(".env.local")
load_dotenv(".env")

API_BASE_URL = "https://api.elevenlabs.io/v1"
DEFAULT_TEXT = "Hola, esta es una prueba breve de síntesis de voz."


async def _get_json(
    session: aiohttp.ClientSession, settings: ElevenLabsSettings, path: str
) -> tuple[int, dict | None]:
    async with session.get(
        f"{API_BASE_URL}{path}", headers={"xi-api-key": settings.api_key}
    ) as resp:
        body = await resp.json() if resp.status == 200 else None
        return resp.status, body


async def _character_count(
    session: aiohttp.ClientSession, settings: ElevenLabsSettings
) -> int | None:
    status, body = await _get_json(session, settings, "/user/subscription")
    if status != 200 or body is None:
        return None
    return body.get("character_count")


async def main(mode: str, text: str, out: Path | None) -> None:
    try:
        settings = load_elevenlabs_settings()
    except MissingConfigurationError as exc:
        print(f"[CONFIGURACION FALTANTE] {exc}")
        return

    async with aiohttp.ClientSession() as session:
        status, voice = await _get_json(session, settings, f"/voices/{settings.voice_id}")
        if status == 200 and voice is not None:
            voice_desc = f"{voice.get('name')!r} (categoria: {voice.get('category')})"
        else:
            voice_desc = (
                f"no verificable (HTTP {status}; la API key puede no tener "
                "permiso de lectura de voces)"
            )

        chars_before = await _character_count(session, settings)

        tts = build_elevenlabs_tts(http_session=session)
        print(f"Modelo:  {settings.model}")
        print(f"Voz:     {settings.voice_id} -> {voice_desc}")
        print(f"Modo:    {mode} (plugin streaming={tts.capabilities.streaming})")
        print(f"Texto:   {text!r} ({len(text)} caracteres)")
        print("Enviando una unica solicitud real a ElevenLabs...")

        frames: list[rtc.AudioFrame] = []
        started_at = time.monotonic()
        first_audio_at: float | None = None

        try:
            if mode == "stream":
                stream = tts.stream()
                stream.push_text(text)
                stream.end_input()
            else:
                stream = tts.synthesize(text)

            async with stream:
                async for event in stream:
                    if first_audio_at is None:
                        first_audio_at = time.monotonic()
                    frames.append(event.frame)
        except Exception as exc:  # noqa: BLE001 - queremos reportar cualquier error de la API tal cual
            elapsed = time.monotonic() - started_at
            print(f"[ERROR] La sintesis con ElevenLabs fallo despues de {elapsed:.2f}s.")
            print(f"[ERROR] Tipo: {type(exc).__name__}")
            print(f"[ERROR] Detalle: {exc}")
            return
        finally:
            await tts.aclose()

        total_elapsed = time.monotonic() - started_at
        chars_after = await _character_count(session, settings)

    print("\n--- Resultado ---")
    if not frames:
        print("[ERROR] ElevenLabs no devolvio audio.")
        return

    audio = rtc.combine_audio_frames(frames)
    duration = audio.samples_per_channel / audio.sample_rate
    print(f"Frames de audio:      {len(frames)}")
    print(
        f"Formato:              PCM 16-bit, {audio.sample_rate} Hz, "
        f"{audio.num_channels} canal(es)"
    )
    print(f"Duracion del audio:   {duration:.2f}s")
    print(f"Latencia 1er audio:   {first_audio_at - started_at:.2f}s")
    print(f"Latencia total:       {total_elapsed:.2f}s")
    if chars_before is not None and chars_after is not None:
        print(
            f"Caracteres consumidos (suscripcion): {chars_after - chars_before} "
            f"(contador {chars_before} -> {chars_after})"
        )
    else:
        print(
            "Consumo: no informado (la API key no tiene permiso de lectura de "
            "usuario, o la API no lo devolvio)."
        )

    if out is not None:
        out.parent.mkdir(parents=True, exist_ok=True)
        with wave.open(str(out), "wb") as wav:
            wav.setnchannels(audio.num_channels)
            wav.setsampwidth(2)
            wav.setframerate(audio.sample_rate)
            wav.writeframes(audio.data.tobytes())
        print(f"Audio guardado en:    {out}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--mode", choices=("stream", "http"), default="stream")
    parser.add_argument("--text", default=DEFAULT_TEXT)
    parser.add_argument("--out", type=Path, default=None, help="Ruta .wav opcional")
    args = parser.parse_args()
    asyncio.run(main(args.mode, args.text, args.out))
