"""Pruebas de la integracion Gemini (DART-14-2.1).

Ninguna llama a la API real: usan una API key ficticia y la construccion del
LLM es perezosa. La llamada real se verifica manualmente con
scripts/check_gemini_llm.py.
"""

import socket

import pytest
from livekit.agents.llm import LLM as BaseLLM

from alloxentric_real_time_agent.config import (
    DEFAULT_GEMINI_MODEL,
    REQUIRED_GEMINI_VARS,
    MissingConfigurationError,
    load_gemini_settings,
)
from alloxentric_real_time_agent.llm import build_deepseek_llm
from alloxentric_real_time_agent.llm_gemini import build_gemini_llm

FAKE_KEY = "fake-google-key-1234567890"


def test_required_gemini_var_is_google_api_key():
    assert REQUIRED_GEMINI_VARS == ("GOOGLE_API_KEY",)


def test_load_gemini_settings_uses_default_model_when_not_set():
    settings = load_gemini_settings({"GOOGLE_API_KEY": FAKE_KEY})

    assert settings.api_key == FAKE_KEY
    assert settings.model == DEFAULT_GEMINI_MODEL


def test_load_gemini_settings_respects_model_override():
    settings = load_gemini_settings(
        {"GOOGLE_API_KEY": FAKE_KEY, "GEMINI_MODEL": "gemini-3.5-flash-lite"}
    )

    assert settings.model == "gemini-3.5-flash-lite"


def test_empty_model_override_falls_back_to_default():
    settings = load_gemini_settings({"GOOGLE_API_KEY": FAKE_KEY, "GEMINI_MODEL": ""})

    assert settings.model == DEFAULT_GEMINI_MODEL


@pytest.mark.parametrize("env", [{}, {"GOOGLE_API_KEY": ""}, {"GEMINI_MODEL": "x"}])
def test_load_gemini_settings_raises_when_api_key_missing_or_empty(env):
    with pytest.raises(MissingConfigurationError) as exc_info:
        load_gemini_settings(env)

    assert exc_info.value.missing == list(REQUIRED_GEMINI_VARS)


def test_gemini_settings_repr_never_exposes_api_key():
    settings = load_gemini_settings({"GOOGLE_API_KEY": FAKE_KEY})

    assert FAKE_KEY not in repr(settings)
    assert FAKE_KEY not in str(settings)


def test_missing_configuration_error_does_not_leak_other_values():
    with pytest.raises(MissingConfigurationError) as exc_info:
        build_gemini_llm({"GEMINI_MODEL": "gemini-x", "DEEPSEEK_API_KEY": FAKE_KEY})

    assert FAKE_KEY not in str(exc_info.value)


def test_build_gemini_llm_raises_clear_error_without_api_key():
    with pytest.raises(MissingConfigurationError):
        build_gemini_llm({})


def test_build_gemini_llm_returns_an_agent_session_compatible_llm():
    llm = build_gemini_llm({"GOOGLE_API_KEY": FAKE_KEY})

    assert isinstance(llm, BaseLLM)
    assert llm.model == DEFAULT_GEMINI_MODEL
    assert llm.provider == "Gemini"


def test_build_gemini_llm_does_not_depend_on_plugin_default_model():
    llm = build_gemini_llm({"GOOGLE_API_KEY": FAKE_KEY})

    assert llm.model != "gemini-2.5-flash"


def test_build_gemini_llm_respects_model_override_end_to_end():
    llm = build_gemini_llm(
        {"GOOGLE_API_KEY": FAKE_KEY, "GEMINI_MODEL": "gemini-3.5-flash-lite"}
    )

    assert llm.model == "gemini-3.5-flash-lite"


def test_build_gemini_llm_never_touches_the_network(monkeypatch):
    def _blocked(*_args, **_kwargs):
        raise AssertionError("No se esperaba acceso a la red al construir el LLM")

    monkeypatch.setattr(socket, "socket", _blocked)

    build_gemini_llm({"GOOGLE_API_KEY": FAKE_KEY})


def test_deepseek_and_gemini_builders_coexist_independently():
    deepseek = build_deepseek_llm({"DEEPSEEK_API_KEY": "fake-key"})
    gemini = build_gemini_llm({"GOOGLE_API_KEY": FAKE_KEY})

    assert deepseek.model == "deepseek-flash"
    assert gemini.model == DEFAULT_GEMINI_MODEL
    assert type(deepseek) is not type(gemini)
