"""Pruebas de la integracion ElevenLabs TTS (DART_14-1.6).

Ninguna de estas pruebas hace una llamada real a la API de ElevenLabs: usan
una API key ficticia solo para verificar que el componente TTS se
construye y se configura correctamente (la construccion es perezosa, sin
red). La sintesis real de bajo costo se verifica manualmente con
scripts/check_elevenlabs_tts.py.
"""

import socket

import pytest
from livekit.agents.tts import TTS as BaseTTS
from livekit.plugins import elevenlabs

from alloxentric_real_time_agent.config import (
    DEFAULT_ELEVENLABS_TTS_MODEL,
    DEFAULT_ELEVENLABS_VOICE_ID,
    REQUIRED_ELEVENLABS_VARS,
    MissingConfigurationError,
    load_elevenlabs_settings,
)
from alloxentric_real_time_agent.tts import build_elevenlabs_tts

FAKE_ENV = {"ELEVEN_API_KEY": "fake-key"}


def test_required_elevenlabs_var_is_the_one_read_by_the_plugin():
    """El plugin de LiveKit lee ELEVEN_API_KEY (no ELEVENLABS_API_KEY)."""

    assert REQUIRED_ELEVENLABS_VARS == ("ELEVEN_API_KEY",)


def test_default_elevenlabs_model_is_eleven_v4_turbo():
    """Valor literal: el default del plugin ("eleven_turbo_v2_5") esta deprecado."""

    assert DEFAULT_ELEVENLABS_TTS_MODEL == "eleven_v4_turbo"


def test_load_elevenlabs_settings_uses_defaults_when_not_set():
    settings = load_elevenlabs_settings(FAKE_ENV)

    assert settings.api_key == "fake-key"
    assert settings.model == DEFAULT_ELEVENLABS_TTS_MODEL
    assert settings.voice_id == DEFAULT_ELEVENLABS_VOICE_ID


def test_load_elevenlabs_settings_respects_model_and_voice_overrides():
    settings = load_elevenlabs_settings(
        {**FAKE_ENV, "ELEVEN_TTS_MODEL": "eleven_v4_turbo", "ELEVEN_VOICE_ID": "voice-123"}
    )

    assert settings.model == "eleven_v4_turbo"
    assert settings.voice_id == "voice-123"


@pytest.mark.parametrize("env", [{}, {"ELEVEN_API_KEY": ""}])
def test_load_elevenlabs_settings_raises_when_api_key_missing_or_empty(env):
    with pytest.raises(MissingConfigurationError) as exc_info:
        load_elevenlabs_settings(env)

    assert exc_info.value.missing == ["ELEVEN_API_KEY"]
    assert "ELEVEN_API_KEY" in str(exc_info.value)


def test_load_elevenlabs_settings_ignores_unrelated_provider_keys():
    """La key de otro proveedor no debe satisfacer la de ElevenLabs."""

    with pytest.raises(MissingConfigurationError):
        load_elevenlabs_settings({"ELEVENLABS_API_KEY": "x", "DEEPSEEK_API_KEY": "y"})


def test_elevenlabs_settings_repr_never_exposes_api_key():
    settings = load_elevenlabs_settings({"ELEVEN_API_KEY": "super-secret-value"})

    assert "super-secret-value" not in repr(settings)


def test_build_elevenlabs_tts_raises_clear_error_without_api_key(monkeypatch):
    # Aunque el proceso tuviera la variable real, la validacion usa `env`.
    monkeypatch.delenv("ELEVEN_API_KEY", raising=False)

    with pytest.raises(MissingConfigurationError):
        build_elevenlabs_tts({})


def test_build_elevenlabs_tts_returns_an_agent_session_compatible_tts():
    tts = build_elevenlabs_tts(FAKE_ENV)

    # AgentSession(tts=...) solo exige esta base comun.
    assert isinstance(tts, BaseTTS)
    assert isinstance(tts, elevenlabs.TTS)
    assert tts.provider == "ElevenLabs"


def test_build_elevenlabs_tts_supports_streaming():
    tts = build_elevenlabs_tts(FAKE_ENV)

    assert tts.capabilities.streaming is True
    assert tts.num_channels == 1
    assert tts.sample_rate > 0


def test_build_elevenlabs_tts_passes_model_and_voice_explicitly():
    """Nunca usar el default del plugin ("eleven_turbo_v2_5", deprecado)."""

    tts = build_elevenlabs_tts(FAKE_ENV)

    assert tts.model == "eleven_v4_turbo"
    assert tts.model != "eleven_turbo_v2_5"
    assert tts._opts.voice_id == DEFAULT_ELEVENLABS_VOICE_ID
    assert tts._opts.api_key == "fake-key"


def test_build_elevenlabs_tts_respects_overrides_end_to_end():
    tts = build_elevenlabs_tts(
        {**FAKE_ENV, "ELEVEN_TTS_MODEL": "eleven_multilingual_v2", "ELEVEN_VOICE_ID": "voice-123"}
    )

    assert tts.model == "eleven_multilingual_v2"
    assert tts._opts.voice_id == "voice-123"


def test_build_elevenlabs_tts_never_touches_the_network(monkeypatch):
    """Construir el TTS no debe abrir ninguna conexion de red.

    Si esto falla, el plugin dejo de ser perezoso en una version futura y
    los tests empezarian a depender de red/creditos reales sin decidirlo.
    """

    def _blocked(*_args, **_kwargs):
        raise AssertionError("No se esperaba acceso a la red al construir el TTS")

    monkeypatch.setattr(socket, "socket", _blocked)

    build_elevenlabs_tts(FAKE_ENV)
