"""Nombre de despacho del worker configurable (DART-14-5.1).

Cubre ``config.resolve_agent_name`` y el registro de ``agent.server``. No abre
conexiones de red ni inicia un worker.
"""

from __future__ import annotations

import importlib

import pytest

from alloxentric_real_time_agent import agent as agent_module
from alloxentric_real_time_agent.config import (
    DEFAULT_AGENT_NAME,
    InvalidConfigurationError,
    resolve_agent_name,
)
from alloxentric_real_time_agent.personas import PERSONAS, persona_from_job_metadata


def test_agent_name_defaults_to_the_published_one():
    assert DEFAULT_AGENT_NAME == "alloxentric-real-time-agent"
    assert resolve_agent_name({}) == DEFAULT_AGENT_NAME
    assert resolve_agent_name({"LIVEKIT_AGENT_NAME": ""}) == DEFAULT_AGENT_NAME
    assert resolve_agent_name({"LIVEKIT_AGENT_NAME": "  "}) == DEFAULT_AGENT_NAME


def test_agent_name_can_be_overridden_for_development():
    env = {"LIVEKIT_AGENT_NAME": "alloxentric-real-time-agent-dev"}
    assert resolve_agent_name(env) == "alloxentric-real-time-agent-dev"
    assert resolve_agent_name(env) != DEFAULT_AGENT_NAME


def test_agent_name_accepts_surrounding_whitespace_and_max_length():
    assert resolve_agent_name({"LIVEKIT_AGENT_NAME": " dev-1 "}) == "dev-1"
    assert resolve_agent_name({"LIVEKIT_AGENT_NAME": "a" * 63}) == "a" * 63


@pytest.mark.parametrize(
    "value",
    ["Agente Dev", "-dev", "a_b", "a" * 64, "x/../y", "dev\nx", "valor-sensible-12345!"],
)
def test_invalid_agent_name_fails_fast_without_leaking_the_value(value):
    with pytest.raises(InvalidConfigurationError) as excinfo:
        resolve_agent_name({"LIVEKIT_AGENT_NAME": value})
    assert value.strip() not in str(excinfo.value)


def _reload_agent(monkeypatch, env_value):
    """Reimporta ``agent`` para ver con que nombre se registra el server."""

    monkeypatch.delenv("LIVEKIT_AGENT_NAME_OVERRIDE", raising=False)
    if env_value is None:
        monkeypatch.delenv("LIVEKIT_AGENT_NAME", raising=False)
    else:
        monkeypatch.setenv("LIVEKIT_AGENT_NAME", env_value)
    return importlib.reload(agent_module)


@pytest.fixture
def restore_agent_module(monkeypatch):
    yield
    monkeypatch.delenv("LIVEKIT_AGENT_NAME", raising=False)
    monkeypatch.delenv("LIVEKIT_AGENT_NAME_OVERRIDE", raising=False)
    importlib.reload(agent_module)


def test_server_registers_with_the_default_name(monkeypatch, restore_agent_module):
    reloaded = _reload_agent(monkeypatch, None)
    assert reloaded.server._agent_name == "alloxentric-real-time-agent"


def test_server_registers_with_the_configured_name(monkeypatch, restore_agent_module):
    reloaded = _reload_agent(monkeypatch, "alloxentric-real-time-agent-dev")
    assert reloaded.server._agent_name == "alloxentric-real-time-agent-dev"


def test_server_refuses_to_register_with_an_invalid_name(monkeypatch, restore_agent_module):
    with pytest.raises(InvalidConfigurationError) as excinfo:
        _reload_agent(monkeypatch, "Nombre Invalido!")
    assert "Nombre Invalido" not in str(excinfo.value)


def test_persona_metadata_contract_is_unchanged_by_the_agent_name(monkeypatch, restore_agent_module):
    _reload_agent(monkeypatch, "alloxentric-real-time-agent-dev")
    for persona_id, persona in PERSONAS.items():
        assert persona_from_job_metadata(f'{{"persona":"{persona_id}"}}') is persona
    assert persona_from_job_metadata('{"scenario":"clinica-dental"}') is None
