"""Pruebas del STT de Google Chirp 3 (DART_14-2.2).

Ninguna hace llamadas de red ni usa credenciales reales: las ADC se simulan
(la construccion del plugin es perezosa). No demuestran rendimiento real del
proveedor; eso se verifica manualmente con scripts/check_google_stt.py.
"""

import socket

from google.auth.exceptions import DefaultCredentialsError
import pytest
from livekit.agents import stt as lk_stt
from livekit.plugins import google
from livekit.plugins.google import stt as google_stt_module

from alloxentric_real_time_agent.config import (
    DEFAULT_GOOGLE_STT_LANGUAGE,
    DEFAULT_GOOGLE_STT_LOCATION,
    GOOGLE_STT_MODEL,
    REQUIRED_GOOGLE_STT_VARS,
    MissingConfigurationError,
    load_google_stt_settings,
)
from alloxentric_real_time_agent.stt import (
    MissingCredentialsError,
    build_google_stt,
    create_google_stt,
    resolve_google_adc,
)

ENV = {"GOOGLE_CLOUD_PROJECT": "my-project"}


@pytest.fixture
def fake_adc(monkeypatch):
    monkeypatch.setattr(google_stt_module, "gauth_default", lambda *a, **k: (object(), "p"))


def test_model_is_chirp_3():
    assert GOOGLE_STT_MODEL == "chirp_3"


def test_required_var_is_project_only_no_api_key():
    assert REQUIRED_GOOGLE_STT_VARS == ("GOOGLE_CLOUD_PROJECT",)


def test_settings_defaults():
    settings = load_google_stt_settings(ENV)

    assert settings.project == "my-project"
    assert settings.location == DEFAULT_GOOGLE_STT_LOCATION
    assert settings.location != "global"
    assert settings.language == DEFAULT_GOOGLE_STT_LANGUAGE
    assert settings.model == "chirp_3"


def test_settings_overrides():
    settings = load_google_stt_settings(
        {**ENV, "GOOGLE_STT_LOCATION": "eu", "GOOGLE_STT_LANGUAGE": "es-ES"}
    )

    assert (settings.location, settings.language) == ("eu", "es-ES")


@pytest.mark.parametrize("env", [{}, {"GOOGLE_CLOUD_PROJECT": ""}, {"GOOGLE_CLOUD_PROJECT": " "}])
def test_missing_project_raises(env):
    with pytest.raises(MissingConfigurationError) as exc_info:
        load_google_stt_settings(env)

    assert exc_info.value.missing == ["GOOGLE_CLOUD_PROJECT"]


def test_build_google_stt_configures_chirp_3(fake_adc):
    instance = create_google_stt(ENV)

    assert isinstance(instance, lk_stt.STT)
    assert isinstance(instance, google.STT)
    assert instance.model == "chirp_3"
    assert instance.provider == "Google Cloud Platform"
    assert instance.capabilities.streaming is True
    assert instance.capabilities.interim_results is True
    config = instance._config
    assert [str(lang) for lang in config.languages] == [DEFAULT_GOOGLE_STT_LANGUAGE]
    assert config.detect_language is False
    assert instance._location == DEFAULT_GOOGLE_STT_LOCATION
    assert instance._project_id == "my-project"


def test_explicit_credentials_skip_plugin_adc_resolution(monkeypatch):
    credentials = object()

    def unexpected_adc(*args, **kwargs):
        raise AssertionError("google.STT no debe resolver ADC con credenciales explicitas")

    monkeypatch.setattr(google_stt_module, "gauth_default", unexpected_adc)

    instance = create_google_stt(ENV, credentials=credentials)

    assert instance._credentials is credentials
    assert instance._project_id == "my-project"


def test_resolve_google_adc_returns_credentials_without_exposing_project(monkeypatch):
    credentials = object()
    monkeypatch.setattr(
        "alloxentric_real_time_agent.stt.google_auth_default",
        lambda: (credentials, "ignored"),
    )

    assert resolve_google_adc() is credentials


def test_resolve_google_adc_without_credentials_raises_clear_error(monkeypatch):
    def no_adc():
        raise DefaultCredentialsError("secret provider detail")

    monkeypatch.setattr("alloxentric_real_time_agent.stt.google_auth_default", no_adc)

    with pytest.raises(MissingCredentialsError) as exc_info:
        resolve_google_adc()

    assert "secret provider detail" not in str(exc_info.value)


def test_build_google_stt_without_adc_raises_clear_error(monkeypatch):
    def no_adc(*args, **kwargs):
        raise DefaultCredentialsError("no adc")

    monkeypatch.setattr(google_stt_module, "gauth_default", no_adc)

    with pytest.raises(MissingCredentialsError, match="gcloud auth application-default login"):
        build_google_stt(load_google_stt_settings(ENV))


def test_missing_project_is_reported_before_credentials():
    with pytest.raises(MissingConfigurationError, match="GOOGLE_CLOUD_PROJECT"):
        create_google_stt({})


def test_building_does_not_touch_the_network(fake_adc, monkeypatch):
    def blocked(*args, **kwargs):
        raise AssertionError("no se permiten conexiones de red en estas pruebas")

    monkeypatch.setattr(socket.socket, "connect", blocked)

    create_google_stt(ENV)
