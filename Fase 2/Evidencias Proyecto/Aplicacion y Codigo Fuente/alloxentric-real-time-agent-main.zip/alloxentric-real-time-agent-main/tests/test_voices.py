"""Pruebas de voces chilenas por persona y precalentamiento (DART-14-5.1).

Sin red ni credenciales reales. No validan la calidad ni el acento de las voces
(eso requiere escucharlas); solo la configuracion y el cableado.
"""

import re

import pytest
from livekit.agents.utils import is_given

import alloxentric_real_time_agent.voice_warmup as warmup
from alloxentric_real_time_agent.config import (
    DEFAULT_ELEVENLABS_LANGUAGE,
    DEFAULT_ELEVENLABS_VOICE_ID,
    load_elevenlabs_settings,
)
from alloxentric_real_time_agent.personas import PERSONAS
from alloxentric_real_time_agent.pipeline import build_agent_session
from alloxentric_real_time_agent.tts import build_elevenlabs_tts

ENV = {"ELEVEN_API_KEY": "fake-eleven"}
SESSION_ENV = {
    "GOOGLE_API_KEY": "fake-gemini",
    "GOOGLE_CLOUD_PROJECT": "p",
    "ELEVEN_API_KEY": "fake-eleven",
}


@pytest.mark.parametrize("persona", PERSONAS.values(), ids=lambda p: p.id)
def test_every_persona_has_a_valid_voice_id(persona):
    assert re.fullmatch(r"[A-Za-z0-9]{20}", persona.voice_id)


def test_personas_do_not_all_share_the_same_voice():
    assert len({p.voice_id for p in PERSONAS.values()}) == len(PERSONAS)


def test_default_voice_is_the_chilean_default_and_language_is_spanish():
    settings = load_elevenlabs_settings(ENV)

    assert settings.voice_id == DEFAULT_ELEVENLABS_VOICE_ID == "oJIuRMopN0sojGjwD6rQ"
    assert settings.language == DEFAULT_ELEVENLABS_LANGUAGE == "es"


@pytest.mark.parametrize("value", ["off", "OFF", "none", "false"])
def test_language_can_be_disabled(value):
    assert load_elevenlabs_settings({**ENV, "ELEVEN_LANGUAGE": value}).language is None


def test_persona_voice_is_used_when_no_explicit_override():
    tts = build_elevenlabs_tts(ENV, voice_id=PERSONAS["falabella-cobranza"].voice_id)

    assert tts._opts.voice_id == PERSONAS["falabella-cobranza"].voice_id


def test_explicit_env_voice_overrides_the_persona_voice():
    tts = build_elevenlabs_tts(
        {**ENV, "ELEVEN_VOICE_ID": "operator-voice"}, voice_id=PERSONAS["claro-ventas"].voice_id
    )

    assert tts._opts.voice_id == "operator-voice"


def test_without_persona_the_default_voice_is_used():
    assert build_elevenlabs_tts(ENV)._opts.voice_id == DEFAULT_ELEVENLABS_VOICE_ID


def test_tts_receives_the_spanish_language():
    assert build_elevenlabs_tts(ENV)._opts.language == "es"
    assert not is_given(build_elevenlabs_tts({**ENV, "ELEVEN_LANGUAGE": "off"})._opts.language)


@pytest.mark.parametrize("persona_id", list(PERSONAS))
def test_session_uses_the_voice_of_its_persona(persona_id, monkeypatch):
    from livekit.plugins.google import stt as google_stt_module

    monkeypatch.setattr(google_stt_module, "gauth_default", lambda *a, **k: (object(), "p"))
    session = build_agent_session(SESSION_ENV, persona=PERSONAS[persona_id])

    assert session.tts._opts.voice_id == PERSONAS[persona_id].voice_id


# --- precalentamiento -----------------------------------------------------------


class _FakeResponse:
    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False

    def read(self):
        return b""


def test_warmup_requests_one_synthesis_per_persona_voice(monkeypatch):
    calls = []

    def fake_urlopen(request, timeout=None):
        calls.append(request.full_url)
        assert request.get_header("Xi-api-key") == "fake-eleven"
        return _FakeResponse()

    monkeypatch.setattr(warmup.urllib.request, "urlopen", fake_urlopen)
    threads = warmup.start_voice_warmup(ENV)
    for thread in threads:
        thread.join(5)

    voices = {p.voice_id for p in PERSONAS.values()}
    assert len(calls) == len(voices)
    assert {voice in url for voice in voices for url in calls}


def test_warmup_can_be_disabled(monkeypatch):
    monkeypatch.setattr(warmup.urllib.request, "urlopen", lambda *a, **k: pytest.fail("no debe llamar"))

    assert warmup.start_voice_warmup({**ENV, "ELEVEN_VOICE_WARMUP": "off"}) == []


def test_warmup_without_api_key_does_nothing(monkeypatch):
    monkeypatch.setattr(warmup.urllib.request, "urlopen", lambda *a, **k: pytest.fail("no debe llamar"))

    assert warmup.start_voice_warmup({}) == []


def test_warmup_failure_is_silent_and_does_not_leak_provider_details(monkeypatch, caplog):
    def boom(*args, **kwargs):
        raise OSError("secret provider detail xyz")

    monkeypatch.setattr(warmup.urllib.request, "urlopen", boom)

    assert warmup.warm_up_voice("a" * 20, ENV) is False
    assert "secret provider detail" not in caplog.text
