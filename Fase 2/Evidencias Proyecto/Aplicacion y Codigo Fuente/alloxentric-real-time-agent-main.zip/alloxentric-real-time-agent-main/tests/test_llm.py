"""Pruebas de la integracion DeepSeek (DART_14-1.6).

Ninguna de estas pruebas hace una llamada real a la API de DeepSeek: usan
una API key ficticia solo para verificar que el componente LLM se
construye y se configura correctamente (la construccion es perezosa, sin
red). La llamada real de bajo costo se verifica manualmente con
scripts/check_deepseek_llm.py.
"""

import socket

import pytest
from livekit.agents.llm import LLM as BaseLLM

from alloxentric_real_time_agent.config import (
    DEFAULT_DEEPSEEK_MODEL,
    REQUIRED_DEEPSEEK_VARS,
    MissingConfigurationError,
    load_deepseek_settings,
)
from alloxentric_real_time_agent.llm import build_deepseek_llm


def test_default_deepseek_model_is_deepseek_flash():
    """Valor literal, no solo contra la constante (ver correccion DART_14-1.6).

    La documentacion oficial vigente de DeepSeek retiro "deepseek-chat" /
    "deepseek-reasoner" el 2026-07-24; "deepseek-flash" es el identificador
    actual de DeepSeek-V4.1-Flash. LiveKit (plugin y docs) sigue mostrando
    "deepseek-chat" como ejemplo/default, por lo que este proyecto NO
    depende de ese default y fija el suyo explicitamente.
    """

    assert DEFAULT_DEEPSEEK_MODEL == "deepseek-flash"


def test_load_deepseek_settings_uses_default_model_when_not_set():
    settings = load_deepseek_settings({"DEEPSEEK_API_KEY": "fake-key"})

    assert settings.api_key == "fake-key"
    assert settings.model == "deepseek-flash"
    assert settings.model == DEFAULT_DEEPSEEK_MODEL


def test_load_deepseek_settings_respects_explicit_model_override():
    settings = load_deepseek_settings(
        {"DEEPSEEK_API_KEY": "fake-key", "DEEPSEEK_MODEL": "deepseek-coder"}
    )

    assert settings.model == "deepseek-coder"


def test_load_deepseek_settings_raises_when_api_key_missing():
    with pytest.raises(MissingConfigurationError) as exc_info:
        load_deepseek_settings({})

    assert exc_info.value.missing == list(REQUIRED_DEEPSEEK_VARS)


def test_build_deepseek_llm_raises_clear_error_without_api_key():
    with pytest.raises(MissingConfigurationError):
        build_deepseek_llm({})


def test_build_deepseek_llm_returns_an_agent_session_compatible_llm():
    llm = build_deepseek_llm({"DEEPSEEK_API_KEY": "fake-key"})

    # AgentSession(llm=...) solo exige esta base comun.
    assert isinstance(llm, BaseLLM)
    assert llm.model == "deepseek-flash"
    assert llm.model == DEFAULT_DEEPSEEK_MODEL


def test_build_deepseek_llm_passes_model_explicitly_not_livekit_default():
    """`with_deepseek()` nunca debe usar su propio default ("deepseek-chat").

    build_deepseek_llm() debe pasar `model=` explicitamente siempre, para
    no depender silenciosamente del ejemplo/default desactualizado de
    LiveKit (ver discrepancia documentada en README y config.py).
    """

    llm = build_deepseek_llm({"DEEPSEEK_API_KEY": "fake-key"})

    assert llm.model != "deepseek-chat"
    assert llm.model == "deepseek-flash"


def test_build_deepseek_llm_respects_model_override_end_to_end():
    llm = build_deepseek_llm(
        {"DEEPSEEK_API_KEY": "fake-key", "DEEPSEEK_MODEL": "deepseek-coder"}
    )

    assert llm.model == "deepseek-coder"


def test_build_deepseek_llm_never_touches_the_network(monkeypatch):
    """Construir el LLM no debe abrir ninguna conexion de red.

    Si esto falla, significa que `with_deepseek()` dejo de ser perezoso en
    una version futura del SDK y los tests automatizados empezarian a
    depender de red/credenciales reales sin que nadie lo haya decidido.
    """

    def _blocked(*_args, **_kwargs):
        raise AssertionError("No se esperaba acceso a la red al construir el LLM")

    monkeypatch.setattr(socket, "socket", _blocked)

    build_deepseek_llm({"DEEPSEEK_API_KEY": "fake-key"})
