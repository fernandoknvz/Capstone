"""Pruebas del recolector de metricas de latencia (DART-14-3.1).

Ninguna usa red ni proveedores: se emiten eventos sinteticos en una
``AgentSession`` y se inspecciona el log local. Los valores numericos son
arbitrarios y NO representan rendimiento real.
"""

import json
import logging
import time
from types import SimpleNamespace

import pytest
from livekit.agents import (
    AgentSession,
    AgentStateChangedEvent,
    CloseEvent,
    CloseReason,
    ConversationItemAddedEvent,
    ErrorEvent,
    SessionUsageUpdatedEvent,
)
from livekit.agents.llm import ChatMessage, LLMError
from livekit.agents.metrics import AgentSessionUsage, LLMModelUsage, TTSModelUsage
from livekit.plugins.google import stt as google_stt_module

from alloxentric_real_time_agent.metrics import (
    AGENT_TURN_FIELDS,
    USER_TURN_FIELDS,
    attach_metrics,
)
from alloxentric_real_time_agent.pipeline import attach_observability, build_agent_session

LOGGER = "alloxentric_real_time_agent.metrics"
SECRET_TEXT = "frase-secreta-de-la-conversacion"
REQUEST_ID = "req-id-externo-12345"


@pytest.fixture
def session():
    return AgentSession()


@pytest.fixture
def logs(caplog):
    caplog.set_level(logging.INFO, logger=LOGGER)
    return caplog


def _lines(caplog, kind):
    """Devuelve los payloads JSON de las lineas ``metrics <kind> {...}``."""

    out = []
    for record in caplog.records:
        if record.name != LOGGER:
            continue
        message = record.getMessage()
        prefix = f"metrics {kind} "
        if message.startswith(prefix):
            out.append(json.loads(message[len(prefix):]))
    return out


def _user(metrics=None, text=SECRET_TEXT):
    return ChatMessage(role="user", content=[text], metrics=metrics or {})


def _agent(metrics=None, text="respuesta-secreta", interrupted=False):
    return ChatMessage(
        role="assistant", content=[text], metrics=metrics or {}, interrupted=interrupted
    )


def _add(session, msg):
    session.emit("conversation_item_added", ConversationItemAddedEvent(item=msg))


FULL_USER = {"transcription_delay": 0.41, "end_of_turn_delay": 0.52}
FULL_AGENT = {
    "llm_node_ttft": 0.73,
    "tts_node_ttfb": 0.31,
    "playback_latency": 0.05,
    "e2e_latency": 1.9,
}


# --- Metricas por turno --------------------------------------------------------


def test_turn_logs_the_available_metrics_with_explicit_units(session, logs):
    attach_metrics(session)

    _add(session, _user(FULL_USER))
    _add(session, _agent(FULL_AGENT))

    [turn] = _lines(logs, "turn")
    assert turn == {
        "turn": 1,
        "transcription_delay_s": 0.41,
        "end_of_turn_delay_s": 0.52,
        "llm_node_ttft_s": 0.73,
        "tts_node_ttfb_s": 0.31,
        "playback_latency_s": 0.05,
        "e2e_latency_s": 1.9,
        "interrupted": False,
    }


def test_the_documented_target_fields_are_the_ones_read():
    assert USER_TURN_FIELDS == ("transcription_delay", "end_of_turn_delay")
    assert AGENT_TURN_FIELDS == (
        "llm_node_ttft",
        "tts_node_ttfb",
        "playback_latency",
        "e2e_latency",
    )


def test_absent_fields_are_omitted_and_never_turned_into_zero(session, logs):
    attach_metrics(session)

    _add(session, _agent({"e2e_latency": 2.0}))

    [turn] = _lines(logs, "turn")
    assert turn == {"turn": 1, "e2e_latency_s": 2.0, "interrupted": False}


@pytest.mark.parametrize("bad", [-1, -0.5, float("nan"), float("inf")])
def test_invalid_numbers_are_treated_as_absent(session, logs, bad):
    attach_metrics(session)

    _add(session, _agent({"llm_node_ttft": bad, "e2e_latency": 1.2}))

    [turn] = _lines(logs, "turn")
    assert "llm_node_ttft_s" not in turn
    assert turn["e2e_latency_s"] == 1.2


@pytest.mark.parametrize("bad", [True, "1.0", None, [1]])
def test_non_numeric_values_are_treated_as_absent(session, logs, bad):
    # ChatMessage valida los tipos; model_construct simula un SDK que no lo hiciera.
    attach_metrics(session)
    msg = ChatMessage.model_construct(
        role="assistant",
        content=["x"],
        metrics={"llm_node_ttft": bad, "e2e_latency": 1.2},
    )

    _add(session, msg)

    [turn] = _lines(logs, "turn")
    assert "llm_node_ttft_s" not in turn
    assert turn["e2e_latency_s"] == 1.2


def test_a_real_zero_is_kept_as_zero(session, logs):
    attach_metrics(session)

    _add(session, _agent({"playback_latency": 0.0}))

    [turn] = _lines(logs, "turn")
    assert turn["playback_latency_s"] == 0.0


def test_user_metrics_are_attached_to_the_next_agent_turn_only_once(session, logs):
    attach_metrics(session)

    _add(session, _user(FULL_USER))
    _add(session, _agent(FULL_AGENT))
    _add(session, _agent({"e2e_latency": 1.0}))  # sin mensaje de usuario previo

    first, second = _lines(logs, "turn")
    assert first["transcription_delay_s"] == 0.41
    assert "transcription_delay_s" not in second
    assert (first["turn"], second["turn"]) == (1, 2)


def test_a_newer_user_message_replaces_an_unanswered_one(session, logs):
    attach_metrics(session)

    _add(session, _user({"transcription_delay": 9.0}))
    _add(session, _user({"transcription_delay": 0.3}))
    _add(session, _agent())

    [turn] = _lines(logs, "turn")
    assert turn["transcription_delay_s"] == 0.3


def test_interrupted_turns_are_flagged(session, logs):
    attach_metrics(session)

    _add(session, _agent(FULL_AGENT, interrupted=True))

    [turn] = _lines(logs, "turn")
    assert turn["interrupted"] is True


def test_duplicate_items_do_not_produce_duplicate_lines(session, logs):
    attach_metrics(session)
    msg = _agent(FULL_AGENT)

    _add(session, msg)
    _add(session, msg)

    assert len(_lines(logs, "turn")) == 1


def test_items_that_are_not_chat_messages_are_ignored(session, logs):
    attach_metrics(session)

    session.emit(
        "conversation_item_added",
        SimpleNamespace(item=SimpleNamespace(id="x", role="assistant")),
    )

    assert _lines(logs, "turn") == []


def test_attaching_twice_does_not_duplicate_lines(session, logs):
    first = attach_metrics(session)
    second = attach_metrics(session)

    _add(session, _agent(FULL_AGENT))

    assert first is second
    assert len(_lines(logs, "turn")) == 1


# --- Inicializacion --------------------------------------------------------------


def test_startup_time_is_measured_from_the_agent_state_events(session, logs):
    t0 = time.time()
    attach_metrics(session, started_at=t0)

    session.emit(
        "agent_state_changed",
        AgentStateChangedEvent(old_state="initializing", new_state="listening", created_at=t0 + 1.25),
    )
    session.emit(
        "agent_state_changed",
        AgentStateChangedEvent(old_state="listening", new_state="thinking", created_at=t0 + 9),
    )

    assert _lines(logs, "startup") == [{"startup_s": 1.25}]


def test_startup_is_not_reported_without_a_verifiable_transition(session, logs):
    t0 = time.time()
    attach_metrics(session, started_at=t0)

    session.emit(
        "agent_state_changed",
        AgentStateChangedEvent(old_state="listening", new_state="speaking", created_at=t0 + 1),
    )
    session.emit(  # evento anterior al inicio: no es verificable
        "agent_state_changed",
        AgentStateChangedEvent(old_state="initializing", new_state="listening", created_at=t0 - 5),
    )

    assert _lines(logs, "startup") == []


# --- Errores y cierre ------------------------------------------------------------


def _error_event(session, kind_error=RuntimeError("detalle sensible 401")):
    return ErrorEvent(
        error=LLMError(timestamp=0.0, label="proveedor", error=kind_error, recoverable=False),
        source=session.llm,
    )


def test_errors_are_counted_by_type_in_the_summary(session, logs):
    attach_metrics(session)

    session.emit("error", _error_event(session))
    session.emit("error", _error_event(session))
    session.emit("close", CloseEvent(reason=CloseReason.USER_INITIATED))

    [summary] = _lines(logs, "session_summary")
    assert summary["errors"] == {"llm_error": 2}
    assert summary["close_reason"] == "user_initiated"
    assert "detalle sensible" not in logs.text


def test_closing_a_session_without_turns_reports_zero_turns(session, logs):
    attach_metrics(session)

    session.emit("close", CloseEvent(reason=CloseReason.JOB_SHUTDOWN))

    [summary] = _lines(logs, "session_summary")
    assert summary == {"turns": 0, "errors": {}, "close_reason": "job_shutdown"}


def test_close_is_reported_only_once(session, logs):
    attach_metrics(session)

    session.emit("close", CloseEvent(reason=CloseReason.USER_INITIATED))
    session.emit("close", CloseEvent(reason=CloseReason.USER_INITIATED))

    assert len(_lines(logs, "session_summary")) == 1


def test_summary_includes_turn_count_and_startup(session, logs):
    t0 = time.time()
    attach_metrics(session, started_at=t0)
    session.emit(
        "agent_state_changed",
        AgentStateChangedEvent(old_state="initializing", new_state="listening", created_at=t0 + 0.8),
    )
    _add(session, _agent(FULL_AGENT))
    _add(session, _agent(FULL_AGENT))

    session.emit("close", CloseEvent(reason=CloseReason.USER_INITIATED))

    [summary] = _lines(logs, "session_summary")
    assert summary["turns"] == 2
    assert summary["startup_s"] == 0.8


# --- Uso -------------------------------------------------------------------------


def test_usage_is_reported_once_at_close_using_the_latest_cumulative_value(session, logs):
    attach_metrics(session)

    def usage(tokens):
        return AgentSessionUsage(
            model_usage=[
                LLMModelUsage(provider="Gemini", model="gemini-x", input_tokens=tokens, output_tokens=7),
                TTSModelUsage(provider="ElevenLabs", model="eleven-x", characters_count=50),
            ]
        )

    session.emit("session_usage_updated", SessionUsageUpdatedEvent(usage=usage(10)))
    session.emit("session_usage_updated", SessionUsageUpdatedEvent(usage=usage(25)))
    assert _lines(logs, "session_summary") == []  # no se registra en cada actualizacion

    session.emit("close", CloseEvent(reason=CloseReason.USER_INITIATED))

    [summary] = _lines(logs, "session_summary")
    assert summary["usage"] == [
        {"type": "llm_usage", "provider": "Gemini", "model": "gemini-x", "input_tokens": 25.0, "output_tokens": 7.0},
        {"type": "tts_usage", "provider": "ElevenLabs", "model": "eleven-x", "characters_count": 50.0},
    ]


# --- Privacidad ------------------------------------------------------------------


def test_logs_never_contain_conversation_text_or_provider_identifiers(session, logs):
    attach_metrics(session)
    user = _user({**FULL_USER, "provider_request_ids": [REQUEST_ID]}, text=SECRET_TEXT)
    agent = _agent(
        {**FULL_AGENT, "provider_request_ids": [REQUEST_ID], "llm_metadata": {"model_name": "m"}},
        text="otra-frase-privada",
    )

    _add(session, user)
    _add(session, agent)
    session.emit("close", CloseEvent(reason=CloseReason.USER_INITIATED))

    assert _lines(logs, "turn")  # se registro algo...
    assert SECRET_TEXT not in logs.text
    assert "otra-frase-privada" not in logs.text
    assert REQUEST_ID not in logs.text
    assert user.id not in logs.text and agent.id not in logs.text
    assert "request_id" not in logs.text


def test_the_obsolete_metrics_collected_event_is_not_subscribed(session, caplog):
    caplog.set_level(logging.WARNING)

    attach_metrics(session)

    assert "deprecated" not in caplog.text


# --- Compatibilidad con la sesion existente --------------------------------------

ENV = {
    "GOOGLE_CLOUD_PROJECT": "my-project",
    "GOOGLE_API_KEY": "fake-google-key",
    "ELEVEN_API_KEY": "fake-eleven-key",
}


def test_attach_observability_wires_the_metrics_and_keeps_the_error_log(monkeypatch, caplog):
    monkeypatch.setattr(google_stt_module, "gauth_default", lambda *a, **k: (object(), "p"))
    session = build_agent_session(ENV)
    caplog.set_level(logging.INFO)

    attach_observability(session)
    session.emit("error", _error_event(session))
    _add(session, _agent(FULL_AGENT))
    session.emit("close", CloseEvent(reason=CloseReason.USER_INITIATED))

    assert "Error de sesion: tipo=llm_error" in caplog.text  # log previo intacto
    assert "Sesion cerrada: motivo=user_initiated" in caplog.text
    assert len(_lines(caplog, "turn")) == 1
    [summary] = _lines(caplog, "session_summary")
    assert summary["errors"] == {"llm_error": 1}
    assert "deprecated" not in caplog.text
    assert "detalle sensible" not in caplog.text


# --- Asociacion de turnos con interrupciones y respuestas canceladas ---------------
#
# Las marcas de tiempo son de una linea de tiempo sintetica (no de rendimiento).


def _user_t(stopped, **extra):
    return _user({"stopped_speaking_at": stopped, **extra})


def _agent_t(started, e2e=None, **extra):
    metrics = {"started_speaking_at": started, **extra}
    if e2e is not None:
        metrics["e2e_latency"] = e2e
    return _agent(metrics)


def test_a_user_interruption_arriving_before_the_interrupted_reply_keeps_each_pairing(session, logs):
    attach_metrics(session)

    _add(session, _user_t(8.0, transcription_delay=0.11))
    _add(session, _user_t(12.0, transcription_delay=0.22))  # interrumpe la respuesta 1
    _add(session, _agent_t(10.0, e2e=2.0, llm_node_ttft=0.5))  # respuesta 1 (interrumpida)
    _add(session, _agent_t(14.0, e2e=2.0, llm_node_ttft=0.6))

    first, second = _lines(logs, "turn")
    assert first["transcription_delay_s"] == 0.11
    assert second["transcription_delay_s"] == 0.22


def test_a_cancelled_reply_leaves_no_stale_user_metrics_for_later_turns(session, logs):
    attach_metrics(session)

    _add(session, _user_t(8.0, transcription_delay=0.11))  # su respuesta se cancelo
    _add(session, _user_t(20.0, transcription_delay=0.22))
    _add(session, _agent_t(22.0, e2e=2.0))
    _add(session, _agent_t(40.0))  # respuesta sin usuario previo (p. ej. saludo)

    answered, proactive = _lines(logs, "turn")
    assert answered["transcription_delay_s"] == 0.22
    assert "transcription_delay_s" not in proactive


def test_stale_user_metrics_are_not_borrowed_when_the_sdk_paired_another_user_turn(session, logs):
    attach_metrics(session)

    _add(session, _user_t(8.0, transcription_delay=0.11))
    # e2e = 2.0 indica que el SDK respondio a un usuario que termino en t=28, no en t=8
    _add(session, _agent_t(30.0, e2e=2.0))

    [turn] = _lines(logs, "turn")
    assert "transcription_delay_s" not in turn


def test_a_user_message_delivered_after_its_reply_is_not_assigned_to_the_next_turn(session, logs):
    attach_metrics(session)

    _add(session, _agent_t(10.0, e2e=2.0))  # la respuesta llega primero
    _add(session, _user_t(8.0, transcription_delay=0.11))  # el SDK entrega el usuario tarde
    _add(session, _agent_t(30.0, e2e=2.0))

    first, second = _lines(logs, "turn")
    assert "transcription_delay_s" not in first
    assert "transcription_delay_s" not in second


def test_a_duplicated_user_message_is_paired_only_once(session, logs):
    attach_metrics(session)
    user = _user_t(8.0, transcription_delay=0.11)

    _add(session, user)
    _add(session, user)
    _add(session, _agent_t(10.0, e2e=2.0))
    _add(session, _agent_t(30.0))

    first, second = _lines(logs, "turn")
    assert first["transcription_delay_s"] == 0.11
    assert "transcription_delay_s" not in second


def test_an_unanswered_user_message_produces_no_turn_line(session, logs):
    attach_metrics(session)

    _add(session, _user_t(8.0, transcription_delay=0.11))
    session.emit("close", CloseEvent(reason=CloseReason.USER_INITIATED))

    assert _lines(logs, "turn") == []
    assert _lines(logs, "session_summary")[0]["turns"] == 0


def test_without_timestamps_pairing_falls_back_to_arrival_order(session, logs):
    attach_metrics(session)

    _add(session, _user({"transcription_delay": 0.4}))
    _add(session, _agent())

    [turn] = _lines(logs, "turn")
    assert turn["transcription_delay_s"] == 0.4


def test_timestamps_are_used_to_pair_but_never_logged(session, logs):
    attach_metrics(session)

    _add(session, _user_t(8.0, transcription_delay=0.11))
    _add(session, _agent_t(10.0, e2e=2.0))

    [turn] = _lines(logs, "turn")
    assert not any("speaking_at" in key for key in turn)


# --- Privacidad del resumen de uso -----------------------------------------------


def _usage_item(**extra):
    base = dict(
        type="llm_usage", provider="Gemini", model="gemini-x", input_tokens=15, output_tokens=23
    )
    return SimpleNamespace(**{**base, **extra})


def test_usage_summary_ignores_unexpected_attributes(session, logs):
    attach_metrics(session)
    item = _usage_item(
        api_key="clave-secreta-123",
        access_token="token-de-autenticacion-456",
        participant_identity="persona-789",
        room_name="sala-privada-000",
        request_id=REQUEST_ID,
        text=SECRET_TEXT,
    )

    session.emit(
        "session_usage_updated",
        SimpleNamespace(usage=SimpleNamespace(model_usage=[item])),
    )
    session.emit("close", CloseEvent(reason=CloseReason.USER_INITIATED))

    [summary] = _lines(logs, "session_summary")
    assert summary["usage"] == [
        {"type": "llm_usage", "provider": "Gemini", "model": "gemini-x", "input_tokens": 15.0, "output_tokens": 23.0}
    ]
    for secret in (
        "clave-secreta-123",
        "token-de-autenticacion-456",
        "persona-789",
        "sala-privada-000",
        REQUEST_ID,
        SECRET_TEXT,
    ):
        assert secret not in logs.text


def test_llm_consumption_tokens_are_reported_but_authentication_tokens_are_not(session, logs):
    attach_metrics(session)
    item = _usage_item(token="credencial-no-debe-salir", auth_token="otra-credencial")

    session.emit(
        "session_usage_updated",
        SimpleNamespace(usage=SimpleNamespace(model_usage=[item])),
    )
    session.emit("close", CloseEvent(reason=CloseReason.USER_INITIATED))

    [summary] = _lines(logs, "session_summary")
    assert summary["usage"][0]["input_tokens"] == 15.0  # tokens de consumo del LLM
    assert "credencial-no-debe-salir" not in logs.text
    assert "otra-credencial" not in logs.text


def test_unsafe_labels_are_replaced_by_unknown(session, logs):
    attach_metrics(session)
    item = _usage_item(provider="Bearer abc.def secreto", model="x" * 200, type="llm usage")

    session.emit(
        "session_usage_updated",
        SimpleNamespace(usage=SimpleNamespace(model_usage=[item])),
    )
    session.emit(
        "error",
        SimpleNamespace(error=SimpleNamespace(type="error con secreto sk-123 y espacios")),
    )
    session.emit("close", SimpleNamespace(reason="motivo con espacios y secreto"))

    [summary] = _lines(logs, "session_summary")
    entry = summary["usage"][0]
    assert (entry["provider"], entry["model"], entry["type"]) == ("desconocido",) * 3
    assert summary["errors"] == {"desconocido": 1}
    assert summary["close_reason"] == "desconocido"
    assert "secreto" not in logs.text and "sk-123" not in logs.text


def test_session_summary_only_contains_whitelisted_keys(session, logs):
    attach_metrics(session)
    session.emit("error", _error_event(session))
    _add(session, _agent(FULL_AGENT))
    session.emit(
        "session_usage_updated",
        SessionUsageUpdatedEvent(
            usage=AgentSessionUsage(model_usage=[LLMModelUsage(provider="Gemini", model="g", input_tokens=1)])
        ),
    )
    session.emit("close", CloseEvent(reason=CloseReason.USER_INITIATED))

    [summary] = _lines(logs, "session_summary")
    assert set(summary) <= {"turns", "errors", "close_reason", "startup_s", "usage"}
    for entry in summary["usage"]:
        assert set(entry) <= {
            "type", "provider", "model", "input_tokens", "output_tokens",
            "output_reasoning_tokens", "characters_count", "audio_duration",
        }
