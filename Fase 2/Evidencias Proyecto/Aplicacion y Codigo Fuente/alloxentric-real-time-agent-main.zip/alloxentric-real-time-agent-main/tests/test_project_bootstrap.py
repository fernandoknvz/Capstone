"""Pruebas de arranque del proyecto (DART_14-1.5).

Demuestran que:
- el paquete del proyecto se importa correctamente;
- el SDK de LiveKit Agents se importa correctamente;
- el modulo del agente define un entrypoint coherente (un AgentServer con
  al menos un job registrado), sin requerir una conexion real a LiveKit.
"""

import importlib


def test_project_package_imports():
    package = importlib.import_module("alloxentric_real_time_agent")

    assert hasattr(package, "__version__")
    assert package.__version__


def test_livekit_agents_sdk_imports():
    agents = importlib.import_module("livekit.agents")

    assert hasattr(agents, "JobContext")
    assert hasattr(agents, "cli")


def test_agent_module_defines_an_agent_server():
    from livekit.agents import AgentServer

    agent_module = importlib.import_module("alloxentric_real_time_agent.agent")

    assert isinstance(agent_module.server, AgentServer)
    assert callable(agent_module.entrypoint)
    assert callable(agent_module.run)
