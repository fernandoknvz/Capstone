"""Pruebas de las personas del agente (DART-14-5.1). Sin red ni credenciales."""

import json
import re
from pathlib import Path

import pytest
from livekit.agents import Agent

from alloxentric_real_time_agent.personas import (
    COLLECTION_RULES,
    COMMON_RULES,
    PERSONA_IDS,
    PERSONAS,
    build_instructions,
    get_persona,
    persona_from_job_metadata,
)
from alloxentric_real_time_agent.pipeline import AGENT_INSTRUCTIONS, build_agent

from test_pipeline import _run_entrypoint

TS_PERSONAS = Path(__file__).parent.parent / "web-demo" / "lib" / "personas.ts"


def test_there_are_seven_personas_with_unique_ids():
    assert len(PERSONA_IDS) == 7
    assert len(set(PERSONA_IDS)) == 7


def test_python_and_web_persona_ids_are_identical():
    text = TS_PERSONAS.read_text(encoding="utf-8")
    web_ids = re.findall(r"id:\s*'([a-z0-9-]+)'", text)

    assert web_ids == list(PERSONA_IDS)


def test_required_scenarios_are_present():
    texts = {pid: PERSONAS[pid].instructions for pid in PERSONA_IDS}

    assert "MovilAndes" in texts["claro-ventas"]
    assert "4.200.000" in texts["falabella-cobranza"]
    assert "Casa Aurora" in texts["falabella-cobranza"]
    assert "dental" in texts["clinica-dental"].lower()
    assert "Brujula" in texts["hites-servicio"]
    assert "1.300.000" in texts["ripley-cobranza"]
    assert "300 por ciento" in texts["ripley-cobranza"]
    assert "juguera" in texts["ripley-cobranza"].lower()


@pytest.mark.parametrize("persona_id", PERSONA_IDS)
def test_every_persona_is_complete_and_short_spoken(persona_id):
    persona = PERSONAS[persona_id]

    assert persona.label and persona.tagline and persona.greeting
    assert len(persona.greeting.split()) <= 30
    assert build_instructions(persona).startswith(COMMON_RULES)


@pytest.mark.parametrize("persona_id", ["falabella-cobranza", "ripley-cobranza"])
def test_collection_personas_forbid_threats(persona_id):
    assert COLLECTION_RULES in build_instructions(PERSONAS[persona_id])
    assert "nunca amenazas" in COLLECTION_RULES


def test_get_persona_rejects_unknown_and_non_string_ids():
    assert get_persona("claro-ventas") is PERSONAS["claro-ventas"]
    for bad in ("nope", "", None, 3, ["claro-ventas"]):
        assert get_persona(bad) is None


@pytest.mark.parametrize(
    "metadata",
    [None, "", "no-es-json", "[]", '"claro-ventas"', '{"persona": "x"}', '{"persona": 5}', "{}"],
)
def test_job_metadata_that_is_missing_or_invalid_gives_no_persona(metadata):
    assert persona_from_job_metadata(metadata) is None


def test_job_metadata_with_valid_persona():
    persona = persona_from_job_metadata(json.dumps({"persona": "clinica-dental"}))

    assert persona is PERSONAS["clinica-dental"]


def test_build_agent_defaults_to_the_test_agent():
    assert build_agent().instructions == AGENT_INSTRUCTIONS


def test_build_agent_uses_persona_instructions():
    agent = build_agent(PERSONAS["claro-ventas"])

    assert isinstance(agent, Agent)
    assert agent.instructions == build_instructions(PERSONAS["claro-ventas"])


def test_entrypoint_greets_with_the_persona_and_uses_its_instructions(monkeypatch):
    _, session, _, _ = _run_entrypoint(
        monkeypatch, metadata=json.dumps({"persona": "falabella-cobranza"})
    )

    agent = session.start.await_args.args[0]
    assert agent.instructions == build_instructions(PERSONAS["falabella-cobranza"])
    session.say.assert_called_once_with(PERSONAS["falabella-cobranza"].greeting)


def test_entrypoint_without_persona_does_not_greet(monkeypatch):
    _, session, _, _ = _run_entrypoint(monkeypatch, metadata=None)

    assert session.start.await_args.args[0].instructions == AGENT_INSTRUCTIONS
    session.say.assert_not_called()


# Sensible a mayusculas: "Claro" es una marca, pero "un compromiso claro" es un adjetivo.
REAL_BRANDS_AND_PEOPLE = ("Claro", "Falabella", "Ripley", "Hites", "Juan Díaz", "Juan Diaz", "Juan Salvador")


def test_scenarios_use_fictional_companies_and_no_real_people():
    """Los escenarios no mencionan marcas comerciales reales ni a integrantes del equipo."""

    for persona in PERSONAS.values():
        blob = " ".join([persona.label, persona.tagline, persona.greeting, build_instructions(persona)])
        for term in REAL_BRANDS_AND_PEOPLE:
            assert term not in blob, f"{persona.id}: menciona '{term}'"


def test_each_scenario_declares_a_fictional_company_or_person():
    for pid in PERSONA_IDS:
        assert "fictici" in PERSONAS[pid].instructions.lower(), pid


@pytest.mark.parametrize("persona_id", PERSONA_IDS)
def test_every_scenario_handles_unknown_information_and_simulated_actions(persona_id):
    instructions = build_instructions(PERSONAS[persona_id]).lower()

    assert "no inventes disponibilidad" in instructions
    assert "nunca afirmes que una operacion quedo realizada" in instructions
    assert "solo puedes simularla" in instructions
    assert "para cerrar" in instructions


@pytest.mark.parametrize(
    ("persona_id", "required_terms"),
    [
        ("claro-ventas", ("lunes a viernes", "600 000 1010", "contratacion es solo simulada")),
        ("falabella-cobranza", ("600 000 2020", "no solicites datos financieros reales")),
        ("clinica-dental", ("la agenda no esta conectada", "no entregas diagnosticos")),
        ("ripley-cobranza", ("600 000 3030", "informacion bancaria", "acuerdos vinculantes")),
        ("soporte-internet", ("600 000 4040", "sin afirmar que existe una orden real")),
        ("entrevista-rrhh", ("talento cordillera", "datos sensibles", "decision de contratacion")),
        ("hites-servicio", ("600 000 5050", "no se creo un reclamo", "no hay una cuenta conectada")),
    ],
)
def test_every_scenario_contains_its_business_context_and_restrictions(persona_id, required_terms):
    instructions = PERSONAS[persona_id].instructions.lower()

    for term in required_terms:
        assert term in instructions


def test_collection_options_and_commitments_are_explicitly_fictional():
    assert "opciones ficticias" in COLLECTION_RULES
    assert "simulas registrar" in COLLECTION_RULES
