"""Pruebas de la composicion del pipeline de voz (DART-14-2.4).

Ninguna llama a proveedores reales ni abre conexiones: las credenciales son
ficticias, las ADC de Google se simulan (la construccion de los plugins es
perezosa) y una prueba bloquea ``socket`` para demostrarlo. No validan la
conversacion real; eso queda para la validacion manual (ver README).
"""

import logging
import socket

import pytest
from livekit.agents import Agent, AgentSession, CloseEvent, CloseReason, ErrorEvent
from livekit.agents.llm import LLMError
from livekit.plugins import elevenlabs, google
from livekit.plugins import openai as livekit_openai
from livekit.plugins.google import stt as google_stt_module

from alloxentric_real_time_agent.config import (
    DEFAULT_LLM_PROVIDER,
    SUPPORTED_LLM_PROVIDERS,
    InvalidConfigurationError,
    MissingConfigurationError,
    load_llm_provider,
)
from alloxentric_real_time_agent.pipeline import (
    AGENT_INSTRUCTIONS,
    attach_observability,
    build_agent,
    build_agent_session,
    build_llm,
)
from alloxentric_real_time_agent.stt import MissingCredentialsError

GEMINI_KEY = "fake-google-key-AAAA1111"
DEEPSEEK_KEY = "fake-deepseek-key-BBBB2222"
ELEVEN_KEY = "fake-eleven-key-CCCC3333"

ENV = {
    "GOOGLE_CLOUD_PROJECT": "my-project",
    "GOOGLE_API_KEY": GEMINI_KEY,
    "DEEPSEEK_API_KEY": DEEPSEEK_KEY,
    "ELEVEN_API_KEY": ELEVEN_KEY,
}


@pytest.fixture(autouse=True)
def fake_adc(monkeypatch):
    monkeypatch.setattr(google_stt_module, "gauth_default", lambda *a, **k: (object(), "p"))


# --- load_llm_provider -------------------------------------------------------


def test_supported_providers_and_default():
    assert SUPPORTED_LLM_PROVIDERS == ("gemini", "deepseek")
    assert DEFAULT_LLM_PROVIDER == "gemini"


@pytest.mark.parametrize("env", [{}, {"LLM_PROVIDER": ""}, {"LLM_PROVIDER": "   "}])
def test_provider_defaults_to_gemini(env):
    assert load_llm_provider(env) == "gemini"


@pytest.mark.parametrize(
    ("value", "expected"),
    [("gemini", "gemini"), ("deepseek", "deepseek"), (" DeepSeek ", "deepseek")],
)
def test_provider_is_normalized(value, expected):
    assert load_llm_provider({"LLM_PROVIDER": value}) == expected


def test_invalid_provider_is_rejected_without_echoing_the_value():
    with pytest.raises(InvalidConfigurationError) as exc_info:
        load_llm_provider({"LLM_PROVIDER": "sk-secret-value-123"})

    message = str(exc_info.value)
    assert "sk-secret-value-123" not in message
    assert "gemini" in message and "deepseek" in message


# --- build_llm ---------------------------------------------------------------


def test_build_llm_selects_gemini_by_default():
    llm = build_llm(ENV)

    assert isinstance(llm, google.LLM)


def test_build_llm_selects_deepseek():
    llm = build_llm({**ENV, "LLM_PROVIDER": "deepseek"})

    assert isinstance(llm, livekit_openai.LLM)
    assert llm.model == "deepseek-flash"


def test_build_llm_rejects_invalid_provider():
    with pytest.raises(InvalidConfigurationError):
        build_llm({**ENV, "LLM_PROVIDER": "openai"})


def test_selected_provider_requires_only_its_own_credential():
    env = {"LLM_PROVIDER": "deepseek", "DEEPSEEK_API_KEY": DEEPSEEK_KEY}

    assert build_llm(env).model == "deepseek-flash"

    with pytest.raises(MissingConfigurationError) as exc_info:
        build_llm({"LLM_PROVIDER": "gemini", "DEEPSEEK_API_KEY": DEEPSEEK_KEY})
    assert exc_info.value.missing == ["GOOGLE_API_KEY"]


# --- build_agent_session -----------------------------------------------------


def test_build_agent_session_composes_the_three_components():
    session = build_agent_session(ENV)

    assert isinstance(session, AgentSession)
    assert isinstance(session.stt, google.STT)
    assert isinstance(session.llm, google.LLM)
    assert isinstance(session.tts, elevenlabs.TTS)


def test_build_agent_session_injects_google_credentials(monkeypatch):
    credentials = object()

    def unexpected_adc(*args, **kwargs):
        raise AssertionError("ADC no debe resolverse al construir la sesion")

    monkeypatch.setattr(google_stt_module, "gauth_default", unexpected_adc)

    session = build_agent_session(ENV, google_credentials=credentials)

    assert session.stt._credentials is credentials
    assert session.stt._project_id == "my-project"


def test_build_agent_session_with_deepseek():
    session = build_agent_session({**ENV, "LLM_PROVIDER": "deepseek"})

    assert isinstance(session.llm, livekit_openai.LLM)
    assert session.llm.model == "deepseek-flash"


def test_session_uses_the_builtin_vad_without_extra_plugins():
    session = build_agent_session(ENV)

    assert session.vad is not None
    assert type(session.vad).__module__.startswith("livekit.agents.inference")


def test_build_agent_session_rejects_invalid_provider_before_building_anything():
    with pytest.raises(InvalidConfigurationError):
        build_agent_session({"LLM_PROVIDER": "nope"})


def test_incomplete_configuration_lists_every_missing_variable():
    with pytest.raises(MissingConfigurationError) as exc_info:
        build_agent_session({})

    assert exc_info.value.missing == [
        "GOOGLE_CLOUD_PROJECT",
        "GOOGLE_API_KEY",
        "ELEVEN_API_KEY",
    ]


def test_incomplete_configuration_for_deepseek_asks_for_its_key_only():
    with pytest.raises(MissingConfigurationError) as exc_info:
        build_agent_session({"LLM_PROVIDER": "deepseek"})

    assert "DEEPSEEK_API_KEY" in exc_info.value.missing
    assert "GOOGLE_API_KEY" not in exc_info.value.missing


def test_missing_adc_surfaces_a_clear_error(monkeypatch):
    from google.auth.exceptions import DefaultCredentialsError

    def _no_adc(*_a, **_k):
        raise DefaultCredentialsError("Your default credentials were not found")

    monkeypatch.setattr(google_stt_module, "gauth_default", _no_adc)

    with pytest.raises(MissingCredentialsError):
        build_agent_session(ENV)


def test_errors_never_contain_secret_values():
    secrets = (GEMINI_KEY, DEEPSEEK_KEY, ELEVEN_KEY)

    with pytest.raises(MissingConfigurationError) as missing_exc:
        build_agent_session({"GOOGLE_API_KEY": GEMINI_KEY, "DEEPSEEK_API_KEY": DEEPSEEK_KEY})
    with pytest.raises(InvalidConfigurationError) as invalid_exc:
        build_agent_session({**ENV, "LLM_PROVIDER": "x"})

    for exc in (missing_exc.value, invalid_exc.value):
        for secret in secrets:
            assert secret not in str(exc)


def test_llm_provider_is_read_only_once_per_session():
    class CountingEnv(dict):
        reads = 0

        def get(self, key, default=None):
            if key == "LLM_PROVIDER":
                type(self).reads += 1
            return super().get(key, default)

    build_agent_session(CountingEnv({**ENV, "LLM_PROVIDER": "deepseek"}))

    assert CountingEnv.reads == 1


def test_building_the_session_never_touches_the_network(monkeypatch):
    def _blocked(*_args, **_kwargs):
        raise AssertionError("No se esperaba acceso a la red al construir la sesion")

    monkeypatch.setattr(socket, "socket", _blocked)
    monkeypatch.setattr(socket, "create_connection", _blocked)

    build_agent_session(ENV)
    build_agent_session({**ENV, "LLM_PROVIDER": "deepseek"})


def test_existing_builders_are_reused_unchanged():
    from alloxentric_real_time_agent import pipeline

    assert pipeline.build_deepseek_llm.__module__ == "alloxentric_real_time_agent.llm"
    assert pipeline.build_gemini_llm.__module__ == "alloxentric_real_time_agent.llm_gemini"
    assert pipeline.build_elevenlabs_tts.__module__ == "alloxentric_real_time_agent.tts"
    assert pipeline.create_google_stt.__module__ == "alloxentric_real_time_agent.stt"


# --- Agent -------------------------------------------------------------------


def test_build_agent_uses_the_temporary_test_instructions():
    agent = build_agent()

    assert isinstance(agent, Agent)
    assert agent.instructions == AGENT_INSTRUCTIONS
    assert "español" in AGENT_INSTRUCTIONS
    assert "No solicites información personal" in AGENT_INSTRUCTIONS


# --- Observabilidad ----------------------------------------------------------


def test_error_events_are_logged_without_the_exception_message(caplog):
    session = build_agent_session(ENV)
    attach_observability(session)
    secret = "super-secret-token-XYZ"
    event = ErrorEvent(
        error=LLMError(
            timestamp=0.0,
            label="livekit.plugins.google.LLM",
            error=RuntimeError(f"401 invalid key {secret}"),
            recoverable=False,
        ),
        source=session.llm,
    )

    with caplog.at_level(logging.INFO, logger="alloxentric_real_time_agent.pipeline"):
        session.emit("error", event)

    assert "llm_error" in caplog.text
    assert "RuntimeError" in caplog.text
    assert "recuperable=False" in caplog.text
    assert secret not in caplog.text
    assert "401" not in caplog.text


def test_close_events_log_only_the_reason(caplog):
    session = build_agent_session(ENV)
    attach_observability(session)

    with caplog.at_level(logging.INFO, logger="alloxentric_real_time_agent.pipeline"):
        session.emit("close", CloseEvent(reason=CloseReason.USER_INITIATED))

    assert "user_initiated" in caplog.text


# --- Entrypoint (DART-14-2.5) -------------------------------------------------


def _run_entrypoint(monkeypatch, metadata=None):
    """Ejecuta ``entrypoint`` con dobles: sin sesion, sala ni red reales."""

    import asyncio
    from types import SimpleNamespace
    from unittest.mock import AsyncMock, MagicMock

    from alloxentric_real_time_agent import agent as agent_module

    session = MagicMock()
    session.start = AsyncMock()
    credentials = object()
    ctx = SimpleNamespace(
        room=SimpleNamespace(name="sala-de-prueba"),
        connect=AsyncMock(),
        job=SimpleNamespace(metadata=metadata),
        proc=SimpleNamespace(userdata={agent_module.GOOGLE_ADC_USERDATA_KEY: credentials}),
    )
    monkeypatch.setattr(agent_module, "load_livekit_settings", lambda: None)
    build_session = MagicMock(return_value=session)
    monkeypatch.setattr(agent_module, "build_agent_session", build_session)
    monkeypatch.setattr(agent_module, "attach_observability", lambda s: None)

    # Loop propio: asyncio.run() deja el loop "actual" sin definir y afectaria
    # a las demas pruebas que construyen una AgentSession.
    loop = asyncio.new_event_loop()
    try:
        loop.run_until_complete(agent_module.entrypoint(ctx))
    finally:
        loop.close()
    return agent_module, session, ctx, build_session


def test_entrypoint_starts_the_session_with_recording_disabled(monkeypatch):
    _, session, ctx, build_session = _run_entrypoint(monkeypatch)

    session.start.assert_awaited_once()
    args, kwargs = session.start.await_args
    assert isinstance(args[0], Agent)
    assert kwargs["record"] is False
    assert kwargs["room"] is ctx.room
    ctx.connect.assert_awaited_once()
    build_session.assert_called_once_with(
        google_credentials=ctx.proc.userdata["google_adc_credentials"], persona=None
    )


def test_entrypoint_keeps_the_explicit_dispatch_agent_name(monkeypatch):
    import importlib

    from alloxentric_real_time_agent import agent as agent_module

    # El nombre se resuelve al importar el modulo: se fija el entorno para que
    # la prueba no dependa de la terminal (DART-14-5.1).
    monkeypatch.delenv("LIVEKIT_AGENT_NAME", raising=False)
    monkeypatch.delenv("LIVEKIT_AGENT_NAME_OVERRIDE", raising=False)
    try:
        importlib.reload(agent_module)
        assert agent_module.server._agent_name == "alloxentric-real-time-agent"
    finally:
        importlib.reload(agent_module)


def test_process_setup_resolves_adc_once_and_stores_it(monkeypatch):
    import asyncio
    from types import SimpleNamespace
    from unittest.mock import MagicMock

    from alloxentric_real_time_agent import agent as agent_module

    credentials = object()

    def resolve_without_event_loop():
        with pytest.raises(RuntimeError, match="no running event loop"):
            asyncio.get_running_loop()
        return credentials

    resolver = MagicMock(side_effect=resolve_without_event_loop)
    monkeypatch.setattr(agent_module, "resolve_google_adc", resolver)
    proc = SimpleNamespace(userdata={})

    agent_module.setup_process(proc)

    resolver.assert_called_once_with()
    assert proc.userdata[agent_module.GOOGLE_ADC_USERDATA_KEY] is credentials


def test_process_setup_propagates_missing_adc_without_partial_userdata(monkeypatch):
    from types import SimpleNamespace

    from alloxentric_real_time_agent import agent as agent_module

    def missing_adc():
        raise MissingCredentialsError()

    monkeypatch.setattr(agent_module, "resolve_google_adc", missing_adc)
    proc = SimpleNamespace(userdata={})

    with pytest.raises(MissingCredentialsError):
        agent_module.setup_process(proc)

    assert agent_module.GOOGLE_ADC_USERDATA_KEY not in proc.userdata
    assert proc.userdata == {}


def test_server_registers_adc_setup_with_safe_timeout():
    from alloxentric_real_time_agent import agent as agent_module

    assert agent_module.server.setup_fnc is agent_module.setup_process
    assert agent_module.server._initialize_process_timeout == 30.0
