"""Pruebas de validacion de configuracion (DART_14-1.5)."""

import pytest

from alloxentric_real_time_agent.config import (
    REQUIRED_LIVEKIT_VARS,
    MissingConfigurationError,
    load_livekit_settings,
)

VALID_ENV = {
    "LIVEKIT_URL": "wss://example.livekit.cloud",
    "LIVEKIT_API_KEY": "example-key",
    "LIVEKIT_API_SECRET": "example-secret",
}


def test_load_livekit_settings_succeeds_with_complete_env():
    settings = load_livekit_settings(VALID_ENV)

    assert settings.url == VALID_ENV["LIVEKIT_URL"]
    assert settings.api_key == VALID_ENV["LIVEKIT_API_KEY"]
    assert settings.api_secret == VALID_ENV["LIVEKIT_API_SECRET"]


@pytest.mark.parametrize("missing_var", REQUIRED_LIVEKIT_VARS)
def test_load_livekit_settings_raises_when_one_var_is_missing(missing_var):
    env = dict(VALID_ENV)
    del env[missing_var]

    with pytest.raises(MissingConfigurationError) as exc_info:
        load_livekit_settings(env)

    assert exc_info.value.missing == [missing_var]
    assert missing_var in str(exc_info.value)


def test_load_livekit_settings_raises_when_var_is_empty_string():
    env = dict(VALID_ENV)
    env["LIVEKIT_API_SECRET"] = ""

    with pytest.raises(MissingConfigurationError) as exc_info:
        load_livekit_settings(env)

    assert exc_info.value.missing == ["LIVEKIT_API_SECRET"]


def test_load_livekit_settings_raises_when_env_is_completely_empty():
    with pytest.raises(MissingConfigurationError) as exc_info:
        load_livekit_settings({})

    assert set(exc_info.value.missing) == set(REQUIRED_LIVEKIT_VARS)
