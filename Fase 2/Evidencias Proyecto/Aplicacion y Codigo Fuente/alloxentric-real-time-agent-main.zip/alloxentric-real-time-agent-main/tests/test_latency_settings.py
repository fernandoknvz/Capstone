"""Pruebas de los ajustes de latencia (DART-14-5.1). Sin red ni credenciales reales.

Verifican la CONFIGURACION; no demuestran la latencia real, que se mide con
las metricas de ``metrics.py`` en una sesion de voz real.
"""

import pytest

from alloxentric_real_time_agent.config import (
    DEFAULT_GEMINI_MODEL,
    DEFAULT_GEMINI_THINKING_LEVEL,
    InvalidConfigurationError,
    load_gemini_settings,
)
from alloxentric_real_time_agent.llm_gemini import MAX_OUTPUT_TOKENS, build_gemini_llm
from alloxentric_real_time_agent.pipeline import TURN_HANDLING
from alloxentric_real_time_agent.stt import ENDPOINTING_SENSITIVITY

ENV = {
    "GOOGLE_API_KEY": "fake-gemini",
    "GOOGLE_CLOUD_PROJECT": "p",
    "ELEVEN_API_KEY": "fake-eleven",
}


def test_default_gemini_model_is_the_lite_model_measured_faster():
    assert DEFAULT_GEMINI_MODEL == "gemini-3.1-flash-lite"


def test_thinking_level_defaults_to_minimal():
    settings = load_gemini_settings(ENV)

    assert settings.thinking_level == DEFAULT_GEMINI_THINKING_LEVEL == "MINIMAL"


@pytest.mark.parametrize("value", ["off", "OFF", "none", "false"])
def test_thinking_level_can_be_disabled(value):
    assert load_gemini_settings({**ENV, "GEMINI_THINKING_LEVEL": value}).thinking_level is None


def test_thinking_level_accepts_valid_levels_case_insensitively():
    assert load_gemini_settings({**ENV, "GEMINI_THINKING_LEVEL": "low"}).thinking_level == "LOW"


def test_invalid_thinking_level_is_rejected_without_echoing_the_value():
    with pytest.raises(InvalidConfigurationError) as exc_info:
        load_gemini_settings({**ENV, "GEMINI_THINKING_LEVEL": "secret-value-xyz"})

    assert "secret-value-xyz" not in str(exc_info.value)


def test_settings_repr_hides_the_api_key():
    assert "fake-gemini" not in repr(load_gemini_settings(ENV))


def test_gemini_llm_receives_thinking_config_and_output_cap():
    llm = build_gemini_llm(ENV)

    assert llm.model == DEFAULT_GEMINI_MODEL
    opts = llm._opts
    assert opts.max_output_tokens == MAX_OUTPUT_TOKENS
    assert str(opts.thinking_config.thinking_level).endswith("MINIMAL")


def test_gemini_llm_without_thinking_does_not_send_it():
    llm = build_gemini_llm({**ENV, "GEMINI_THINKING_LEVEL": "off"})

    assert not llm._opts.thinking_config


def test_chirp_uses_short_endpointing():
    assert ENDPOINTING_SENSITIVITY == "ENDPOINTING_SENSITIVITY_SHORT"


def test_turn_handling_is_low_latency_and_does_not_truncate_context():
    assert TURN_HANDLING["endpointing"]["min_delay"] < 0.5
    assert TURN_HANDLING["preemptive_generation"] == {"enabled": True, "preemptive_tts": True}
    assert "max_history" not in TURN_HANDLING
