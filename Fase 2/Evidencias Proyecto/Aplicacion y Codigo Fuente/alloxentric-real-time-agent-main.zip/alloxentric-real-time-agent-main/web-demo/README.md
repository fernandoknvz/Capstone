# Alloxentric web demo (WEB-01)

Base web independiente y exclusivamente de voz para evaluadores autorizados. El
frontend se publica como exportación estática de Next.js y las operaciones
sensibles se ejecutan en Netlify Functions.

## Seguridad

- El código de acceso se valida en el servidor y nunca se incluye en el bundle.
- La sesión temporal usa una cookie `HttpOnly`, `Secure` y `SameSite=Strict`.
- El endpoint LiveKit requiere una sesión válida y genera sala e identidad nuevas.
- El token permite publicar solamente micrófono y suscribirse al audio del agente.
- El servidor fuerza dispatch a `alloxentric-real-time-agent`; no confía en el
  nombre de agente, sala o identidad enviado por el navegador.
- Las Functions aplican rate limiting por dominio e IP y responden con
  `Cache-Control: no-store`.
- Cada build calcula hashes SHA-256 de los scripts inline emitidos por Next.js
  y genera `out/_headers`. La CSP permite solamente scripts del mismo origen y
  los contenidos inline exactos del build; no usa `unsafe-inline` ni
  `unsafe-eval` para scripts.
- `DEMO_ENABLED=false` bloquea nuevos accesos y tokens.
- La expiración del JWT limita su uso para conectar o reconectar; no constituye
  un límite estricto para una conexión que ya está activa.
- Si el inicio falla, la interfaz aborta el intento y desconecta la sala para
  liberar el micrófono antes de permitir otro intento. Si no puede confirmar la
  limpieza, solicita recargar la página.

La aplicación no ofrece cámara, pantalla, chat, transcripciones ni grabación.
El worker Python conserva `record=False` como control independiente.

## Configuración local

Requiere Node.js 24.x y pnpm 9.15.9. Copia `.env.example` a `.env.local` y usa
valores de desarrollo. No agregues `.env.local` a Git.

Para instalar y validar:

```powershell
pnpm install --frozen-lockfile
pnpm test
pnpm lint
pnpm typecheck
pnpm build
```

El frontend estático y sus cabeceras se generan en `out/`. El build falla si no
encuentra HTML, no puede cubrir los scripts inline o detecta un archivo
`out/_headers` inesperado. Para ejecutar conjuntamente el sitio y
las Netlify Functions en local se necesita Netlify CLI, que deliberadamente no
forma parte de las dependencias de WEB-01. Con la CLI ya instalada:

```powershell
netlify dev
```

No inicies el worker ni una conversación real durante las pruebas automatizadas.

## Variables de Netlify

Configura las variables de `.env.example` en Netlify con alcance Functions. No
uses el prefijo `NEXT_PUBLIC_` para secretos. En producción:

- `DEMO_ALLOWED_ORIGIN=https://demo.fernandoolgueadev.cl`
- `LIVEKIT_AGENT_NAME=alloxentric-real-time-agent`
- usa secretos aleatorios independientes para acceso y firma de sesión.

Genera la clave de firma como Base64URL sin padding a partir de, como mínimo,
32 bytes criptográficamente aleatorios. Ejecútalo fuera del repositorio y guarda
solamente el resultado en Netlify:

```powershell
node -e "console.log(require('node:crypto').randomBytes(32).toString('base64url'))"
```

El código temporal de acceso debe ser una frase ASCII no trivial de entre 16 y
128 caracteres. Genéralo con un gestor de contraseñas, entrégalo por un canal
separado y rótalo después de cada ventana de evaluación. La aplicación rechaza
formatos débiles, pero esa validación no sustituye la generación aleatoria.

En Netlify, establece `web-demo` como **Base directory**. La configuración local
usa `pnpm build`, publica `out/` y descubre las Functions en
`netlify/functions/`.

## Despliegue en Vercel (alternativa a Netlify)

Netlify sigue siendo el despliegue de referencia. Para Vercel se agregó una ruta paralela que **no** cambia el comportamiento en Netlify:

- **Funciones:** `vercel-functions/**` reutiliza la lógica de `netlify/functions/*.mts` y `scripts/build-vercel-functions.mts` la empaqueta con esbuild en `api/**.js` (salida generada, en `.gitignore`). Se empaqueta porque el empaquetador de Vercel no incluye los `.mts` reutilizados (`ERR_MODULE_NOT_FOUND`).
- **CSP:** Vercel no lee `out/_headers`. `scripts/vercel-postbuild.mts` inserta la misma política (con el hash de cada script en línea) como `<meta http-equiv="Content-Security-Policy">`; los demás encabezados están en `vercel.json`. `frame-ancestors` no existe en `<meta>`; lo cubre `X-Frame-Options: DENY`.
- **Región:** `vercel.json` fija las funciones en `gru1` (São Paulo, la más cercana a Chile; el plan Hobby permite una región).
- **Orígenes:** `DEMO_ALLOWED_ORIGIN` admite varios orígenes separados por coma (p. ej. el dominio propio y el `*.vercel.app`).
- **Despliegue:** se construye en local y se sube lo construido, sin conectar el repositorio:

  ```shell
  npx vercel@latest login      # una vez
  npx vercel@latest link --yes --project <nombre>
  # cargar las variables de .env.example con `vercel env add <NOMBRE> production`
  pnpm deploy:vercel
  ```

- **Límites conocidos:** Vercel solo aloja la web y las funciones de token; el agente de voz (proceso Python) **no** puede correr en Vercel. Sin límite de intentos por IP salvo que el plan de Vercel ofrezca firewall, por lo que el código de acceso debe ser largo y aleatorio.

## Flujo de uso

1. Inicia el worker Python local contra el mismo proyecto LiveKit Cloud.
2. Abre la URL HTTPS de la demo e ingresa el código temporal.
3. Presiona **Iniciar conversación** y autoriza únicamente el micrófono.
4. Presiona **Finalizar conversación** para ejecutar la desconexión explícita.
5. Detén el worker al terminar la ventana controlada de demostración.

Si el worker está desconectado o LiveKit rechaza el inicio, la interfaz muestra
un error y ejecuta la desconexión. No reintentes si el mensaje indica que el
cierre no pudo confirmarse: recarga primero la página.

## Limitaciones y riesgo aceptado

- El worker debe permanecer activo en el computador del desarrollador.
- El código de acceso es compartido y no identifica individualmente evaluadores.
- `DEMO_ENABLED=false` impide nuevas sesiones, pero no finaliza una conexión ya
  establecida; cada evaluador debe usar **Finalizar conversación**.
- No existe un límite fuerte de duración para una conversación LiveKit ya
  conectada. Esto mantiene un riesgo residual de consumo hasta que el usuario
  finalice la sesión o se detenga el worker.
- El logout elimina la cookie del navegador, pero no mantiene una lista de
  revocación para JWT ya emitidos; el riesgo residual está acotado por su TTL.
- En Windows, el almacén virtual de pnpm puede generar rutas superiores a 260
  caracteres. Se recomienda una ruta de checkout corta y soporte de rutas
  largas; no se observó una falla reproducible en la validación actual.
- La CSP se valida sobre el artefacto local. Su aplicación final por Netlify y
  la hidratación mediante las cabeceras reales continúan pendientes del primer
  despliegue autorizado.
- No existe grabación ni transcripción visible, y solo deben usarse datos ficticios.
- **SEC-WEB-01:** `braces@3.0.3` (`GHSA-vfj7-8cjw-p6xm`,
  `CVE-2026-93687`) permanece en la cadena de desarrollo de ESLint. No forma
  parte del runtime ni procesa patrones aportados por evaluadores. El riesgo de
  tooling se acepta temporalmente sin silenciar auditorías y debe revisarse el
  **2026-11-21**, o antes si aparece una versión corregida, cambia la cadena de
  dependencias o el paquete pasa a ser alcanzable desde runtime.

La primera validación real requiere una autorización separada porque consume
LiveKit Cloud, Google Chirp 3, Gemini y ElevenLabs.
