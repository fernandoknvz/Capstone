import type { Config } from '@netlify/functions';
import { json } from '../../lib/server/http';
import { expiredSessionCookie } from '../../lib/server/session';

export async function logout() {
  return json(204, {}, { 'Set-Cookie': expiredSessionCookie() });
}

export default logout;
export const config: Config = { path: '/api/demo/logout', method: 'POST' };
