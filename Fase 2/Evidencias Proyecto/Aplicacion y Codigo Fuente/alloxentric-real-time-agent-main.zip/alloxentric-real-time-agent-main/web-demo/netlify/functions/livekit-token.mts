import type { Config, Context } from '@netlify/functions';
import { loadDemoConfig } from '../../lib/server/config';
import { json, originAllowed, safeServerError } from '../../lib/server/http';
import { isPersonaId, type PersonaId } from '../../lib/personas';
import { createVoiceConnection } from '../../lib/server/livekit';
import { readCookie, verifySessionToken } from '../../lib/server/session';

// Única entrada del cuerpo que se respeta: `persona`, de una lista cerrada. El
// resto (agent_name, room_config, etc.) se ignora: el despacho lo fija el servidor.
async function requestedPersona(request: Request): Promise<PersonaId | undefined | 'invalid'> {
  const raw = await request.text();
  if (!raw) return undefined;
  if (raw.length > 2048) return 'invalid';
  let body: unknown;
  try { body = JSON.parse(raw); } catch { return undefined; }
  if (typeof body !== 'object' || body === null || !('persona' in body)) return undefined;
  const value = (body as { persona: unknown }).persona;
  return isPersonaId(value) ? value : 'invalid';
}

export async function livekitToken(request: Request, env: NodeJS.ProcessEnv = process.env) {
  try {
    const config = loadDemoConfig(env);
    if (!config.enabled) return json(503, { error: 'demo_disabled' });
    if (!originAllowed(request, config.allowedOrigin)) return json(403, { error: 'forbidden' });
    if (!(await verifySessionToken(readCookie(request), config.signingSecret))) {
      return json(401, { error: 'unauthorized' });
    }
    const persona = await requestedPersona(request);
    if (persona === 'invalid') return json(400, { error: 'invalid_persona' });
    const { server_url, participant_token } = await createVoiceConnection(env, persona);
    return json(201, { server_url, participant_token });
  } catch {
    return safeServerError();
  }
}

export default function handler(request: Request, context: Context) {
  void context;
  return livekitToken(request, process.env);
}
export const config: Config = {
  path: '/api/livekit-token',
  method: 'POST',
  rateLimit: { action: 'rate_limit', aggregateBy: ['domain', 'ip'], windowSize: 60, windowLimit: 6 },
};
