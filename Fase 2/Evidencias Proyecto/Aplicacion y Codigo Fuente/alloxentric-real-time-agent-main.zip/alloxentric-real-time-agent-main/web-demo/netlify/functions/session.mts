import type { Config, Context } from '@netlify/functions';
import { loadDemoConfig } from '../../lib/server/config';
import { json, safeServerError } from '../../lib/server/http';
import { readCookie, verifySessionToken } from '../../lib/server/session';

export async function sessionStatus(request: Request, env: NodeJS.ProcessEnv = process.env) {
  try {
    const config = loadDemoConfig(env);
    if (!config.enabled) return json(503, { error: 'demo_disabled' });
    const valid = await verifySessionToken(readCookie(request), config.signingSecret);
    return valid ? json(204, {}) : json(401, { error: 'unauthorized' });
  } catch {
    return safeServerError();
  }
}

export default function handler(request: Request, context: Context) {
  void context;
  return sessionStatus(request, process.env);
}
export const config: Config = {
  path: '/api/demo/session',
  method: 'GET',
  rateLimit: { action: 'rate_limit', aggregateBy: ['domain', 'ip'], windowSize: 60, windowLimit: 30 },
};
