import type { Config, Context } from '@netlify/functions';
import { loadDemoConfig } from '../../lib/server/config';
import { json, originAllowed, safeServerError } from '../../lib/server/http';
import { accessCodeMatches, createSessionToken, sessionCookie } from '../../lib/server/session';

export async function login(request: Request, env: NodeJS.ProcessEnv = process.env) {
  try {
    const config = loadDemoConfig(env);
    if (!config.enabled) return json(503, { error: 'demo_disabled' });
    if (!originAllowed(request, config.allowedOrigin)) return json(403, { error: 'forbidden' });
    const body = await request.json().catch(() => null) as { accessCode?: unknown } | null;
    if (typeof body?.accessCode !== 'string' || !accessCodeMatches(body.accessCode, config.accessSecret)) {
      return json(401, { error: 'unauthorized' });
    }
    const token = await createSessionToken(config.signingSecret, config.sessionTtlSeconds);
    return json(204, {}, { 'Set-Cookie': sessionCookie(token, config.sessionTtlSeconds) });
  } catch {
    return safeServerError();
  }
}

export default function handler(request: Request, context: Context) {
  void context;
  return login(request, process.env);
}
export const config: Config = {
  path: '/api/demo/login',
  method: 'POST',
  rateLimit: { action: 'rate_limit', aggregateBy: ['domain', 'ip'], windowSize: 60, windowLimit: 5 },
};
