# Third-party notices

The structure and LiveKit session integration of this demonstration were informed by
the `livekit-examples/agent-starter-react` project at commit
`9e1fc2f40fd7ceaccbe4a872b21765b49eefea80`.

That project is Copyright (c) 2025 LiveKit, Inc. and distributed under the MIT
License. Its full license is available at:
https://github.com/livekit-examples/agent-starter-react/blob/main/LICENSE

This demonstration uses an original, reduced implementation and does not include
the starter's camera, screen sharing, chat, transcript, or avatar components.
