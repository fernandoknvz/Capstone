// @vitest-environment node

import { decodeJwt } from 'jose';
import { TokenVerifier } from 'livekit-server-sdk';
import { describe, expect, it } from 'vitest';
import { livekitToken } from '@/netlify/functions/livekit-token.mts';
import { createSessionToken } from '@/lib/server/session';
import { cookieHeader, request, TEST_ENV } from './fixtures';

async function authorizedRequest() {
  const session = await createSessionToken(TEST_ENV.DEMO_SESSION_SIGNING_SECRET!, 300);
  return request('/api/livekit-token', {
    method: 'POST',
    headers: { Cookie: cookieHeader(session), 'Content-Type': 'application/json' },
    body: JSON.stringify({ room_config: { agents: [{ agent_name: 'attacker-agent' }] } }),
  });
}

describe('LiveKit token endpoint', () => {
  it('protects the endpoint with the evaluator session', async () => {
    const response = await livekitToken(request('/api/livekit-token', { method: 'POST' }), TEST_ENV);
    expect(response.status).toBe(401);
  });

  it('creates unique identities and rooms', async () => {
    const first = await livekitToken(await authorizedRequest(), TEST_ENV);
    const second = await livekitToken(await authorizedRequest(), TEST_ENV);
    const firstPayload = decodeJwt((await first.json()).participant_token);
    const secondPayload = decodeJwt((await second.json()).participant_token);
    expect(firstPayload.sub).not.toBe(secondPayload.sub);
    expect((firstPayload.video as { room: string }).room).not.toBe((secondPayload.video as { room: string }).room);
  });

  it('forces explicit dispatch and minimum voice-only grants on the server', async () => {
    const response = await livekitToken(await authorizedRequest(), TEST_ENV);
    expect(response.status).toBe(201);
    expect(response.headers.get('cache-control')).toContain('no-store');
    const body = await response.json();
    expect(body.server_url).toBe(TEST_ENV.LIVEKIT_URL);

    const claims = await new TokenVerifier(
      TEST_ENV.LIVEKIT_API_KEY!, TEST_ENV.LIVEKIT_API_SECRET!,
    ).verify(body.participant_token);
    expect(claims.video).toMatchObject({
      roomJoin: true,
      canPublish: true,
      canPublishData: false,
      canSubscribe: true,
      canUpdateOwnMetadata: false,
      canPublishSources: ['microphone'],
    });
    expect(claims.video?.room).toMatch(/^demo-/);
    expect(claims.roomConfig?.agents).toHaveLength(1);
    expect(claims.roomConfig?.agents[0]?.agentName).toBe('alloxentric-real-time-agent');
    expect(claims.roomConfig?.agents[0]?.agentName).not.toBe('attacker-agent');
    const jwt = decodeJwt(body.participant_token);
    expect(jwt.exp! - jwt.nbf!).toBe(300);
  });

  it('returns a generic error when server configuration is incomplete', async () => {
    const response = await livekitToken(await authorizedRequest(), { ...TEST_ENV, LIVEKIT_API_SECRET: '' });
    expect(response.status).toBe(500);
    expect(await response.json()).toEqual({ error: 'service_unavailable' });
  });
});
