// @vitest-environment node

import { createHash } from 'node:crypto';
import { mkdtemp, mkdir, readFile, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { afterEach, describe, expect, it } from 'vitest';
import {
  createHeaders,
  generateCspHeaders,
  inlineScriptHashes,
  validateHeaders,
} from '@/scripts/generate-csp-headers.mts';

const temporaryDirectories: string[] = [];

async function temporaryOutput() {
  const directory = await mkdtemp(join(tmpdir(), 'alloxentric-csp-'));
  temporaryDirectories.push(directory);
  return directory;
}

afterEach(async () => {
  await Promise.all(temporaryDirectories.splice(0).map((directory) => rm(directory, { recursive: true })));
});

describe('static export CSP headers', () => {
  it('hashes every inline script across every HTML file', async () => {
    const output = await temporaryOutput();
    await mkdir(join(output, 'nested'));
    await writeFile(join(output, 'index.html'), '<script src="/app.js"></script><script>first()</script>');
    await writeFile(join(output, 'nested', 'index.html'), '<script>second()</script>');

    const target = await generateCspHeaders(output);
    const headers = await readFile(target, 'utf8');
    for (const script of ['first()', 'second()']) {
      const digest = createHash('sha256').update(script).digest('base64');
      expect(headers).toContain(`'sha256-${digest}'`);
    }
    expect(headers).not.toContain("'unsafe-inline'");
    expect(headers).not.toContain("'unsafe-eval'");
    expect(headers.match(/Content-Security-Policy:/g)).toHaveLength(1);
  });

  it('fails when the static export has no HTML', async () => {
    await expect(generateCspHeaders(await temporaryOutput())).rejects.toThrow('No HTML files');
  });

  it('fails validation when a generated hash is missing', () => {
    const hashes = inlineScriptHashes('<script>allowed()</script><script>alsoAllowed()</script>');
    const incomplete = createHeaders(hashes).replace(hashes[0], '');
    expect(() => validateHeaders(incomplete, hashes)).toThrow('is missing');
  });

  it('keeps the CSP single-sourced and preserves the required security headers', async () => {
    const netlifyConfig = await readFile(new URL('../netlify.toml', import.meta.url), 'utf8');
    const headers = createHeaders(["'sha256-dGVzdA=='"]);

    expect(netlifyConfig).not.toMatch(/Content-Security-Policy/i);
    expect(headers.match(/Content-Security-Policy:/g)).toHaveLength(1);
    for (const expected of [
      'X-Content-Type-Options: nosniff',
      'Referrer-Policy: no-referrer',
      'Permissions-Policy: camera=(), display-capture=(), microphone=(self)',
      'X-Frame-Options: DENY',
      '/api/*\n  Cache-Control: no-store, max-age=0',
    ]) {
      expect(headers).toContain(expected);
    }
  });

  it('refuses to overwrite an unexpected headers file', async () => {
    const output = await temporaryOutput();
    await writeFile(join(output, 'index.html'), '<script>allowed()</script>');
    await writeFile(join(output, '_headers'), 'user-managed content');
    await expect(generateCspHeaders(output)).rejects.toThrow('Refusing to overwrite');
  });
});
