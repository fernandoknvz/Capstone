import { fireEvent, render, screen } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';
import { VoiceControls } from '@/components/voice-controls';

describe('voice controls', () => {
  it('starts a disconnected session', () => {
    const start = vi.fn();
    render(<VoiceControls connected={false} connecting={false} onStart={start} onEnd={vi.fn()} />);
    fireEvent.click(screen.getByRole('button', { name: 'Iniciar conversación' }));
    expect(start).toHaveBeenCalledOnce();
  });

  it('ends a connected session', () => {
    const end = vi.fn();
    render(<VoiceControls connected connecting={false} onStart={vi.fn()} onEnd={end} />);
    fireEvent.click(screen.getByRole('button', { name: 'Finalizar conversación' }));
    expect(end).toHaveBeenCalledOnce();
  });
});
