// @vitest-environment node

import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';

describe('client secret boundary', () => {
  it('does not reference server credentials from client components', () => {
    for (const file of ['demo-app.tsx', 'voice-session.tsx', 'voice-controls.tsx']) {
      const source = readFileSync(join(process.cwd(), 'components', file), 'utf8');
      expect(source).not.toContain('LIVEKIT_API_SECRET');
      expect(source).not.toContain('LIVEKIT_API_KEY');
      expect(source).not.toContain('DEMO_ACCESS_SECRET');
      expect(source).not.toContain('DEMO_SESSION_SIGNING_SECRET');
      expect(source).not.toContain('NEXT_PUBLIC_');
    }
  });
});
