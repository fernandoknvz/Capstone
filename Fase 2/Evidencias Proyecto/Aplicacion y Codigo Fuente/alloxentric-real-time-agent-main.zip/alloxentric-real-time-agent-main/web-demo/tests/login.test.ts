// @vitest-environment node

import { describe, expect, it } from 'vitest';
import { login } from '@/netlify/functions/login.mts';
import { sessionStatus } from '@/netlify/functions/session.mts';
import { SESSION_COOKIE } from '@/lib/server/session';
import { request, TEST_ENV } from './fixtures';

describe('evaluator login', () => {
  it('creates a secure temporary session for the correct code', async () => {
    const response = await login(request('/api/demo/login', {
      method: 'POST',
      body: JSON.stringify({ accessCode: TEST_ENV.DEMO_ACCESS_SECRET }),
    }), TEST_ENV);
    expect(response.status).toBe(204);
    expect(response.headers.get('set-cookie')).toContain(SESSION_COOKIE);
    expect(response.headers.get('cache-control')).toContain('no-store');
  });

  it('rejects an incorrect code without returning configuration details', async () => {
    const response = await login(request('/api/demo/login', {
      method: 'POST',
      body: JSON.stringify({ accessCode: 'incorrect' }),
    }), TEST_ENV);
    expect(response.status).toBe(401);
    expect(await response.json()).toEqual({ error: 'unauthorized' });
  });

  it('rejects a foreign origin', async () => {
    const response = await login(new Request('https://demo.example.test/api/demo/login', {
      method: 'POST',
      headers: { Origin: 'https://attacker.example' },
      body: JSON.stringify({ accessCode: TEST_ENV.DEMO_ACCESS_SECRET }),
    }), TEST_ENV);
    expect(response.status).toBe(403);
  });

  it('disables access when DEMO_ENABLED is false', async () => {
    const response = await login(request('/api/demo/login', {
      method: 'POST', body: JSON.stringify({ accessCode: TEST_ENV.DEMO_ACCESS_SECRET }),
    }), { ...TEST_ENV, DEMO_ENABLED: 'false' });
    expect(response.status).toBe(503);
  });

  it('rejects an expired or absent session', async () => {
    const response = await sessionStatus(request('/api/demo/session'), TEST_ENV);
    expect(response.status).toBe(401);
  });

  it.each(['%', '%ZZ', '%A'])('rejects malformed cookie encoding without a server error: %s', async (value) => {
    const response = await sessionStatus(request('/api/demo/session', {
      headers: { Cookie: `${SESSION_COOKIE}=${value}` },
    }), TEST_ENV);
    expect(response.status).toBe(401);
    expect(await response.json()).toEqual({ error: 'unauthorized' });
  });
});
