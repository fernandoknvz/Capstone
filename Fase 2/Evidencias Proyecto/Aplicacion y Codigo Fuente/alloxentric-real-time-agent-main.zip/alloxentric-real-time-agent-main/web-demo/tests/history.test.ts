import { beforeEach, describe, expect, it } from 'vitest';
import {
  clearHistory,
  conversationToText,
  deleteConversation,
  HISTORY_KEY,
  loadHistory,
  MAX_ENTRIES,
  MAX_TEXT,
  saveConversation,
  type HistoryEntry,
} from '@/lib/history';

function entry(id: string, overrides: Partial<HistoryEntry> = {}): HistoryEntry {
  return {
    id,
    personaId: 'claro-ventas',
    startedAt: 1_700_000_000_000,
    messages: [{ id: `${id}-1`, role: 'user', text: 'Hola', timestamp: 1_700_000_000_500 }],
    ...overrides,
  };
}

describe('conversation history', () => {
  beforeEach(() => localStorage.clear());

  it('starts empty', () => {
    expect(loadHistory()).toEqual([]);
  });

  it('saves and reloads a conversation, newest first', () => {
    saveConversation(entry('a'));
    saveConversation(entry('b'));
    expect(loadHistory().map((item) => item.id)).toEqual(['b', 'a']);
  });

  it('updates an existing conversation instead of duplicating it', () => {
    saveConversation(entry('a'));
    saveConversation(entry('a', { messages: [
      { id: 'a-1', role: 'user', text: 'Hola', timestamp: 1 },
      { id: 'a-2', role: 'agent', text: 'Buenas', timestamp: 2 },
    ] }));
    const items = loadHistory();
    expect(items).toHaveLength(1);
    expect(items[0].messages).toHaveLength(2);
  });

  it('does not store empty conversations', () => {
    expect(saveConversation(entry('a', { messages: [] }))).toBe(false);
    expect(loadHistory()).toEqual([]);
  });

  it('keeps only the most recent entries and truncates long texts', () => {
    for (let i = 0; i < MAX_ENTRIES + 5; i += 1) saveConversation(entry(`c${i}`));
    expect(loadHistory()).toHaveLength(MAX_ENTRIES);
    saveConversation(entry('long', { messages: [{ id: 'l', role: 'agent', text: 'x'.repeat(MAX_TEXT + 500), timestamp: 1 }] }));
    expect(loadHistory()[0].messages[0].text).toHaveLength(MAX_TEXT);
  });

  it('deletes one conversation and clears all', () => {
    saveConversation(entry('a'));
    saveConversation(entry('b'));
    deleteConversation('a');
    expect(loadHistory().map((item) => item.id)).toEqual(['b']);
    clearHistory();
    expect(loadHistory()).toEqual([]);
  });

  it('survives corrupted or malformed stored data', () => {
    localStorage.setItem(HISTORY_KEY, '{not json');
    expect(loadHistory()).toEqual([]);
    localStorage.setItem(HISTORY_KEY, JSON.stringify([{ id: 1 }, entry('ok')]));
    expect(loadHistory().map((item) => item.id)).toEqual(['ok']);
  });

  it('exports a readable text transcript', () => {
    const text = conversationToText(entry('a'), 'Ventas de telefonía');
    expect(text).toContain('Ventas de telefonía');
    expect(text).toContain('Tú: Hola');
  });
});
