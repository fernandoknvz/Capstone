import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { ConnectionState } from 'livekit-client';
import { VoiceSession } from '@/components/voice-session';

const start = vi.fn();
const end = vi.fn();
const session = {
  start,
  end,
  connectionState: ConnectionState.Disconnected,
  isConnected: false,
};

vi.mock('@livekit/components-react', () => ({
  RoomAudioRenderer: () => null,
  SessionProvider: ({ children }: { children: React.ReactNode }) => children,
  useSession: () => session,
  useSessionMessages: () => ({ messages: [] }),
  useAgent: () => ({ state: 'listening' }),
  useMediaDeviceSelect: () => ({ devices: [], activeDeviceId: '', setActiveMediaDevice: vi.fn() }),
  useTrackToggle: () => ({ enabled: true, pending: false, toggle: vi.fn() }),
}));

describe('voice session lifecycle', () => {
  beforeEach(() => {
    start.mockReset();
    end.mockReset();
    session.connectionState = ConnectionState.Disconnected;
    session.isConnected = false;
    end.mockResolvedValue(undefined);
  });

  it('waits for explicit confirmation before starting a persona session', async () => {
    render(<VoiceSession onLogout={vi.fn()} persona="clinica-dental" onExit={vi.fn()} />);
    expect(start).not.toHaveBeenCalled();
    fireEvent.click(screen.getByRole('button', { name: 'Iniciar conversación' }));
    await waitFor(() => expect(start).toHaveBeenCalledOnce());
  });

  it('starts successfully without closing the session', async () => {
    start.mockResolvedValue(undefined);
    const view = render(<VoiceSession onLogout={vi.fn()} />);
    fireEvent.click(screen.getByRole('button', { name: 'Iniciar conversación' }));
    await waitFor(() => expect(start).toHaveBeenCalledOnce());
    expect(start.mock.calls[0][0].signal).toBeInstanceOf(AbortSignal);
    expect(end).not.toHaveBeenCalled();
    view.unmount();
  });

  it('ends and returns to a safe state when start fails', async () => {
    start.mockRejectedValue(new Error('connection failed'));
    render(<VoiceSession onLogout={vi.fn()} />);
    fireEvent.click(screen.getByRole('button', { name: 'Iniciar conversación' }));
    await screen.findByRole('alert');
    expect(end).toHaveBeenCalledOnce();
    expect(start.mock.calls[0][0].signal.aborted).toBe(true);
    expect(screen.getByText('Listo para iniciar')).toBeTruthy();
    expect((screen.getByRole('button', { name: 'Iniciar conversación' }) as HTMLButtonElement).disabled).toBe(false);
  });

  it('cleans up when start fails after the room became connected', async () => {
    start.mockImplementation(async () => {
      session.connectionState = ConnectionState.Connected;
      session.isConnected = true;
      throw new Error('agent unavailable');
    });
    render(<VoiceSession onLogout={vi.fn()} />);
    fireEvent.click(screen.getByRole('button', { name: 'Iniciar conversación' }));
    await waitFor(() => expect(end).toHaveBeenCalledOnce());
  });

  it('preserves the startup failure and reports an unconfirmed cleanup', async () => {
    start.mockRejectedValue(new Error('startup failed'));
    end.mockRejectedValue(new Error('cleanup failed'));
    render(<VoiceSession onLogout={vi.fn()} />);
    fireEvent.click(screen.getByRole('button', { name: 'Iniciar conversación' }));
    expect((await screen.findByRole('alert')).textContent).toContain('No fue posible iniciar la conversación');
    expect(screen.getByRole('alert').textContent).toContain('no se pudo confirmar el cierre');
  });

  it('prevents duplicate starts while an attempt is pending', async () => {
    let resolveStart!: () => void;
    start.mockImplementation(() => new Promise<void>((resolve) => { resolveStart = resolve; }));
    render(<VoiceSession onLogout={vi.fn()} />);
    const button = screen.getByRole('button', { name: 'Iniciar conversación' });
    fireEvent.click(button);
    fireEvent.click(button);
    expect(start).toHaveBeenCalledOnce();
    resolveStart();
    await waitFor(() => {
      expect((screen.getByRole('button', { name: 'Iniciar conversación' }) as HTMLButtonElement).disabled).toBe(false);
    });
  });

  it('aborts and closes the session when the component unmounts', async () => {
    let signal!: AbortSignal;
    start.mockImplementation(({ signal: currentSignal }) => {
      signal = currentSignal;
      return new Promise<void>(() => undefined);
    });
    const view = render(<VoiceSession onLogout={vi.fn()} />);
    fireEvent.click(screen.getByRole('button', { name: 'Iniciar conversación' }));
    await waitFor(() => expect(start).toHaveBeenCalledOnce());
    view.unmount();
    expect(signal.aborted).toBe(true);
    await waitFor(() => expect(end).toHaveBeenCalledOnce());
  });
});
