// @vitest-environment node

import { describe, expect, it } from 'vitest';
import {
  SESSION_COOKIE,
  accessCodeMatches,
  createSessionToken,
  expiredSessionCookie,
  readCookie,
  sessionCookie,
  verifySessionToken,
} from '@/lib/server/session';

const SECRET = '0123456789abcdef0123456789abcdef';

describe('temporary evaluator session', () => {
  it('compares access codes without accepting a different value', () => {
    expect(accessCodeMatches('allowed', 'allowed')).toBe(true);
    expect(accessCodeMatches('wrong', 'allowed')).toBe(false);
  });

  it('accepts a valid signed session and rejects an expired one', async () => {
    const valid = await createSessionToken(SECRET, 60);
    const expired = await createSessionToken(SECRET, 1, new Date('2000-01-01T00:00:00Z'));
    expect(await verifySessionToken(valid, SECRET)).toBe(true);
    expect(await verifySessionToken(expired, SECRET)).toBe(false);
  });

  it('uses hardened cookie attributes and can expire the cookie', () => {
    expect(sessionCookie('token', 60)).toContain('HttpOnly');
    expect(sessionCookie('token', 60)).toContain('Secure');
    expect(sessionCookie('token', 60)).toContain('SameSite=Strict');
    expect(sessionCookie('token', 60)).toContain('Path=/');
    expect(expiredSessionCookie()).toContain('Max-Age=0');
  });

  it('reads valid cookies and treats missing or malformed cookies as invalid', () => {
    expect(readCookie(new Request('https://demo.example.test'))).toBeUndefined();
    expect(readCookie(new Request('https://demo.example.test', {
      headers: { Cookie: `${SESSION_COOKIE}=valid%20token` },
    }))).toBe('valid token');
    for (const value of ['%', '%ZZ', '%A']) {
      expect(readCookie(new Request('https://demo.example.test', {
        headers: { Cookie: `${SESSION_COOKIE}=${value}` },
      }))).toBeUndefined();
    }
  });
});
