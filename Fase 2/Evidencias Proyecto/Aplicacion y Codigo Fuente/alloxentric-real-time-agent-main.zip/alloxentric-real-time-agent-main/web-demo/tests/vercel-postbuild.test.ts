// @vitest-environment node

import { createHash } from 'node:crypto';
import { mkdtemp, readFile, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';
import { addCspMeta, cspPolicy, injectCsp } from '../scripts/vercel-postbuild.mts';

const INLINE = 'self.__next_f.push([1,"hola"])';
const hash = `'sha256-${createHash('sha256').update(INLINE, 'utf8').digest('base64')}'`;
const PAGE = `<!DOCTYPE html><html><head><meta charSet="utf-8"/><script src="/a.js"></script></head><body><script>${INLINE}</script></body></html>`;

describe('Vercel CSP meta tag', () => {
  it('puts the CSP as the first element of <head> with the hash of every inline script', () => {
    const html = injectCsp(PAGE);
    expect(html).toMatch(/<head><meta http-equiv="Content-Security-Policy" content="[^"]+"\/><meta charSet/);
    expect(html).toContain(`script-src 'self' ${hash}`);
  });

  it('does not allow inline scripts without a hash nor eval', () => {
    const policy = cspPolicy([hash]);
    expect(policy).not.toContain('unsafe-inline');
    expect(policy).not.toContain('unsafe-eval');
    expect(policy).toContain("default-src 'self'");
    expect(policy).toContain("style-src 'self'");
  });

  it('keeps the LiveKit endpoints and omits frame-ancestors (not allowed in <meta>)', () => {
    const policy = cspPolicy([]);
    expect(policy).toContain('wss://*.livekit.cloud');
    expect(policy).not.toContain('frame-ancestors');
    expect(policy).toContain("script-src 'self'");
  });

  it('refuses pages that already declare a CSP or have no <head>', () => {
    expect(() => injectCsp(injectCsp(PAGE))).toThrow('already declares');
    expect(() => injectCsp('<html><body></body></html>')).toThrow('no <head>');
  });

  it('adds the meta tag to every exported HTML file', async () => {
    const dir = await mkdtemp(join(tmpdir(), 'csp-'));
    try {
      await writeFile(join(dir, 'index.html'), PAGE);
      await writeFile(join(dir, '404.html'), '<html><head></head><body>404</body></html>');
      await addCspMeta(dir);
      expect(await readFile(join(dir, 'index.html'), 'utf8')).toContain(hash);
      expect(await readFile(join(dir, '404.html'), 'utf8')).toContain("script-src 'self'");
    } finally {
      await rm(dir, { recursive: true, force: true });
    }
  });
});
