import { SESSION_COOKIE } from '@/lib/server/session';

export const TEST_ENV: NodeJS.ProcessEnv = {
  NODE_ENV: 'test',
  DEMO_ENABLED: 'true',
  DEMO_ACCESS_SECRET: 'correct-horse-battery-staple',
  DEMO_SESSION_SIGNING_SECRET: 'AAECAwQFBgcICQoLDA0ODxAREhMUFRYXGBkaGxwdHh8',
  DEMO_ALLOWED_ORIGIN: 'https://demo.example.test',
  DEMO_SESSION_TTL_SECONDS: '1800',
  DEMO_LIVEKIT_TOKEN_TTL_SECONDS: '300',
  LIVEKIT_URL: 'wss://example.livekit.cloud',
  LIVEKIT_API_KEY: 'test-api-key',
  LIVEKIT_API_SECRET: 'test-api-secret-with-enough-entropy',
  LIVEKIT_AGENT_NAME: 'alloxentric-real-time-agent',
};

export function request(path: string, init: RequestInit = {}) {
  return new Request(`https://demo.example.test${path}`, {
    ...init,
    headers: { Origin: TEST_ENV.DEMO_ALLOWED_ORIGIN!, ...init.headers },
  });
}

export function cookieHeader(token: string) {
  return `${SESSION_COOKIE}=${encodeURIComponent(token)}`;
}
