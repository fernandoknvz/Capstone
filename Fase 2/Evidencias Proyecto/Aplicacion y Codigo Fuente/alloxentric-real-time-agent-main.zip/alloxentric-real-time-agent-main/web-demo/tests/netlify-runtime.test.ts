// @vitest-environment node

import type { Context } from '@netlify/functions';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import livekitTokenHandler from '@/netlify/functions/livekit-token.mts';
import loginHandler from '@/netlify/functions/login.mts';
import sessionHandler from '@/netlify/functions/session.mts';
import * as livekit from '@/lib/server/livekit';
import { request, TEST_ENV } from './fixtures';

const NETLIFY_CONTEXT = {
  requestId: 'test-request-id',
  DEMO_ENABLED: 'true',
} as unknown as Context;

beforeEach(() => {
  for (const [name, value] of Object.entries({ ...TEST_ENV, DEMO_ENABLED: 'false' })) {
    vi.stubEnv(name, value!);
  }
});

afterEach(() => {
  vi.restoreAllMocks();
  vi.unstubAllEnvs();
});

describe('Netlify runtime handlers', () => {
  it('uses process.env instead of Context for the session endpoint', async () => {
    const response = await sessionHandler(request('/api/demo/session'), NETLIFY_CONTEXT);

    expect(response.status).toBe(503);
    expect(await response.json()).toEqual({ error: 'demo_disabled' });
  });

  it('uses process.env instead of Context for the login endpoint', async () => {
    const response = await loginHandler(request('/api/demo/login', {
      method: 'POST',
      body: JSON.stringify({ accessCode: TEST_ENV.DEMO_ACCESS_SECRET }),
    }), NETLIFY_CONTEXT);

    expect(response.status).toBe(503);
    expect(response.headers.get('set-cookie')).toBeNull();
    expect(await response.json()).toEqual({ error: 'demo_disabled' });
  });

  it('does not use LiveKit when the runtime demo is disabled', async () => {
    const createVoiceConnection = vi.spyOn(livekit, 'createVoiceConnection');

    const response = await livekitTokenHandler(
      request('/api/livekit-token', { method: 'POST' }),
      NETLIFY_CONTEXT,
    );

    expect(response.status).toBe(503);
    expect(createVoiceConnection).not.toHaveBeenCalled();
    expect(await response.json()).toEqual({ error: 'demo_disabled' });
  });

  it('keeps configuration failures generic at the public boundary', async () => {
    vi.stubEnv('DEMO_ACCESS_SECRET', 'short');

    const response = await sessionHandler(request('/api/demo/session'), NETLIFY_CONTEXT);

    expect(response.status).toBe(500);
    expect(await response.json()).toEqual({ error: 'service_unavailable' });
  });
});
