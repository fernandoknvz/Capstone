import { fireEvent, render, screen } from '@testing-library/react';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { ConversationPanel } from '@/components/conversation-panel';
import { PersonaPicker } from '@/components/persona-picker';
import { PERSONAS } from '@/lib/personas';
import { loadHistory } from '@/lib/history';

const toggle = vi.fn();
const setActiveMediaDevice = vi.fn();
const state = {
  messages: [] as Array<{ id: string; type: string; message: string; timestamp: number; attributes?: Record<string, string> }>,
  enabled: true,
  agentState: 'listening',
  devices: [
    { deviceId: 'mic-1', label: 'Micrófono USB' },
    { deviceId: 'mic-2', label: '' },
  ],
};

vi.mock('@livekit/components-react', () => ({
  useAgent: () => ({ state: state.agentState }),
  useSessionMessages: () => ({ messages: state.messages }),
  useMediaDeviceSelect: () => ({
    devices: state.devices,
    activeDeviceId: 'mic-1',
    setActiveMediaDevice,
  }),
  useTrackToggle: () => ({ enabled: state.enabled, pending: false, toggle }),
}));

function panel(connected = true) {
  return render(<ConversationPanel conversationId="conv-1" personaId="claro-ventas" startedAt={1_700_000_000_000} connected={connected} />);
}

describe('conversation panel', () => {
  beforeEach(() => {
    localStorage.clear();
    toggle.mockReset();
    setActiveMediaDevice.mockReset();
    state.messages = [];
    state.enabled = true;
    state.agentState = 'listening';
  });

  it('shows the live transcript for the user and the agent', () => {
    state.messages = [
      { id: 'm1', type: 'userTranscript', message: 'Hola, quiero un plan', timestamp: 1 },
      { id: 'm2', type: 'agentTranscript', message: 'Perfecto, ¿cuántos datos usas?', timestamp: 2 },
      { id: 'm3', type: 'chatMessage', message: 'ignorado', timestamp: 3 },
    ];
    panel();
    expect(screen.getByText('Hola, quiero un plan')).toBeTruthy();
    expect(screen.getByText('Perfecto, ¿cuántos datos usas?')).toBeTruthy();
    expect(screen.queryByText('ignorado')).toBeNull();
  });

  it('shows each user utterance once even when LiveKit sends interim and final copies of one segment', () => {
    state.messages = [
      { id: 's1-a', type: 'userTranscript', message: 'No quiero', timestamp: 10, attributes: { 'lk.segment_id': 'SG_1' } },
      { id: 's1-b', type: 'userTranscript', message: 'No quiero pagarla.', timestamp: 12, attributes: { 'lk.segment_id': 'SG_1' } },
      { id: 's1-c', type: 'userTranscript', message: 'No quiero pagarla.', timestamp: 13, attributes: { 'lk.segment_id': 'SG_1' } },
      { id: 'a1', type: 'agentTranscript', message: 'Entiendo.', timestamp: 14, attributes: { 'lk.segment_id': 'SG_2' } },
    ];
    panel();
    expect(screen.getAllByText('No quiero pagarla.')).toHaveLength(1);
    expect(screen.queryByText('No quiero')).toBeNull();
    expect(screen.getAllByText('Entiendo.')).toHaveLength(1);
    expect(loadHistory()[0].messages).toHaveLength(2);
  });

  it('keeps the order of the first message of each segment', () => {
    state.messages = [
      { id: 'u2', type: 'userTranscript', message: 'segunda', timestamp: 20, attributes: { 'lk.segment_id': 'B' } },
      { id: 'u1', type: 'userTranscript', message: 'primera', timestamp: 5, attributes: { 'lk.segment_id': 'A' } },
    ];
    panel();
    const texts = screen.getAllByText(/primera|segunda/).map((node) => node.textContent);
    expect(texts[0]).toContain('primera');
    expect(texts[1]).toContain('segunda');
  });

  it('saves the conversation to the local history as it grows', () => {
    state.messages = [{ id: 'm1', type: 'userTranscript', message: 'Hola', timestamp: 1 }];
    panel();
    const [saved] = loadHistory();
    expect(saved.id).toBe('conv-1');
    expect(saved.personaId).toBe('claro-ventas');
    expect(saved.messages.map((m) => m.text)).toEqual(['Hola']);
  });

  it('does not save anything while there are no messages', () => {
    panel();
    expect(loadHistory()).toEqual([]);
  });

  it('lets the user pick the microphone', () => {
    panel();
    const select = screen.getByLabelText('Micrófono') as HTMLSelectElement;
    expect(select.value).toBe('mic-1');
    expect(screen.getByText('Micrófono 2')).toBeTruthy();
    fireEvent.change(select, { target: { value: 'mic-2' } });
    expect(setActiveMediaDevice).toHaveBeenCalledWith('mic-2');
  });

  it('mutes and unmutes with the toggle button', () => {
    const view = panel();
    fireEvent.click(screen.getByRole('button', { name: 'Silenciar micrófono' }));
    expect(toggle).toHaveBeenCalledOnce();
    state.enabled = false;
    view.rerender(<ConversationPanel conversationId="conv-1" personaId="claro-ventas" startedAt={1} connected />);
    const button = screen.getByRole('button', { name: 'Activar micrófono' });
    expect(button.getAttribute('aria-pressed')).toBe('true');
    expect(screen.getByText('Estás silenciado: el agente no te escucha.')).toBeTruthy();
  });

  it('disables microphone controls when not connected', () => {
    panel(false);
    expect((screen.getByRole('button', { name: 'Silenciar micrófono' }) as HTMLButtonElement).disabled).toBe(true);
    expect((screen.getByLabelText('Micrófono') as HTMLSelectElement).disabled).toBe(true);
  });
});

describe('call screen', () => {
  const dial = () => document.querySelector('.dial') as HTMLElement;

  it.each([
    ['listening', 'Te escucha'],
    ['thinking', 'Pensando…'],
    ['speaking', 'Hablando'],
  ])('shows the agent state %s as "%s"', (agentState, label) => {
    state.agentState = agentState;
    panel();
    expect(screen.getByText(label)).toBeTruthy();
    expect(dial().dataset.state).toBe(agentState);
  });

  it('shows the dialing state while connecting and idle before the call', () => {
    const view = render(<ConversationPanel conversationId="c" personaId="claro-ventas" startedAt={1} connected={false} connecting />);
    expect(screen.getByText('Marcando…')).toBeTruthy();
    view.unmount();
    render(<ConversationPanel conversationId="c" personaId="claro-ventas" startedAt={1} connected={false} />);
    expect(screen.getByText('Listo para llamar')).toBeTruthy();
  });

  it('renders the persona name and tagline and the call controls passed as children', () => {
    render(
      <ConversationPanel
        conversationId="c"
        personaId="falabella-cobranza"
        startedAt={1}
        connected
        persona={PERSONAS[1]}
      >
        <button type="button">Finalizar conversación</button>
      </ConversationPanel>,
    );
    expect(screen.getByRole('heading', { name: 'Cobranza retail' })).toBeTruthy();
    expect(screen.getByText(PERSONAS[1].tagline)).toBeTruthy();
    expect(screen.getByRole('button', { name: 'Finalizar conversación' })).toBeTruthy();
    expect(screen.getByLabelText('Duración de la llamada').textContent).toBe('00:00');
  });

  it('counts the transcript messages in the header', () => {
    state.messages = [
      { id: 'a', type: 'userTranscript', message: 'uno', timestamp: 1, attributes: { 'lk.segment_id': 'X' } },
      { id: 'b', type: 'agentTranscript', message: 'dos', timestamp: 2, attributes: { 'lk.segment_id': 'Y' } },
    ];
    panel();
    expect(screen.getByText('2 mensajes')).toBeTruthy();
  });
});

describe('persona picker', () => {
  it('renders one button per persona and reports the chosen id', () => {
    const onSelect = vi.fn();
    render(<PersonaPicker onSelect={onSelect} />);
    expect(screen.getAllByRole('button')).toHaveLength(PERSONAS.length);
    expect(screen.getByText('Ventas')).toBeTruthy();
    expect(screen.getAllByText('Cobranza', { selector: '.line-tag' })).toHaveLength(2);
    fireEvent.click(screen.getByRole('button', { name: /Cobranza financiera/ }));
    expect(onSelect).toHaveBeenCalledWith('ripley-cobranza');
  });

  it('declares the verified scope of every agent: only the dental clinic has a real documented test', () => {
    render(<PersonaPicker onSelect={vi.fn()} />);
    expect(PERSONAS.filter((persona) => persona.scope === 'tested').map((persona) => persona.id)).toEqual(['clinica-dental']);
    expect(screen.getAllByText('Prueba conversacional real documentada')).toHaveLength(1);
    expect(screen.getAllByText('Guion configurado, sin prueba real documentada')).toHaveLength(PERSONAS.length - 1);
  });

  it('uses no real brands or people in the visible labels', () => {
    const visible = PERSONAS.map((persona) => `${persona.label} ${persona.tagline}`).join(' ').toLowerCase();
    for (const term of ['claro', 'falabella', 'ripley', 'hites', 'juan d']) {
      expect(visible).not.toContain(term);
    }
  });
});
