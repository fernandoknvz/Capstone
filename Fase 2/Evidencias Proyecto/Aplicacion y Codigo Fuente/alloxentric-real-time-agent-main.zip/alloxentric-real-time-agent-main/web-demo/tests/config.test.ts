// @vitest-environment node

import { describe, expect, it } from 'vitest';
import { ConfigurationError, loadDemoConfig } from '@/lib/server/config';
import { TEST_ENV } from './fixtures';

function expectConfigurationError(env: NodeJS.ProcessEnv) {
  expect(() => loadDemoConfig(env)).toThrow(new ConfigurationError());
}

describe('demo secret validation', () => {
  it.each(['DEMO_ACCESS_SECRET', 'DEMO_SESSION_SIGNING_SECRET'])(
    'rejects an absent %s without identifying the variable',
    (name) => {
      const env = { ...TEST_ENV };
      delete env[name];
      expectConfigurationError(env);
    },
  );

  it.each(['DEMO_ACCESS_SECRET', 'DEMO_SESSION_SIGNING_SECRET'])(
    'rejects an empty %s',
    (name) => expectConfigurationError({ ...TEST_ENV, [name]: '   ' }),
  );

  it('rejects short and trivial access codes', () => {
    expectConfigurationError({ ...TEST_ENV, DEMO_ACCESS_SECRET: 'too-short' });
    expectConfigurationError({ ...TEST_ENV, DEMO_ACCESS_SECRET: 'aaaaaaaaaaaaaaaa' });
    expectConfigurationError({ ...TEST_ENV, DEMO_ACCESS_SECRET: 'password-password' });
  });

  it('rejects malformed, short, and trivial signing keys', () => {
    expectConfigurationError({ ...TEST_ENV, DEMO_SESSION_SIGNING_SECRET: 'not+base64url/value' });
    expectConfigurationError({ ...TEST_ENV, DEMO_SESSION_SIGNING_SECRET: 'c2hvcnQ' });
    expectConfigurationError({
      ...TEST_ENV,
      DEMO_SESSION_SIGNING_SECRET: 'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
    });
  });

  it('accepts a valid access code and a canonical 32-byte Base64URL signing key', () => {
    const config = loadDemoConfig(TEST_ENV);
    expect(config.accessSecret).toBe(TEST_ENV.DEMO_ACCESS_SECRET);
    expect(config.signingSecret).toBe(TEST_ENV.DEMO_SESSION_SIGNING_SECRET);
  });

  it('never includes rejected secret values in its error', () => {
    const rejected = 'secret-that-must-not-appear';
    expect(() => loadDemoConfig({ ...TEST_ENV, DEMO_SESSION_SIGNING_SECRET: rejected }))
      .toThrowError('Server configuration is incomplete');
    try {
      loadDemoConfig({ ...TEST_ENV, DEMO_SESSION_SIGNING_SECRET: rejected });
    } catch (error) {
      expect(String(error)).not.toContain(rejected);
    }
  });
});
