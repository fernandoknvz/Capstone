// @vitest-environment node

import { decodeJwt } from 'jose';
import { describe, expect, it } from 'vitest';
import { livekitToken } from '@/netlify/functions/livekit-token.mts';
import { createSessionToken } from '@/lib/server/session';
import { isPersonaId, PERSONAS } from '@/lib/personas';
import { cookieHeader, request, TEST_ENV } from './fixtures';

async function post(body?: unknown, raw?: string) {
  const session = await createSessionToken(TEST_ENV.DEMO_SESSION_SIGNING_SECRET!, 300);
  return livekitToken(
    request('/api/livekit-token', {
      method: 'POST',
      headers: { Cookie: cookieHeader(session), 'Content-Type': 'application/json' },
      body: raw ?? (body === undefined ? undefined : JSON.stringify(body)),
    }),
    TEST_ENV,
  );
}

type Dispatch = { agentName?: string; metadata?: string };

async function dispatches(response: Response): Promise<Dispatch[]> {
  const payload = decodeJwt((await response.json()).participant_token) as {
    roomConfig?: { agents?: Dispatch[] };
  };
  return payload.roomConfig?.agents ?? [];
}

describe('persona dispatch', () => {
  it('offers seven personas with unique ids', () => {
    expect(PERSONAS).toHaveLength(7);
    expect(new Set(PERSONAS.map((persona) => persona.id)).size).toBe(7);
  });

  it('validates persona ids against the closed list', () => {
    expect(isPersonaId('claro-ventas')).toBe(true);
    for (const bad of ['', 'nope', 3, null, undefined, ['claro-ventas'], '__proto__']) {
      expect(isPersonaId(bad)).toBe(false);
    }
  });

  it.each(PERSONAS.map((persona) => persona.id))('dispatches %s through server-side metadata', async (id) => {
    const response = await post({ persona: id });
    expect(response.status).toBe(201);
    const [dispatch] = await dispatches(response);
    expect(dispatch.agentName).toBe(TEST_ENV.LIVEKIT_AGENT_NAME);
    expect(JSON.parse(dispatch.metadata!)).toEqual({ persona: id });
  });

  it('sends no persona metadata when none is requested', async () => {
    const [dispatch] = await dispatches(await post({}));
    expect(dispatch.metadata ?? '').toBe('');
  });

  it.each([{ persona: 'attacker' }, { persona: 7 }, { persona: { id: 'claro-ventas' } }, { persona: '' }])(
    'rejects an invalid persona %j',
    async (body) => {
      const response = await post(body);
      expect(response.status).toBe(400);
      expect(await response.json()).toEqual({ error: 'invalid_persona' });
    },
  );

  it('rejects oversized bodies', async () => {
    const response = await post(undefined, JSON.stringify({ persona: 'claro-ventas', pad: 'x'.repeat(5000) }));
    expect(response.status).toBe(400);
  });

  it('ignores a body that is not JSON and keeps the forced agent', async () => {
    const response = await post(undefined, 'not-json');
    expect(response.status).toBe(201);
    const [dispatch] = await dispatches(response);
    expect(dispatch.agentName).toBe(TEST_ENV.LIVEKIT_AGENT_NAME);
  });

  it('still ignores a client-supplied agent name alongside a valid persona', async () => {
    const response = await post({ persona: 'clinica-dental', agent_name: 'attacker-agent', room_config: { agents: [{ agent_name: 'attacker-agent' }] } });
    const agents = await dispatches(response);
    expect(agents).toHaveLength(1);
    expect(agents[0].agentName).toBe(TEST_ENV.LIVEKIT_AGENT_NAME);
  });
});
