// @vitest-environment node

import { describe, expect, it } from 'vitest';
import { originAllowed } from '@/lib/server/http';

const req = (origin?: string) => new Request('https://x.test/api', { headers: origin ? { Origin: origin } : {} });

describe('originAllowed', () => {
  it('accepts the exact configured origin', () => {
    expect(originAllowed(req('https://demo.example.test'), 'https://demo.example.test')).toBe(true);
  });

  it('accepts any origin of a comma-separated list, ignoring spaces', () => {
    const list = 'https://alloxentric.jdz.cl, https://alloxentric-voz-demo.vercel.app';
    expect(originAllowed(req('https://alloxentric.jdz.cl'), list)).toBe(true);
    expect(originAllowed(req('https://alloxentric-voz-demo.vercel.app'), list)).toBe(true);
  });

  it('rejects other origins, near-misses and requests without Origin', () => {
    const list = 'https://alloxentric.jdz.cl,https://alloxentric-voz-demo.vercel.app';
    for (const bad of ['https://evil.example', 'https://alloxentric.jdz.cl.evil.example', 'http://alloxentric.jdz.cl', 'https://sub.alloxentric.jdz.cl', 'null']) {
      expect(originAllowed(req(bad), list)).toBe(false);
    }
    expect(originAllowed(req(), list)).toBe(false);
  });

  it('does not treat an empty entry as a wildcard', () => {
    expect(originAllowed(req('https://evil.example'), 'https://a.test,,')).toBe(false);
    expect(originAllowed(req(''), 'https://a.test,,')).toBe(false);
  });
});
