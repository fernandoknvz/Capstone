import { sessionStatus } from '../../netlify/functions/session.mts';

export async function GET(request: Request) {
  return sessionStatus(request, process.env);
}
