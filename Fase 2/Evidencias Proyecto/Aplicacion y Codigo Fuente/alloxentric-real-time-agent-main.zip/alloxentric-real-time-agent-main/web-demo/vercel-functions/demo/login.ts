import { login } from '../../netlify/functions/login.mts';

export async function POST(request: Request) {
  return login(request, process.env);
}
