import { logout } from '../../netlify/functions/logout.mts';

export async function POST() {
  return logout();
}
