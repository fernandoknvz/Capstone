// Fuente de la Vercel Function /api/livekit-token. Se empaqueta con esbuild
// (scripts/build-vercel-functions.mts) en api/livekit-token.js; no se edita api/ a mano.
// La lógica se reutiliza de la Netlify Function de igual nombre.
import { livekitToken } from '../netlify/functions/livekit-token.mts';

export async function POST(request: Request) {
  return livekitToken(request, process.env);
}
