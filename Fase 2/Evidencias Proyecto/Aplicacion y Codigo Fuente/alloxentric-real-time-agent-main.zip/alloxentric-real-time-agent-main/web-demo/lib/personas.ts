// Habilidades (personas) disponibles en la demo. Los identificadores DEBEN
// coincidir, en el mismo orden, con src/alloxentric_real_time_agent/personas.py
// (hay una prueba en pytest que lo verifica). El navegador solo envía el
// identificador; las instrucciones del agente viven en el servidor del agente.
export type PersonaIcon = 'headset' | 'coin' | 'tooth' | 'wifi' | 'briefcase' | 'ledger' | 'card';
// Alcance verificable de cada agente (ver docs/VOXENTRA_DEMO.md): solo la clínica
// dental tiene una prueba conversacional real documentada.
export type PersonaScope = 'tested' | 'scripted';
export type PersonaTone = 'amber' | 'rose' | 'mint' | 'sky' | 'violet' | 'lime';

export type PersonaOption = {
  id: string;
  label: string;
  tagline: string;
  tag: string;
  icon: PersonaIcon;
  tone: PersonaTone;
  scope: PersonaScope;
};

export const SCOPE_LABEL: Record<PersonaScope, string> = {
  tested: 'Prueba conversacional real documentada',
  scripted: 'Guion configurado, sin prueba real documentada',
};

export const PERSONAS: readonly PersonaOption[] = [
  { id: 'claro-ventas', label: 'Ventas de telefonía', tagline: 'Ejecutiva que intenta venderte un plan móvil', tag: 'Ventas', icon: 'headset', tone: 'amber', scope: 'scripted' },
  { id: 'falabella-cobranza', label: 'Cobranza retail', tagline: 'Deuda de $4.200.000 de una tarjeta de tienda', tag: 'Cobranza', icon: 'coin', tone: 'rose', scope: 'scripted' },
  { id: 'clinica-dental', label: 'Clínica dental', tagline: 'Asistente de agendamiento y consultas', tag: 'Salud', icon: 'tooth', tone: 'mint', scope: 'tested' },
  { id: 'ripley-cobranza', label: 'Cobranza financiera', tagline: 'Deuda de $1.300.000 de una juguera con CAE +300%', tag: 'Cobranza', icon: 'ledger', tone: 'violet', scope: 'scripted' },
  { id: 'soporte-internet', label: 'Soporte de internet', tagline: 'Técnico que diagnostica fallas de fibra óptica', tag: 'Soporte', icon: 'wifi', tone: 'sky', scope: 'scripted' },
  { id: 'entrevista-rrhh', label: 'Entrevista laboral', tagline: 'Reclutadora que te entrevista para un cargo comercial', tag: 'RR. HH.', icon: 'briefcase', tone: 'lime', scope: 'scripted' },
  { id: 'hites-servicio', label: 'Atención postventa', tagline: 'Ejecutivo que te ayuda con una compra que no reconoces', tag: 'Servicio', icon: 'card', tone: 'rose', scope: 'scripted' },
];

export type PersonaId = (typeof PERSONAS)[number]['id'];

export function isPersonaId(value: unknown): value is PersonaId {
  return typeof value === 'string' && PERSONAS.some((persona) => persona.id === value);
}

export function personaLabel(id: string): string {
  return PERSONAS.find((persona) => persona.id === id)?.label ?? 'Agente de prueba';
}

export function personaOption(id: string): PersonaOption | undefined {
  return PERSONAS.find((persona) => persona.id === id);
}
