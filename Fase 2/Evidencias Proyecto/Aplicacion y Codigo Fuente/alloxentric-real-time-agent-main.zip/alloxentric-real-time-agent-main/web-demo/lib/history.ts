// Historial de conversaciones guardado SOLO en este navegador (localStorage).
// No se envía a ningún servidor. Todas las lecturas/escrituras son defensivas:
// localStorage puede no existir, estar bloqueado o contener datos corruptos.

export type HistoryMessage = {
  id: string;
  role: 'user' | 'agent';
  text: string;
  timestamp: number;
};

export type HistoryEntry = {
  id: string;
  personaId: string;
  startedAt: number;
  messages: HistoryMessage[];
};

export const HISTORY_KEY = 'alloxentric-demo-history-v1';
export const MAX_ENTRIES = 30;
export const MAX_MESSAGES = 400;
export const MAX_TEXT = 2000;

function storage(): Storage | null {
  try {
    return typeof window === 'undefined' ? null : window.localStorage;
  } catch {
    return null;
  }
}

function isMessage(value: unknown): value is HistoryMessage {
  if (typeof value !== 'object' || value === null) return false;
  const m = value as Record<string, unknown>;
  return typeof m.id === 'string'
    && (m.role === 'user' || m.role === 'agent')
    && typeof m.text === 'string'
    && typeof m.timestamp === 'number';
}

function isEntry(value: unknown): value is HistoryEntry {
  if (typeof value !== 'object' || value === null) return false;
  const e = value as Record<string, unknown>;
  return typeof e.id === 'string'
    && typeof e.personaId === 'string'
    && typeof e.startedAt === 'number'
    && Array.isArray(e.messages)
    && e.messages.every(isMessage);
}

export function loadHistory(): HistoryEntry[] {
  const store = storage();
  if (!store) return [];
  try {
    const parsed: unknown = JSON.parse(store.getItem(HISTORY_KEY) ?? '[]');
    return Array.isArray(parsed) ? parsed.filter(isEntry) : [];
  } catch {
    return [];
  }
}

function persist(entries: HistoryEntry[]): boolean {
  const store = storage();
  if (!store) return false;
  try {
    store.setItem(HISTORY_KEY, JSON.stringify(entries.slice(0, MAX_ENTRIES)));
    return true;
  } catch {
    return false;
  }
}

/** Crea o actualiza una conversación (la más reciente primero). */
export function saveConversation(entry: HistoryEntry): boolean {
  if (entry.messages.length === 0) return false;
  const clean: HistoryEntry = {
    ...entry,
    messages: entry.messages
      .slice(-MAX_MESSAGES)
      .map((message) => ({ ...message, text: message.text.slice(0, MAX_TEXT) })),
  };
  const others = loadHistory().filter((existing) => existing.id !== entry.id);
  return persist([clean, ...others]);
}

export function deleteConversation(id: string): void {
  persist(loadHistory().filter((entry) => entry.id !== id));
}

export function clearHistory(): void {
  const store = storage();
  try {
    store?.removeItem(HISTORY_KEY);
  } catch {
    // Sin almacenamiento: no hay nada que borrar.
  }
}

export function conversationToText(entry: HistoryEntry, personaName: string): string {
  const header = `${personaName} — ${new Date(entry.startedAt).toLocaleString('es-CL')}`;
  const lines = entry.messages.map((message) => {
    const time = new Date(message.timestamp).toLocaleTimeString('es-CL');
    return `[${time}] ${message.role === 'user' ? 'Tú' : 'Agente'}: ${message.text}`;
  });
  return `${header}\n\n${lines.join('\n')}\n`;
}
