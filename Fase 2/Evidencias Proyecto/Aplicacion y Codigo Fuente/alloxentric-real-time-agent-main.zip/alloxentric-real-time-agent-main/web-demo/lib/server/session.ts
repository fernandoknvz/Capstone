import { createHash, randomUUID, timingSafeEqual } from 'node:crypto';
import { jwtVerify, SignJWT } from 'jose';

export const SESSION_COOKIE = '__Host-alloxentric-demo';

function key(secret: string): Uint8Array {
  return new TextEncoder().encode(secret);
}

export function accessCodeMatches(actual: string, expected: string): boolean {
  const actualHash = createHash('sha256').update(actual).digest();
  const expectedHash = createHash('sha256').update(expected).digest();
  return timingSafeEqual(actualHash, expectedHash);
}

export async function createSessionToken(secret: string, ttlSeconds: number, now = new Date()) {
  return new SignJWT({ scope: 'voice-demo' })
    .setProtectedHeader({ alg: 'HS256' })
    .setSubject(randomUUID())
    .setIssuedAt(Math.floor(now.getTime() / 1000))
    .setExpirationTime(Math.floor(now.getTime() / 1000) + ttlSeconds)
    .sign(key(secret));
}

export async function verifySessionToken(token: string | undefined, secret: string) {
  if (!token) return false;
  try {
    const { payload } = await jwtVerify(token, key(secret), { algorithms: ['HS256'] });
    return payload.scope === 'voice-demo';
  } catch {
    return false;
  }
}

export function readCookie(request: Request, name = SESSION_COOKIE): string | undefined {
  const cookie = request.headers.get('cookie');
  if (!cookie) return undefined;
  for (const item of cookie.split(';')) {
    const [keyName, ...value] = item.trim().split('=');
    if (keyName === name) {
      try {
        return decodeURIComponent(value.join('='));
      } catch {
        return undefined;
      }
    }
  }
  return undefined;
}

export function sessionCookie(token: string, maxAge: number) {
  return `${SESSION_COOKIE}=${encodeURIComponent(token)}; Path=/; Max-Age=${maxAge}; HttpOnly; Secure; SameSite=Strict`;
}

export function expiredSessionCookie() {
  return `${SESSION_COOKIE}=; Path=/; Max-Age=0; HttpOnly; Secure; SameSite=Strict`;
}
