import { randomUUID } from 'node:crypto';
import {
  AccessToken,
  RoomAgentDispatch,
  RoomConfiguration,
  TrackSource,
  type VideoGrant,
} from 'livekit-server-sdk';
import { loadLiveKitConfig } from './config';
import type { PersonaId } from '../personas';

export async function createVoiceConnection(env: NodeJS.ProcessEnv = process.env, persona?: PersonaId) {
  const config = loadLiveKitConfig(env);
  const roomName = `demo-${randomUUID()}`;
  const identity = `evaluator-${randomUUID()}`;
  const token = new AccessToken(config.apiKey, config.apiSecret, {
    identity,
    name: 'Evaluador',
    ttl: config.tokenTtlSeconds,
  });
  const grant: VideoGrant = {
    room: roomName,
    roomJoin: true,
    canPublish: true,
    canPublishSources: [TrackSource.MICROPHONE],
    canPublishData: false,
    canSubscribe: true,
    canUpdateOwnMetadata: false,
  };
  token.addGrant(grant);
  token.roomConfig = new RoomConfiguration({
    name: roomName,
    agents: [new RoomAgentDispatch({
      agentName: config.agentName,
      // Solo un identificador de una lista cerrada, validado antes de llegar aquí.
      ...(persona ? { metadata: JSON.stringify({ persona }) } : {}),
    })],
  });
  return {
    server_url: config.url,
    participant_token: await token.toJwt(),
    roomName,
    identity,
  };
}
