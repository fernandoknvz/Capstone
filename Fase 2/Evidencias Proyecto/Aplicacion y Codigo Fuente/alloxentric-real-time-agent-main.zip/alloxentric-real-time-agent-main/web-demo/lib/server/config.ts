export class ConfigurationError extends Error {
  constructor() { super('Server configuration is incomplete'); }
}

const ACCESS_SECRET_MIN_LENGTH = 16;
const ACCESS_SECRET_MAX_LENGTH = 128;
const TRIVIAL_ACCESS_SECRETS = new Set([
  '1234567890123456', 'alloxentric', 'changeme', 'demo', 'password', 'test',
]);

function required(env: NodeJS.ProcessEnv, name: string): string {
  const value = env[name]?.trim();
  if (!value) throw new ConfigurationError();
  return value;
}

function positiveInteger(env: NodeJS.ProcessEnv, name: string, fallback: number): number {
  const raw = env[name];
  if (!raw) return fallback;
  const value = Number(raw);
  if (!Number.isSafeInteger(value) || value <= 0) throw new ConfigurationError();
  return value;
}

function validAccessSecret(value: string): boolean {
  if (value.length < ACCESS_SECRET_MIN_LENGTH || value.length > ACCESS_SECRET_MAX_LENGTH) return false;
  if (!/^[\x20-\x7E]+$/.test(value)) return false;
  const normalized = value.toLowerCase().replace(/[\s_-]/g, '');
  if (TRIVIAL_ACCESS_SECRETS.has(normalized)) return false;
  if (/^(admin|alloxentric|changeme|demo|letmein|password|qwerty|secret|test|welcome)+\d*$/.test(normalized)) return false;
  return !/^(.)\1+$/.test(value);
}

function validSigningSecret(value: string): boolean {
  if (!/^[A-Za-z0-9_-]+$/.test(value)) return false;
  const decoded = Buffer.from(value, 'base64url');
  if (decoded.length < 32 || decoded.toString('base64url') !== value) return false;
  return new Set(decoded).size >= 8;
}

function accessSecret(env: NodeJS.ProcessEnv): string {
  const value = required(env, 'DEMO_ACCESS_SECRET');
  if (!validAccessSecret(value)) throw new ConfigurationError();
  return value;
}

function signingSecret(env: NodeJS.ProcessEnv): string {
  const value = required(env, 'DEMO_SESSION_SIGNING_SECRET');
  if (!validSigningSecret(value)) throw new ConfigurationError();
  return value;
}

export function loadDemoConfig(env: NodeJS.ProcessEnv = process.env) {
  return {
    enabled: env.DEMO_ENABLED === 'true',
    accessSecret: accessSecret(env),
    signingSecret: signingSecret(env),
    allowedOrigin: required(env, 'DEMO_ALLOWED_ORIGIN'),
    sessionTtlSeconds: positiveInteger(env, 'DEMO_SESSION_TTL_SECONDS', 1800),
  };
}

export function loadLiveKitConfig(env: NodeJS.ProcessEnv = process.env) {
  return {
    url: required(env, 'LIVEKIT_URL'),
    apiKey: required(env, 'LIVEKIT_API_KEY'),
    apiSecret: required(env, 'LIVEKIT_API_SECRET'),
    agentName: required(env, 'LIVEKIT_AGENT_NAME'),
    tokenTtlSeconds: positiveInteger(env, 'DEMO_LIVEKIT_TOKEN_TTL_SECONDS', 300),
  };
}
