export const NO_STORE_HEADERS = {
  'Cache-Control': 'no-store, max-age=0',
  'Content-Type': 'application/json; charset=utf-8',
};

export function json(status: number, body: object, headers: HeadersInit = {}) {
  return new Response(status === 204 ? null : JSON.stringify(body), {
    status,
    headers: { ...NO_STORE_HEADERS, ...headers },
  });
}

// `allowedOrigins` admite uno o varios orígenes separados por coma (p. ej. el dominio
// propio y el *.vercel.app). La comparación es exacta; sin cabecera Origin se rechaza.
export function originAllowed(request: Request, allowedOrigins: string) {
  const origin = request.headers.get('origin');
  if (!origin) return false;
  return allowedOrigins.split(',').some((allowed) => allowed.trim() === origin);
}

export function safeServerError() {
  return json(500, { error: 'service_unavailable' });
}
