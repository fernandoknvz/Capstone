import type { Metadata } from 'next';
import '@fontsource/nunito/latin-300.css';
import '@fontsource/nunito/latin-400.css';
import '@fontsource/nunito/latin-600.css';
import '@fontsource/nunito/latin-700.css';
import './globals.css';

export const metadata: Metadata = {
  title: 'VOXENTRA — Agentes de voz inteligentes para tu negocio',
  description: 'Demostración académica con datos ficticios de agentes de voz para pequeñas y medianas empresas. Nombre provisional.',
  robots: { index: false, follow: false },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="es">
      <body>{children}</body>
    </html>
  );
}
