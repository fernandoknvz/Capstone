// Paso posterior al build para Vercel.
//
// En Netlify la CSP se entrega como encabezado (out/_headers) con el hash de cada
// script en línea. Vercel no lee `_headers` y `vercel.json` no puede conocer hashes
// que cambian en cada build, así que aquí se inserta la MISMA política como
// <meta http-equiv="Content-Security-Policy"> al inicio de cada HTML exportado.
// `frame-ancestors` no se admite en <meta>; ese riesgo lo cubre X-Frame-Options: DENY
// (ver vercel.json).
import { readFile, writeFile } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { findHtmlFiles, inlineScriptHashes } from './generate-csp-headers.mts';

export function cspPolicy(hashes: string[]): string {
  return [
    "default-src 'self'",
    "connect-src 'self' https://*.livekit.cloud wss://*.livekit.cloud",
    "media-src 'self' blob:",
    `script-src ${["'self'", ...hashes].join(' ')}`,
    "style-src 'self'",
    "img-src 'self' data:",
    "base-uri 'self'",
    "form-action 'self'",
  ].join('; ');
}

export function injectCsp(html: string): string {
  if (/http-equiv=["']?content-security-policy/i.test(html)) {
    throw new Error('The page already declares a CSP meta tag.');
  }
  const head = /<head(\s[^>]*)?>/i.exec(html);
  if (!head) throw new Error('The page has no <head>.');
  const meta = `<meta http-equiv="Content-Security-Policy" content="${cspPolicy(inlineScriptHashes(html))}"/>`;
  const at = head.index + head[0].length;
  return `${html.slice(0, at)}${meta}${html.slice(at)}`;
}

export async function addCspMeta(outDirectory: string): Promise<string[]> {
  const files = await findHtmlFiles(outDirectory);
  for (const file of files) {
    const html = await readFile(file, 'utf8');
    // Una página sin scripts en línea solo lleva 'self' en script-src.
    await writeFile(file, injectCsp(html), 'utf8');
  }
  return files;
}

const currentFile = fileURLToPath(import.meta.url);
if (process.argv[1] && resolve(process.argv[1]) === currentFile) {
  const out = join(resolve(dirname(currentFile), '..'), 'out');
  addCspMeta(out)
    .then((files) => console.log(`CSP meta tag added to ${files.length} HTML file(s).`))
    .catch((error: unknown) => {
      console.error(error instanceof Error ? error.message : String(error));
      process.exitCode = 1;
    });
}
