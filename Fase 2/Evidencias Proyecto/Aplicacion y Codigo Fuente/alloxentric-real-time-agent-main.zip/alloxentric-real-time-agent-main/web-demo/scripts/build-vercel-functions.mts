// Empaqueta las Vercel Functions (vercel-functions/**) en api/**.js, cada una en un
// solo archivo ESM autocontenido. Se hace así porque el empaquetador de Vercel no
// incluye los .mts que reutilizamos de Netlify (ERR_MODULE_NOT_FOUND en producción).
// api/ es salida generada y está en .gitignore.
import { rm } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { build } from 'esbuild';

export const FUNCTIONS = {
  'api/livekit-token': 'vercel-functions/livekit-token.ts',
  'api/demo/login': 'vercel-functions/demo/login.ts',
  'api/demo/session': 'vercel-functions/demo/session.ts',
  'api/demo/logout': 'vercel-functions/demo/logout.ts',
} as const;

export async function buildVercelFunctions(root: string) {
  await rm(join(root, 'api'), { recursive: true, force: true });
  await build({
    absWorkingDir: root,
    entryPoints: FUNCTIONS,
    outdir: '.',
    bundle: true,
    platform: 'node',
    format: 'esm',
    target: 'node24',
    outExtension: { '.js': '.js' },
    tsconfig: 'tsconfig.json',
    legalComments: 'none',
    // Algunas dependencias CJS usan require(): se habilita dentro del bundle ESM.
    banner: { js: "import { createRequire as __cr } from 'node:module'; const require = __cr(import.meta.url);" },
    logLevel: 'info',
  });
  return Object.keys(FUNCTIONS);
}

const currentFile = fileURLToPath(import.meta.url);
if (process.argv[1] && resolve(process.argv[1]) === currentFile) {
  buildVercelFunctions(resolve(dirname(currentFile), '..'))
    .then((outputs) => console.log(`Built ${outputs.length} Vercel function(s): ${outputs.join(', ')}`))
    .catch((error: unknown) => {
      console.error(error instanceof Error ? error.message : String(error));
      process.exitCode = 1;
    });
}
