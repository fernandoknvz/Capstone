'use client';

import { useEffect, useRef, useState, type ReactNode } from 'react';
import { useAgent, useMediaDeviceSelect, useSessionMessages, useTrackToggle } from '@livekit/components-react';
import { Track } from 'livekit-client';
import { MicIcon, PersonaGlyph } from '@/components/icons';
import { saveConversation, type HistoryMessage } from '@/lib/history';
import { SCOPE_LABEL, type PersonaOption } from '@/lib/personas';

type Props = {
  conversationId: string;
  personaId: string;
  startedAt: number;
  connected: boolean;
  connecting?: boolean;
  persona?: PersonaOption;
  // Botones de iniciar / finalizar, que controla la sesión.
  children?: ReactNode;
};

type DialState = 'idle' | 'connecting' | 'listening' | 'thinking' | 'speaking';

const STATE_LABEL: Record<DialState, string> = {
  idle: 'Listo para llamar',
  connecting: 'Marcando…',
  listening: 'Te escucha',
  thinking: 'Pensando…',
  speaking: 'Hablando',
};

function dialStateFor(connected: boolean, connecting: boolean, agentState: string): DialState {
  if (!connected) return connecting ? 'connecting' : 'idle';
  if (agentState === 'speaking' || agentState === 'thinking' || agentState === 'listening') return agentState;
  return 'connecting';
}

function clock(totalSeconds: number): string {
  const minutes = Math.floor(totalSeconds / 60);
  return `${String(minutes).padStart(2, '0')}:${String(totalSeconds % 60).padStart(2, '0')}`;
}

// Pantalla de llamada: dial del agente, controles, transcripción en vivo e
// historial de UNA conversación. Debe renderizarse dentro de <SessionProvider>.
export function ConversationPanel({
  conversationId,
  personaId,
  startedAt,
  connected,
  connecting = false,
  persona,
  children,
}: Props) {
  const { messages } = useSessionMessages();
  const agent = useAgent();
  const mic = useMediaDeviceSelect({ kind: 'audioinput' });
  const toggle = useTrackToggle({ source: Track.Source.Microphone });
  // Se acumula localmente para que la transcripción siga visible al terminar.
  const [lines, setLines] = useState<HistoryMessage[]>([]);
  const [seconds, setSeconds] = useState(0);
  const endRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    // LiveKit publica la transcripción del usuario como VARIOS mensajes del mismo
    // segmento (parcial y final, con ids distintos pero el mismo `lk.segment_id`).
    // Se agrupa por segmento y gana el más reciente.
    const bySegment = new Map<string, HistoryMessage & { stamp: number }>();
    for (const message of messages) {
      if (message.type !== 'userTranscript' && message.type !== 'agentTranscript') continue;
      const text = message.message.trim();
      if (!text) continue;
      const attributes = (message as { attributes?: Record<string, string> }).attributes;
      const key = attributes?.['lk.segment_id'] ?? message.id;
      const current = bySegment.get(key);
      if (current && current.stamp > message.timestamp) continue;
      bySegment.set(key, {
        id: key,
        role: message.type === 'userTranscript' ? 'user' : 'agent',
        text,
        // El orden lo da el primer mensaje del segmento.
        timestamp: current ? current.timestamp : message.timestamp,
        stamp: message.timestamp,
      });
    }
    if (bySegment.size === 0) return;
    setLines((previous) => {
      const byId = new Map(previous.map((line) => [line.id, line]));
      for (const { stamp, ...line } of bySegment.values()) {
        void stamp;
        const before = byId.get(line.id);
        byId.set(line.id, before ? { ...line, timestamp: before.timestamp } : line);
      }
      return [...byId.values()].sort((a, b) => a.timestamp - b.timestamp);
    });
  }, [messages]);

  useEffect(() => {
    saveConversation({ id: conversationId, personaId, startedAt, messages: lines });
  }, [lines, conversationId, personaId, startedAt]);

  useEffect(() => {
    endRef.current?.scrollIntoView?.({ block: 'end' });
  }, [lines]);

  // Cronómetro de la llamada: corre solo mientras hay conexión.
  useEffect(() => {
    if (!connected) return;
    const begin = Date.now();
    setSeconds(0);
    const timer = window.setInterval(() => setSeconds(Math.floor((Date.now() - begin) / 1000)), 1000);
    return () => window.clearInterval(timer);
  }, [connected]);

  const muted = !toggle.enabled;
  const state = dialStateFor(connected, connecting, agent.state);

  return (
    <div className="call-body">
      <aside className="agent-card">
        <div className="dial" data-state={state} data-muted={connected && muted}>
          <span className="dial-ring dial-ring-a" aria-hidden="true" />
          <span className="dial-ring dial-ring-b" aria-hidden="true" />
          <span className="dial-ring dial-ring-c" aria-hidden="true" />
          <span className="dial-sweep" aria-hidden="true" />
          <span className="dial-core">
            {persona ? <PersonaGlyph icon={persona.icon} className="dial-glyph" /> : <MicIcon className="dial-glyph" />}
          </span>
        </div>
        <h2 className="agent-name">{persona?.label ?? 'Agente'}</h2>
        {persona && <p className="agent-tagline">{persona.tagline}</p>}
        {persona && <span className="line-scope" data-scope={persona.scope}>{SCOPE_LABEL[persona.scope]}</span>}
        <div className="call-meta">
          <span className="timer" aria-label="Duración de la llamada">{clock(seconds)}</span>
          <span className="state-chip" data-state={state} role="status">{STATE_LABEL[state]}</span>
        </div>

        <div className="call-actions">
          <button
            type="button"
            className={`button ${muted ? 'button-muted' : ''}`}
            aria-pressed={muted}
            disabled={!connected || toggle.pending}
            onClick={() => { void toggle.toggle(); }}
          >
            <MicIcon className="icon" off={muted} />
            {muted ? 'Activar micrófono' : 'Silenciar micrófono'}
          </button>
          {children}
        </div>
        {connected && muted && <p className="muted-note" role="status">Estás silenciado: el agente no te escucha.</p>}

        <div className="field">
          <label htmlFor="mic-select">Micrófono</label>
          <select
            id="mic-select"
            value={mic.activeDeviceId}
            disabled={!connected || mic.devices.length === 0}
            onChange={(event) => { void mic.setActiveMediaDevice(event.target.value); }}
          >
            {mic.devices.length === 0 && <option value="">Sin micrófonos disponibles</option>}
            {mic.devices.map((device, index) => (
              <option key={device.deviceId} value={device.deviceId}>
                {device.label || `Micrófono ${index + 1}`}
              </option>
            ))}
          </select>
        </div>
      </aside>

      <section className="chat" aria-label="Transcripción">
        <header className="chat-head">
          <span className="chat-title">Transcripción en vivo</span>
          <span className="chat-count">{lines.length} {lines.length === 1 ? 'mensaje' : 'mensajes'}</span>
        </header>
        <div className="transcript" role="log" aria-live="polite" aria-label="Transcripción de la conversación">
          {lines.length === 0 && (
            <p className="transcript-empty">La transcripción aparecerá aquí cuando empieces a hablar.</p>
          )}
          {lines.map((line) => (
            <div key={line.id} className={`bubble bubble-${line.role}`}>
              <span className="bubble-who">{line.role === 'user' ? 'Tú' : 'Agente'}</span>
              <p className="bubble-text">{line.text}</p>
              <time className="bubble-time" dateTime={new Date(line.timestamp).toISOString()}>
                {new Date(line.timestamp).toLocaleTimeString('es-CL', { hour: '2-digit', minute: '2-digit' })}
              </time>
            </div>
          ))}
          <div ref={endRef} />
        </div>
      </section>
    </div>
  );
}
