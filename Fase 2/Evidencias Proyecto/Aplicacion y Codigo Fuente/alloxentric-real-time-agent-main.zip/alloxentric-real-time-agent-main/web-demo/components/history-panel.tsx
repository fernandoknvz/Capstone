'use client';

import { useEffect, useState } from 'react';
import {
  clearHistory,
  conversationToText,
  deleteConversation,
  loadHistory,
  type HistoryEntry,
} from '@/lib/history';
import { personaLabel } from '@/lib/personas';

function span(entry: HistoryEntry): string {
  const stamps = entry.messages.map((message) => message.timestamp);
  const seconds = Math.max(0, Math.round((Math.max(...stamps) - entry.startedAt) / 1000));
  if (seconds < 60) return `${seconds} s`;
  return `${Math.floor(seconds / 60)} min ${String(seconds % 60).padStart(2, '0')} s`;
}

export function HistoryPanel({ refreshKey }: { refreshKey: number }) {
  const [entries, setEntries] = useState<HistoryEntry[]>([]);
  const [openId, setOpenId] = useState<string | null>(null);

  useEffect(() => {
    setEntries(loadHistory());
  }, [refreshKey]);

  function remove(id: string) {
    deleteConversation(id);
    setEntries(loadHistory());
    if (openId === id) setOpenId(null);
  }

  function clearAll() {
    clearHistory();
    setEntries([]);
    setOpenId(null);
  }

  function download(entry: HistoryEntry) {
    const text = conversationToText(entry, personaLabel(entry.personaId));
    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    const stamp = new Date(entry.startedAt).toISOString().slice(0, 16).replace(/[:T]/g, '-');
    link.download = `conversacion-${entry.personaId}-${stamp}.txt`;
    link.click();
    URL.revokeObjectURL(url);
  }

  return (
    <section aria-labelledby="history-heading" className="log">
      <div className="section-head">
        <h2 id="history-heading" className="section-title">Historial</h2>
        {entries.length > 0 && (
          <button type="button" className="button button-small" onClick={clearAll}>Borrar todo</button>
        )}
      </div>
      <p className="log-note">Se guarda solo en este navegador; no se envía a ningún servidor.</p>
      {entries.length === 0 && <p className="log-empty">Aún no hay conversaciones guardadas.</p>}
      <ul className="log-list">
        {entries.map((entry) => {
          return (
            <li key={entry.id} className="log-item">
              <button
                type="button"
                className="log-toggle"
                aria-expanded={openId === entry.id}
                onClick={() => setOpenId(openId === entry.id ? null : entry.id)}
              >
                <span className="log-name">{personaLabel(entry.personaId)}</span>
                <span className="log-meta">
                  {new Date(entry.startedAt).toLocaleString('es-CL')} · {entry.messages.length} mensajes · {span(entry)}
                </span>
              </button>
              {openId === entry.id && (
                <div className="log-body">
                  {entry.messages.map((message) => (
                    <div key={message.id} className={`bubble bubble-${message.role}`}>
                      <span className="bubble-who">{message.role === 'user' ? 'Tú' : 'Agente'}</span>
                      <p className="bubble-text">{message.text}</p>
                    </div>
                  ))}
                  <div className="button-row">
                    <button type="button" className="button button-small" onClick={() => download(entry)}>Descargar .txt</button>
                    <button type="button" className="button button-small button-danger" onClick={() => remove(entry.id)}>Eliminar</button>
                  </div>
                </div>
              )}
            </li>
          );
        })}
      </ul>
    </section>
  );
}
