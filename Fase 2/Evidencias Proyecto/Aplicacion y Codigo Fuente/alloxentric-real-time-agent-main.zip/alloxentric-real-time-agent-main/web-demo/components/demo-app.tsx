'use client';

import { FormEvent, useEffect, useState } from 'react';
import { HistoryPanel } from '@/components/history-panel';
import { PersonaPicker } from '@/components/persona-picker';
import { VoiceSession } from '@/components/voice-session';
import type { PersonaId } from '@/lib/personas';

type AccessState = 'checking' | 'locked' | 'authorized';

function BrandMark() {
  return (
    <svg className="brand-mark" viewBox="0 0 32 32" width="30" height="30" aria-hidden="true" focusable="false">
      <path d="M16 2.5 28 9.25v13.5L16 29.5 4 22.75V9.25L16 2.5Z" fill="currentColor" />
      <circle className="brand-dot" cx="16" cy="16" r="5.2" />
    </svg>
  );
}

export function DemoApp() {
  const [access, setAccess] = useState<AccessState>('checking');
  const [code, setCode] = useState('');
  const [error, setError] = useState('');
  const [pending, setPending] = useState(false);
  const [persona, setPersona] = useState<PersonaId | null>(null);
  const [historyVersion, setHistoryVersion] = useState(0);

  useEffect(() => {
    let active = true;
    fetch('/api/demo/session', { cache: 'no-store', credentials: 'same-origin' })
      .then((response) => active && setAccess(response.ok ? 'authorized' : 'locked'))
      .catch(() => active && setAccess('locked'));
    return () => { active = false; };
  }, []);

  async function login(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setPending(true);
    setError('');
    try {
      const response = await fetch('/api/demo/login', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ accessCode: code }),
      });
      if (!response.ok) {
        setError(response.status === 401 ? 'Código de acceso incorrecto.' : 'No fue posible autorizar el acceso.');
        return;
      }
      setCode('');
      setAccess('authorized');
    } catch {
      setError('No fue posible conectar con el servicio de autorización.');
    } finally {
      setPending(false);
    }
  }

  async function logout() {
    await fetch('/api/demo/logout', { method: 'POST', credentials: 'same-origin' }).catch(() => undefined);
    setAccess('locked');
  }

  return (
    <div className="shell">
      <header className="topbar">
        <div className="brand">
          <BrandMark />
          <div className="brand-text">
            <span className="brand-name">VOXENTRA</span>
            <span className="brand-sub">Agentes de voz inteligentes para tu negocio</span>
          </div>
        </div>
        <div className="topbar-right">
          <span className="pill">Simulación · datos ficticios</span>
          {access === 'authorized' && persona === null && (
            <button className="button button-small button-ghost" type="button" onClick={logout}>Cerrar acceso</button>
          )}
        </div>
      </header>

      <p className="notice" role="note">
        <strong>Demostración con datos ficticios.</strong> No realiza operaciones reales ni está integrada con sistemas empresariales.
      </p>

      <main className="main" aria-busy={access === 'checking'}>
        {access === 'checking' && <p className="checking" role="status">Verificando acceso…</p>}

        {access === 'locked' && (
          <section className="login" aria-labelledby="login-title">
            <div className="login-copy">
              <span className="eyebrow">Demostración académica</span>
              <h1 id="login-title" className="display">
                Agentes de voz inteligentes para tu negocio.
              </h1>
              <p className="lede">
                Prueba cómo un agente de voz podría atender llamadas de ventas, cobranza, agenda, soporte y
                reclutamiento. Ingresa el código temporal entregado por el equipo para abrir la demostración.
              </p>
            </div>
            <form className="login-card" onSubmit={login}>
              <label htmlFor="access-code">Código de acceso</label>
              <input
                id="access-code"
                type="password"
                autoComplete="one-time-code"
                required
                value={code}
                onChange={(event) => setCode(event.target.value)}
              />
              <button className="button button-primary" type="submit" disabled={pending}>
                {pending ? 'Verificando…' : 'Ingresar'}
              </button>
              {error && <p className="error" role="alert">{error}</p>}
            </form>
          </section>
        )}

        {access === 'authorized' && persona === null && (
          <>
            <section className="hero">
              <span className="eyebrow">Demostración académica</span>
              <h1 className="display">
                Agentes de voz inteligentes para tu negocio
              </h1>
              <p className="lede">
                Cada agente representa un tipo de negocio con una empresa ficticia. Autoriza el micrófono cuando el
                navegador lo solicite y habla con naturalidad: puedes interrumpir al agente.
              </p>
            </section>
            <PersonaPicker onSelect={setPersona} />
            <HistoryPanel refreshKey={historyVersion} />
          </>
        )}

        {access === 'authorized' && persona !== null && (
          <VoiceSession
            key={persona}
            persona={persona}
            onLogout={logout}
            onExit={() => { setPersona(null); setHistoryVersion((version) => version + 1); }}
          />
        )}
      </main>

      <footer className="privacy">
        VOXENTRA es un nombre provisional de esta demostración académica. Los escenarios, empresas y personas son
        ficticios; cualquier coincidencia con entidades reales es casual. Usa solamente información ficticia. La conversación se transcribe en pantalla y el historial se
        guarda únicamente en este navegador. No se graba audio ni se habilitan cámara o pantalla.
      </footer>
    </div>
  );
}
