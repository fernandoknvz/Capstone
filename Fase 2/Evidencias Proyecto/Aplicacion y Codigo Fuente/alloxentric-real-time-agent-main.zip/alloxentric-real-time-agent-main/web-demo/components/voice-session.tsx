'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import { RoomAudioRenderer, SessionProvider, useSession } from '@livekit/components-react';
import { ConnectionState, TokenSource, type TokenSourceResponseObject } from 'livekit-client';
import { ConversationPanel } from '@/components/conversation-panel';
import { VoiceControls } from '@/components/voice-controls';
import { BackIcon } from '@/components/icons';
import { personaLabel, personaOption, type PersonaId } from '@/lib/personas';

type VoiceSessionProps = {
  onLogout: () => Promise<void>;
  // Si se indica, la sesión despacha a esa persona cuando la persona usuaria
  // confirma el inicio mediante el control visible.
  persona?: PersonaId;
  // Se llama al volver a la lista de agentes (solo con `persona`).
  onExit?: () => void;
};

async function fetchPersonaToken(persona: PersonaId, signal?: AbortSignal): Promise<TokenSourceResponseObject> {
  const response = await fetch('/api/livekit-token', {
    method: 'POST',
    credentials: 'same-origin',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ persona }),
    signal,
  });
  if (!response.ok) throw new Error('token_request_failed');
  const body = (await response.json()) as { server_url: string; participant_token: string };
  return { serverUrl: body.server_url, participantToken: body.participant_token } as TokenSourceResponseObject;
}

export function VoiceSession({ onLogout, persona, onExit }: VoiceSessionProps) {
  const tokenSource = useMemo(
    () => (persona
      ? TokenSource.custom(() => fetchPersonaToken(persona))
      : TokenSource.endpoint('/api/livekit-token', { credentials: 'same-origin' })),
    [persona],
  );
  const conversation = useMemo(
    () => ({ id: `conv-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, startedAt: Date.now() }),
    // Una conversación nueva por persona elegida.
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [persona],
  );
  const session = useSession(tokenSource, { agentConnectTimeoutMilliseconds: 20_000 });
  const [error, setError] = useState('');
  const [operationPending, setOperationPending] = useState(false);
  const operationPendingRef = useRef(false);
  const mountedRef = useRef(true);
  const operationRef = useRef(0);
  const abortRef = useRef<AbortController | null>(null);
  const endPromiseRef = useRef<Promise<void> | null>(null);
  const sessionEndRef = useRef(session.end);
  sessionEndRef.current = session.end;

  const connecting = operationPending || session.connectionState === ConnectionState.Connecting;

  function closeSession(): Promise<void> {
    abortRef.current?.abort();
    abortRef.current = null;
    if (!endPromiseRef.current) {
      endPromiseRef.current = sessionEndRef.current().finally(() => {
        endPromiseRef.current = null;
      });
    }
    return endPromiseRef.current;
  }

  useEffect(() => {
    mountedRef.current = true;
    return () => {
      mountedRef.current = false;
      operationRef.current += 1;
      void closeSession().catch(() => undefined);
    };
  }, []);

  async function start() {
    if (operationPendingRef.current) return;
    operationPendingRef.current = true;
    const operation = ++operationRef.current;
    const controller = new AbortController();
    abortRef.current = controller;
    setOperationPending(true);
    setError('');
    try {
      await session.start({ signal: controller.signal });
    } catch {
      let cleanupFailed = false;
      try {
        await closeSession();
      } catch {
        cleanupFailed = true;
      }
      if (mountedRef.current && operation === operationRef.current) {
        setError(cleanupFailed
          ? 'No fue posible iniciar la conversación. Además, no se pudo confirmar el cierre de la conexión; recarga la página antes de reintentar.'
          : 'No fue posible iniciar la conversación. Verifica que el worker esté disponible y vuelve a intentar.');
      }
    } finally {
      if (operation === operationRef.current) {
        operationPendingRef.current = false;
        if (mountedRef.current) setOperationPending(false);
      }
    }
  }

  async function end() {
    if (operationPendingRef.current) return;
    operationPendingRef.current = true;
    const operation = ++operationRef.current;
    setOperationPending(true);
    setError('');
    try {
      await closeSession();
    } catch {
      if (mountedRef.current && operation === operationRef.current) {
        setError('La sesión terminó con un error de conexión. Recarga la página antes de reintentar.');
      }
    } finally {
      if (operation === operationRef.current) {
        operationPendingRef.current = false;
        if (mountedRef.current) setOperationPending(false);
      }
    }
  }

  const stateLabel = session.isConnected
    ? 'Conectado: el micrófono está activo'
    : connecting
      ? 'Conectando con el agente…'
      : 'Listo para iniciar';

  async function exit() {
    await end();
    onExit?.();
  }

  if (persona) {
    const option = personaOption(persona);
    return (
      <SessionProvider session={session}>
        <section className="call" aria-label={`Llamada con ${personaLabel(persona)}`}>
          <div className="call-top">
            <button
              className="button button-ghost"
              type="button"
              onClick={exit}
              disabled={operationPending && !session.isConnected}
            >
              <BackIcon className="icon" />
              Volver a los agentes
            </button>
            <span className="call-line">Llamada de demostración</span>
          </div>
          <ConversationPanel
            conversationId={conversation.id}
            personaId={persona}
            startedAt={conversation.startedAt}
            connected={session.isConnected}
            connecting={connecting}
            persona={option}
          >
            <VoiceControls connected={session.isConnected} connecting={connecting} onStart={start} onEnd={end} />
          </ConversationPanel>
          {error && <p className="error" role="alert">{error}</p>}
        </section>
        <RoomAudioRenderer />
      </SessionProvider>
    );
  }

  return (
    <SessionProvider session={session}>
      <p>Presiona iniciar y autoriza el micrófono cuando lo solicite el navegador.</p>
      <div className="status" role="status">
        <span className="status-dot" data-active={session.isConnected} aria-hidden="true" />
        {stateLabel}
      </div>
      <VoiceControls connected={session.isConnected} connecting={connecting} onStart={start} onEnd={end} />
      <div className="button-row">
        <button className="button" type="button" onClick={onLogout} disabled={session.isConnected || operationPending}>
          Cerrar acceso
        </button>
      </div>
      {error && <p className="error" role="alert">{error}</p>}
      <RoomAudioRenderer />
    </SessionProvider>
  );
}
