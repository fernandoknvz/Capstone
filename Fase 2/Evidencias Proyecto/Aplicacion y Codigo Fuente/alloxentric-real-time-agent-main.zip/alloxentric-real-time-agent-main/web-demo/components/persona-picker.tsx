import { ArrowIcon, PersonaGlyph } from '@/components/icons';
import { PERSONAS, SCOPE_LABEL, type PersonaId } from '@/lib/personas';

export function PersonaPicker({ onSelect }: { onSelect: (id: PersonaId) => void }) {
  return (
    <section aria-labelledby="persona-heading" className="lines-section">
      <div className="section-head">
        <h2 id="persona-heading" className="section-title">Elige un agente y habla con él</h2>
        <span className="section-note">{PERSONAS.length} agentes disponibles</span>
      </div>
      <p className="section-lede">
        Solo la clínica dental cuenta con una prueba conversacional real documentada; los otros seis agentes
        tienen el guion configurado, sin prueba real documentada.
      </p>
      <div className="lines">
        {PERSONAS.map((persona) => (
          <button
            key={persona.id}
            type="button"
            className="line-card"
            onClick={() => onSelect(persona.id)}
          >
            <span className="line-top">
              <span className="line-glyph">
                <PersonaGlyph icon={persona.icon} className="line-icon" />
              </span>
              <span className="line-tag">{persona.tag}</span>
            </span>
            <span className="line-name">{persona.label}</span>
            <span className="line-tagline">{persona.tagline}</span>
            <span className="line-scope" data-scope={persona.scope}>{SCOPE_LABEL[persona.scope]}</span>
            <span className="line-cta">
              Llamar
              <ArrowIcon className="icon" />
            </span>
          </button>
        ))}
      </div>
    </section>
  );
}
