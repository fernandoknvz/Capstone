import type { PersonaIcon } from '@/lib/personas';

type Props = { className?: string };

function Svg({ className, children }: Props & { children: React.ReactNode }) {
  return (
    <svg
      className={className}
      viewBox="0 0 24 24"
      width="24"
      height="24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.6"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      focusable="false"
    >
      {children}
    </svg>
  );
}

export function PersonaGlyph({ icon, className }: { icon: PersonaIcon } & Props) {
  switch (icon) {
    case 'headset':
      return (
        <Svg className={className}>
          <path d="M4 14v-2a8 8 0 0 1 16 0v2" />
          <rect x="3" y="14" width="4" height="6" rx="1.5" />
          <rect x="17" y="14" width="4" height="6" rx="1.5" />
          <path d="M19 20c0 1.4-1.6 2-4 2h-2" />
        </Svg>
      );
    case 'coin':
      return (
        <Svg className={className}>
          <circle cx="12" cy="12" r="8.5" />
          <path d="M14.8 9.4c-.4-.9-1.4-1.4-2.8-1.4-1.6 0-2.7.8-2.7 2 0 3 5.6 1.2 5.6 4.1 0 1.2-1.2 2-2.9 2-1.5 0-2.6-.6-3-1.6M12 6.5V8m0 8v1.5" />
        </Svg>
      );
    case 'tooth':
      return (
        <Svg className={className}>
          <path d="M7.5 3.5c-2.3 0-4 1.8-4 4.3 0 2 .8 3.3 1.5 5 .6 1.5.6 3.2 1 5.2.3 1.4 1.1 2.5 2 2.5 1.2 0 1.4-2 1.9-3.6.3-1 .8-1.6 1.6-1.6s1.3.6 1.6 1.6c.5 1.6.7 3.6 1.9 3.6.9 0 1.7-1.1 2-2.5.4-2 .4-3.7 1-5.2.7-1.7 1.5-3 1.5-5 0-2.5-1.7-4.3-4-4.3-1.6 0-2.5.8-4.5.8s-2.9-.8-4.5-.8Z" />
        </Svg>
      );
    case 'ledger':
      return (
        <Svg className={className}>
          <rect x="4" y="3.5" width="16" height="17" rx="2" />
          <path d="M8 8h8M8 12h8M8 16h4" />
        </Svg>
      );
    case 'wifi':
      return (
        <Svg className={className}>
          <path d="M3 9.5a14 14 0 0 1 18 0M6 13a9.5 9.5 0 0 1 12 0M9 16.4a5 5 0 0 1 6 0" />
          <circle cx="12" cy="19.5" r="1" fill="currentColor" />
        </Svg>
      );
    case 'card':
      return (
        <Svg className={className}>
          <rect x="2.5" y="5" width="19" height="14" rx="2.5" />
          <path d="M2.5 10h19M6 15h4" />
        </Svg>
      );
    case 'briefcase':
      return (
        <Svg className={className}>
          <rect x="3" y="7.5" width="18" height="12" rx="2" />
          <path d="M9 7.5V6a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v1.5M3 13h18" />
        </Svg>
      );
  }
}

export function MicIcon({ className, off = false }: Props & { off?: boolean }) {
  return (
    <Svg className={className}>
      <rect x="9" y="3" width="6" height="11" rx="3" />
      <path d="M5.5 11.5a6.5 6.5 0 0 0 13 0M12 18v3" />
      {off && <path d="M4 4l16 16" />}
    </Svg>
  );
}

export function HangupIcon({ className }: Props) {
  return (
    <Svg className={className}>
      <path d="M3.5 14.5c4.7-4 12.3-4 17 0l-1.8 2.7-3.1-1.4v-2.4a9 9 0 0 0-3.2-.5 9 9 0 0 0-3.2.5v2.4l-3.1 1.4-2.6-2.7Z" />
    </Svg>
  );
}

export function ArrowIcon({ className }: Props) {
  return (
    <Svg className={className}>
      <path d="M5 12h14M13 6l6 6-6 6" />
    </Svg>
  );
}

export function BackIcon({ className }: Props) {
  return (
    <Svg className={className}>
      <path d="M19 12H5M11 6l-6 6 6 6" />
    </Svg>
  );
}
