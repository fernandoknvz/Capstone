import { HangupIcon, MicIcon } from '@/components/icons';

export type VoiceControlsProps = {
  connected: boolean;
  connecting: boolean;
  onStart: () => void;
  onEnd: () => void;
};

export function VoiceControls({ connected, connecting, onStart, onEnd }: VoiceControlsProps) {
  return (
    <div className="button-row">
      {!connected ? (
        <button className="button button-primary" type="button" onClick={onStart} disabled={connecting}>
          <MicIcon className="icon" />
          {connecting ? 'Conectando…' : 'Iniciar conversación'}
        </button>
      ) : (
        <button className="button button-danger" type="button" onClick={onEnd}>
          <HangupIcon className="icon" />
          Finalizar conversación
        </button>
      )}
    </div>
  );
}
