# CLAUDE.md — Alloxentric Real Time Agent

Contexto compartido del proyecto. Este archivo está versionado en Git y aplica a todos los integrantes que trabajen con Claude Code en este repositorio. Toda modificación a este archivo debe pasar por revisión del equipo.

## Leyenda de clasificación

Toda decisión o afirmación relevante debe clasificarse cuando corresponda:

| Etiqueta | Significado |
|---|---|
| **CONFIRMADO** | Respaldado explícitamente por el equipo o el cliente. |
| **PROPUESTA** | Sugerida, aún no aprobada. |
| **INFERENCIA** | Deducida de información confirmada; requiere validación. |
| **PENDIENTE** | Falta información; no se debe asumir. |

## 1. Contexto del proyecto

- **Proyecto:** Alloxentric Real Time Agent — agente conversacional de voz en tiempo real. (CONFIRMADO)
- **Naturaleza:** Proyecto Capstone de Ingeniería en Informática, Duoc UC, S2 2026. (CONFIRMADO)
- **Cliente:** Alloxentric. (CONFIRMADO)
- **Equipo de desarrollo:** Fernando Olguea (líder del equipo), Juan Díaz y David Sepúlveda. (CONFIRMADO)
- **Este repositorio:** repositorio privado de desarrollo del producto. Es independiente del repositorio académico de evidencias Capstone. (CONFIRMADO)
- **Gestión del trabajo:** CoreStream se utiliza para épicas, tickets y evidencias. (CONFIRMADO)
- **Fase actual:** configuración del repositorio, ticket DART_14-1.3. (CONFIRMADO)

## 2. Objetivo del MVP

- Lograr una **conversación de voz completa de extremo a extremo en tiempo real**. (CONFIRMADO)
- LiveKit forma parte del flujo conversacional requerido. (CONFIRMADO)
- Flujo técnico preliminar: **voz → STT → LLM → TTS → voz**, orquestado/integrado mediante LiveKit. (CONFIRMADO como flujo preliminar; los componentes concretos de STT, LLM y TTS son PENDIENTE)
- El alcance se orienta primero al MVP funcional voz-a-voz; nada fuera de ese objetivo tiene prioridad hasta lograrlo.

## 3. Reglas obligatorias

1. **No inventar** requerimientos, arquitectura, tecnologías, proveedores, procesos de negocio, cifras ni restricciones.
2. **Clasificar** las decisiones relevantes como CONFIRMADO, PROPUESTA, INFERENCIA o PENDIENTE.
3. **No implementar** funcionalidades hasta que el requerimiento asociado esté suficientemente definido.
4. **Inspeccionar el estado actual del repositorio** antes de modificar código.
5. **Mantener trazabilidad** entre requerimientos, implementación, pruebas y evidencias.
6. **No almacenar secretos en Git:** credenciales, tokens, API keys ni archivos `.env` con valores reales.
7. **No hacer commits, push, merge ni modificaciones destructivas** sin autorización explícita.
8. **No desarrollar funcionalidades directamente sobre `main`.** Usar ramas de trabajo y Pull Requests una vez definido el flujo Git.
9. **No seleccionar tecnologías por defecto.** Las decisiones técnicas se justifican con requerimientos confirmados.
10. **Si falta información, marcarla como PENDIENTE** en lugar de asumirla.
11. **Priorizar el MVP funcional voz-a-voz.**
12. **Documentar las decisiones arquitectónicas relevantes** cuando corresponda.

## 4. Cómo debe trabajar Claude Code aquí

- Antes de proponer o ejecutar cambios, revisar el estado actual del repositorio (archivos, rama, historial).
- Ante ambigüedad, preguntar o registrar PENDIENTE; no rellenar vacíos con supuestos.
- Al proponer una solución técnica, indicar qué requerimiento confirmado la justifica y su clasificación.
- No instalar dependencias ni agregar tecnologías sin que exista una decisión clasificada y justificada.
- Al finalizar un cambio, indicar qué requerimiento/ticket atiende y cómo se verificará (prueba o evidencia).

## 5. Trazabilidad

- Cada cambio debe poder vincularse a un ticket de CoreStream (formato de referencia visto: `DART_14-1.3`).
- Cadena esperada: requerimiento → implementación → prueba → evidencia.
- Convención de nombres de ramas, mensajes de commit y formato de PR: **PENDIENTE** (flujo Git aún no definido).

## 6. Decisiones abiertas

| Tema | Estado |
|---|---|
| Flujo Git (ramas, PR, revisión, protección de `main`) | PENDIENTE |
| Proveedor/modelo de STT | PENDIENTE |
| Proveedor/modelo de LLM | PENDIENTE |
| Proveedor/modelo de TTS | PENDIENTE |
| Lenguaje, framework y estructura del repositorio | PENDIENTE |
| Despliegue de LiveKit (nube o autoalojado) | PENDIENTE |
| Requerimientos funcionales y no funcionales detallados (idioma, latencia, casos de uso) | PENDIENTE |
| Estrategia de pruebas | PENDIENTE |
| Gestión de secretos y configuración por entorno | PENDIENTE |
| Registro de decisiones arquitectónicas (ubicación y formato) | PENDIENTE |

## 7. Mantenimiento de este archivo

- Solo debe contener información respaldada por el equipo o el cliente.
- Cuando una decisión PENDIENTE se resuelva, actualizar su estado y registrar la fuente.
- Cambios a este archivo se realizan mediante rama y Pull Request una vez definido el flujo Git.
