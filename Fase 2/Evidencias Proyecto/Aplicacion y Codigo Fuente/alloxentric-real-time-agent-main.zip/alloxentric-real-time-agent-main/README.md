# alloxentric-real-time-agent

Alloxentric Real Time Agent — Agente conversacional de voz en tiempo real desarrollado como proyecto Capstone Duoc UC.

## Alcance actual

> Última actualización documental: 2026-10-26 (DART-14-4.3, en revisión). Ver `docs/validation/` para la validación de la conversación desde la Web Demo. DART-14-4.3 (validación funcional de conversación en navegador) y DART-14-4.4 (consolidación posterior de documentación y evidencias de demostración) son una organización de trabajo del equipo, no un requisito empresarial confirmado.

Este repositorio contiene la base de entorno Python/LiveKit (`DART_14-1.5`), los componentes del pipeline de voz implementados por separado (LLM: DeepSeek `DART_14-1.6` y Gemini `DART-14-2.1`; TTS: ElevenLabs `DART_14-1.6`; STT: Google Chirp 3 `DART_14-2.2`) y su **composición en una `AgentSession`** (`DART-14-2.4`). Es un incremento parcial del MVP.

**Estado, en resumen:**

| Aspecto | Estado |
|---|---|
| Componentes STT, LLM y TTS | Implementados; cada uno verificado de forma aislada por su responsable (ver las secciones de cada integración) |
| Pipeline `AgentSession` (STT → LLM → TTS) | **Construido** y conectado a `agent.py` |
| Pruebas automatizadas | Aprobadas, sin red (no consumen ningún proveedor) |
| Conversación de voz real de extremo a extremo | **Una prueba E2E exitosa** (2026-10-19, una sola sesión; evidencia en CoreStream): el agente reconoció la intervención del usuario, generó una respuesta y produjo audio audible. Es una muestra, no una validación estadística |
| Conversación de voz desde la Web Demo (navegador) | **Una prueba E2E reportada por el equipo** (2026-10-26, DART-14-4.3, una sola sesión): conversación de voz con cuatro turnos contabilizados. **Los logs originales no están archivados**; las cifras no están verificadas contra archivos. Ver [`docs/validation/DART-14-4.3-E2E-2026-10-26-web-demo.md`](docs/validation/DART-14-4.3-E2E-2026-10-26-web-demo.md) |
| Instrumentación de latencia | **Implementada** (DART-14-3.1): registro local por turno (ver "Métricas de latencia"); verificada con pruebas sin red y, según el reporte del equipo, usada en la sesión del 2026-10-26 |
| Mediciones de latencia del pipeline | **Solo cifras reportadas, sin logs originales** (2026-10-26: `e2e_latency_s` de 5,3589, 5,4732 y 4,5016 s en tres turnos, promedio 5,11 s; turno 1 sin dato). No constituyen línea base: son una muestra única sin respaldo archivado. Medición verificada y repetida: **PENDIENTE** |

**Lo que SÍ existe en este incremento:**
- Proyecto Python gestionado con [`uv`](https://docs.astral.sh/uv/).
- Dependencia del [LiveKit Agents SDK](https://docs.livekit.io/agents/) (`livekit-agents`, extras `[openai,elevenlabs]`, más `livekit-plugins-google` para Gemini y Chirp 3).
- Un entrypoint (`src/alloxentric_real_time_agent/agent.py`) con `AgentServer` / `@server.rtc_session` que, al recibir un job, construye la `AgentSession` de `pipeline.py` y la inicia en la sala (ver "Pipeline de voz"). La configuración requerida se valida con errores comprensibles.
- Validación de configuración (`src/alloxentric_real_time_agent/config.py`) para LiveKit, DeepSeek, Gemini, ElevenLabs, Google STT y la selección `LLM_PROVIDER`.
- **Componente LLM de DeepSeek** (`src/alloxentric_real_time_agent/llm.py`), compatible con `AgentSession(llm=...)`: recibe contexto conversacional en texto y devuelve la respuesta del modelo, en streaming. Seleccionable en el pipeline con `LLM_PROVIDER=deepseek`; su uso dentro de una conversación de voz real no se ha validado.
- Un script manual (`scripts/check_deepseek_llm.py`, **no** forma parte de la suite de `pytest`) para validar `texto → DeepSeek → respuesta` con una llamada real y de bajo costo, usando tu propia `DEEPSEEK_API_KEY` local.
- **Componente TTS de ElevenLabs** (`src/alloxentric_real_time_agent/tts.py`), compatible con `AgentSession(tts=...)`: recibe el texto de la respuesta destinada al usuario y devuelve audio sintetizado (`AudioFrame`), en streaming. Forma parte del pipeline de `pipeline.py`; su uso en una conversación de voz real no se ha validado.
- Un script manual (`scripts/check_elevenlabs_tts.py`, **no** forma parte de la suite de `pytest`) para validar `texto → ElevenLabs → audio` con una llamada real y breve, usando tu propia `ELEVEN_API_KEY` local.
- **Componente STT de Google Chirp 3** (`src/alloxentric_real_time_agent/stt.py`, `DART_14-2.2`), compatible con `AgentSession(stt=...)`. **Funciona de forma independiente** (audio → Chirp 3 → texto, verificado con `scripts/check_google_stt.py`) y, desde `DART-14-2.4`, se compone con el LLM y el TTS en `pipeline.py` (ver "Pipeline de voz").
- Pruebas con `pytest` (no consumen la API de DeepSeek, ElevenLabs, Google ni LiveKit).

**Lo que NO existe todavía (PENDIENTE, ver `CLAUDE.md`, sección 6):**
- **Validación repetida y mediciones de rendimiento del pipeline de voz.** Desde `DART-14-2.4` existe la composición `AgentSession` (STT → LLM → TTS) y, el 2026-10-19, se completó una prueba E2E real y, el 2026-10-26, el equipo reportó una segunda desde la Web Demo (`DART-14-4.3`). Siguen sin existir mediciones verificadas de latencia por etapa ni de voz a voz, ni muestras suficientes para compararlas: las cifras de la sesión del 2026-10-26 son solo reportadas y sus logs originales no están archivados. La instrumentación (`DART-14-3.1`) está implementada.
- Lógica de negocio del agente (el caso de uso de Alloxentric sigue PENDIENTE).
- Despliegue persistente del worker: no hay evidencia de uno. En la prueba reportada del 2026-10-26 el worker Python se ejecutó localmente.
- Existe `web-demo/`, un frontend de demostración (Netlify) que se integra con LiveKit Cloud (DART-14-4.1); ver `web-demo/README.md`.

El flujo técnico del MVP es: `LiveKit → STT → LLM → ElevenLabs (TTS) → LiveKit` (ver `CLAUDE.md`, sección 2). El STT es **Google Chirp 3** (DART_14-2.2, reemplaza a Speechmatics por indicación del cliente) y el LLM puede ser **Gemini** (DART-14-2.1, alternativa temporal) o **DeepSeek**, a elección con `LLM_PROVIDER`. Los componentes se componen en una `AgentSession` desde DART-14-2.4; eso es una composición verificada solo con pruebas sin red, no un agente de voz validado.

### Pipeline de voz — `AgentSession` (DART-14-2.4)

Composición inicial, implementada en `src/alloxentric_real_time_agent/pipeline.py` y conectada al `AgentServer` en `agent.py` (el decorador `@server.rtc_session` registra el worker con el nombre de `LIVEKIT_AGENT_NAME`, por defecto `alloxentric-real-time-agent`; ver "Nombre del agente y aislamiento de desarrollo").

```
audio de la sala LiveKit
   → STT  Google Chirp 3      (stt.create_google_stt)
   → LLM  Gemini | DeepSeek   (según LLM_PROVIDER)
   → TTS  ElevenLabs          (tts.build_elevenlabs_tts)
   → audio publicado en la sala
```

- `build_agent_session(env=None)` **solo compone** los builders existentes en una `AgentSession`; no reimplementa ningún componente ni duplica su configuración. Construida de forma aislada (como en las pruebas, sin un loop de asyncio en ejecución) no abre conexiones de red. **Dentro de un job real el comportamiento es distinto:** `AgentSession` precalienta el LLM al construirse (`llm.prewarm()`), y en el caso de Gemini eso programa una solicitud de listado de modelos (`models.list`, no una generación) en cuanto el loop se ejecuta, aunque nadie hable. Acumula todas las variables faltantes en un único `MissingConfigurationError`; la falta de ADC produce `MissingCredentialsError`.
- **Selección del LLM:** variable `LLM_PROVIDER` = `gemini` (por defecto, PROPUESTA) o `deepseek`. Un valor inválido produce `InvalidConfigurationError` **sin repetir el valor recibido** (podría ser una credencial pegada por error). Solo se exige la credencial del proveedor elegido.
- **VAD y turnos:** se usan los valores por defecto de `livekit-agents` 1.8.4, que incluyen un VAD silero local (`livekit.agents.inference.VAD`). No se agregaron `livekit-plugins-silero` ni `turn_detector`, ni dependencias nuevas. Reintentos y tiempos de espera de cada proveedor quedan en los valores por defecto del SDK (PENDIENTE de decisión).
- **Grabación:** `agent.py` inicia la sesión con `record=False`, de modo que el SDK no usa el ajuste del servidor (`job.enable_recording`) y desactiva de forma explícita el audio, la transcripción, las trazas y los logs de grabación de la sesión durante las pruebas de desarrollo. Esto **no garantiza** que no exista ninguna otra telemetría o almacenamiento externo: el SDK puede enviar logs de arranque o de fallo y los proveedores (Google, ElevenLabs, LiveKit Cloud) tienen sus propios registros y facturación. Revisa también la configuración del proyecto en LiveKit Cloud.
- **Instrucciones del agente: PROPUESTA TEMPORAL**, solo para pruebas técnicas ("asistente de voz de prueba… en español, breve… no solicita información personal"). No define un caso de uso de Alloxentric, que sigue PENDIENTE. El agente no saluda por iniciativa propia.
- **Errores y observabilidad:** `attach_observability(session)` registra los eventos `error` y `close` de la sesión. Del error solo se registran categoría, etiqueta del proveedor, nombre de la clase de la excepción y si es recuperable; **nunca el mensaje ni el detalle**, que podrían contener credenciales o contenido del usuario. Además engancha el recolector de métricas de latencia (ver "Métricas de latencia"). Este README no reporta ningún valor de latencia del pipeline: no existen mediciones.

**Dos tipos de credencial de Google (no confundir):**

| Uso | Mecanismo | Variables |
|---|---|---|
| Gemini (LLM) | API key de Google AI Studio | `GOOGLE_API_KEY`, `GEMINI_MODEL` (opcional) |
| Chirp 3 (STT) | Application Default Credentials (ADC), sin API key | `GOOGLE_CLOUD_PROJECT`, `GOOGLE_STT_LOCATION`, `GOOGLE_STT_LANGUAGE` (opcionales) |

Para las ADC: instala Google Cloud CLI y ejecuta `gcloud auth application-default login` con tu cuenta, y luego `gcloud auth application-default set-quota-project <ID_DEL_PROYECTO>`. Alternativamente, define `GOOGLE_APPLICATION_CREDENTIALS` con la ruta a un archivo de cuenta de servicio que **nunca** debe versionarse.

**Limitaciones actuales:**
- Hay **dos** pruebas E2E reales: 2026-10-19 y 2026-10-26 (esta última reportada por el equipo, sin logs originales archivados; ver `docs/validation/`). Las pruebas automatizadas verifican composición, configuración, registro de errores y métricas, sin red.
- Sin mediciones verificadas de latencia del pipeline: las cifras del 2026-10-26 (E2E de 5,11 s de promedio en tres turnos) son solo reportadas. La cifra suelta anterior (Gemini, 4,25 s en una muestra, solo la llamada al LLM) no representa el pipeline.
- Idioma, voz del producto, instrucciones del agente y despliegue de LiveKit siguen PENDIENTES.

**Procedimiento de validación real (el usado en la prueba del 2026-10-19; cada ejecución requiere autorización explícita):**
1. Tener las credenciales de LiveKit, del LLM elegido, de ElevenLabs y las ADC de Chirp 3 configuradas localmente (nunca en Git).
2. Iniciar el worker con `uv run alloxentric-agent dev` y unirse a la sala con un cliente de LiveKit.
3. Decir una frase **no sensible**, una sola conversación breve.
4. Registrar si hubo respuesta hablada, los errores de sesión y las líneas `metrics ...` del worker (ver "Métricas de latencia"), como **una muestra**, no como benchmark.
5. Repetir con `LLM_PROVIDER=deepseek` para comparar, solo si se autoriza.

### Nombre del agente y aislamiento de desarrollo (DART-14-5.1)

- **Finalidad:** `LIVEKIT_AGENT_NAME` fija el nombre con el que el worker se registra en LiveKit. La Web Demo despacha por nombre explícito (`RoomAgentDispatch`, `agentName`), de modo que solo atiende la sesión un worker registrado con ese mismo nombre.
- **Valor por defecto:** si la variable falta o está vacía, el nombre es `alloxentric-real-time-agent`, el mismo de la Web Demo publicada. Sin la variable el comportamiento no cambia.
- **Formato:** minúsculas, dígitos y guiones, sin guion inicial, hasta 63 caracteres. Un valor inválido hace fallar el arranque con `InvalidConfigurationError`, sin repetir el valor.
- **Worker de desarrollo:** define la variable solo en el proceso que lo inicia (no en el `.env.local` compartido):

  ```powershell
  $env:LIVEKIT_AGENT_NAME = "alloxentric-real-time-agent-dev"
  uv run alloxentric-agent dev --log-level info --no-reload
  ```

  La Web Demo local debe usar el mismo valor en `LIVEKIT_AGENT_NAME` de `web-demo/.env.local`; la publicada conserva el de Netlify. El navegador no puede elegir el nombre del agente. El metadato de despacho sigue siendo `{"persona":"<id>"}`.
- **Precedencia (livekit-agents 1.8.4):** `LIVEKIT_AGENT_NAME_OVERRIDE` > argumento `agent_name` del decorador > `LIVEKIT_AGENT_NAME`. Como el decorador recibe siempre un nombre, el valor se resuelve en `config.resolve_agent_name()` y se pasa de forma explícita.
- **Limitaciones:** el aislamiento es solo por nombre de despacho. Ambos workers siguen usando el mismo proyecto LiveKit y las mismas credenciales de proveedores, y un worker de desarrollo con el nombre de producción (o una Web Demo local con el nombre equivocado) recibiría o enviaría sesiones al destino equivocado. Compartir un proyecto LiveKit también comparte salas, límites y facturación. Para aislamiento fuerte, usa un proyecto LiveKit separado (decisión PENDIENTE).

### Métricas de latencia (DART-14-3.1)

`src/alloxentric_real_time_agent/metrics.py` se engancha desde `attach_observability` y escribe **líneas de log locales con nivel INFO** en el logger `alloxentric_real_time_agent.metrics`, con el formato `metrics <tipo> {json}`. No crea archivos, no envía nada fuera del proceso y no activa observabilidad remota; `record=False` se mantiene. Usa solo eventos oficiales de livekit-agents 1.8.4 (`conversation_item_added`, `agent_state_changed`, `session_usage_updated`, `error`, `close`); **no** usa `metrics_collected`, que el SDK marca como obsoleto.

**Líneas que se registran:**

| Línea | Cuándo | Contenido |
|---|---|---|
| `metrics startup` | Una vez, cuando el agente sale de `initializing` | `startup_s` |
| `metrics turn` | Una por respuesta del agente | `turn`, los tiempos disponibles y `interrupted` |
| `metrics session_summary` | Una vez, al cerrar la sesión | `turns`, `errors` por tipo, `close_reason`, `startup_s` y `usage` si existen |

**Indicadores por turno (todos en segundos, sufijo `_s`; fuente: `ChatMessage.metrics` del SDK):**

| Campo | Qué representa | Mensaje de origen |
|---|---|---|
| `transcription_delay_s` | Tiempo para obtener la transcripción tras terminar de hablar el usuario (etapa STT) | usuario |
| `end_of_turn_delay_s` | Espera entre el fin del habla y la decisión de que el turno terminó | usuario |
| `llm_node_ttft_s` | Tiempo hasta el **primer token** del LLM (no la duración total de la generación) | agente |
| `tts_node_ttfb_s` | Tiempo hasta el **primer fragmento de audio** del TTS | agente |
| `playback_latency_s` | Demora entre el primer fotograma de audio enviado y su reproducción | agente |
| `e2e_latency_s` | Desde que el usuario terminó de hablar (según el VAD) hasta que el agente empezó a hablar; es lo más cercano a la latencia de voz a voz | agente |

El campo `startup_s` mide desde justo antes de `session.start` hasta que el agente sale de `initializing`; **no** incluye la espera previa a la asignación del job ni la conexión del cliente. `usage` resume el uso acumulado por proveedor y modelo (tokens, caracteres, segundos de audio).

**Limitaciones y cómo interpretarlas:**
- **Métricas por etapa vs. `e2e_latency_s`:** las etapas **pueden solaparse**, porque la generación anticipada de livekit-agents 1.8.4 está activa por defecto y el LLM puede empezar antes de que se decida el fin del turno. Por eso **no se deben sumar** las etapas para obtener la latencia de voz a voz: usar `e2e_latency_s`.
- **No confundir** tiempo hasta el primer token (`llm_node_ttft_s`) con tiempo total de generación, ni con la latencia de conexión o con lo que percibe la persona usuaria.
- Los campos que el SDK no informa se **omiten** de la línea (nunca se registran como cero). Los valores no numéricos, no finitos o negativos se tratan como ausentes.
- **Asociación de turnos:** `transcription_delay_s` y `end_of_turn_delay_s` provienen del mensaje del usuario y se emparejan con la respuesta usando las marcas de tiempo del SDK (el usuario debe haber terminado de hablar antes de que empiece la respuesta, y `e2e_latency` debe coincidir con ese emparejamiento); sin marcas de tiempo se usa el orden de llegada. Ante interrupciones, respuestas canceladas o mensajes de usuario entregados **después** de su respuesta, esos dos campos se **omiten** de la línea en lugar de asignarse a otro turno. Las marcas de tiempo se usan solo para emparejar y no se registran.
- `e2e_latency_s` depende del fin de habla detectado por el VAD y de la reproducción en el cliente; es una aproximación.
- Gemini puede generar tokens de razonamiento que alarguen `llm_node_ttft_s` (hipótesis a verificar con mediciones).
- Cada línea corresponde a **una muestra** de una sesión real. No hay cifras de referencia en este repositorio; para comparar hacen falta varias sesiones autorizadas.

**Privacidad:** solo se leen campos numéricos. **No** se registra texto de la conversación ni transcripciones, audio, credenciales, tokens, identificadores de solicitud de los proveedores, identidades de participantes ni nombres de sala (las pruebas lo verifican). Para ver estas líneas en una sesión real, el worker debe ejecutarse con `--log-level info`.

### Integración Google Chirp 3 STT — detalle técnico (DART_14-2.2)

- Integración **oficial** de LiveKit Agents: plugin `livekit-plugins-google` (extra `livekit-agents[google]`, `1.8.4`), clase `livekit.plugins.google.STT`, modelo **`chirp_3`** (Speech-to-Text API v2, streaming). Código en `src/alloxentric_real_time_agent/stt.py`.
- **Autenticación: Application Default Credentials (ADC), sin API key.** Instala [Google Cloud CLI](https://cloud.google.com/sdk/docs/install) y ejecuta con tu cuenta (necesita el rol *Cliente de Cloud Speech* en el proyecto):
  ```shell
  gcloud auth application-default login
  gcloud auth application-default set-quota-project <ID_DEL_PROYECTO>
  ```
- Configura en `.env.local`:
  ```
  GOOGLE_CLOUD_PROJECT=   # ID del proyecto (puede diferir del nombre "alloxentric-real-time-agent")
  # Opcionales (PROPUESTA):
  # GOOGLE_STT_LOCATION=us
  # GOOGLE_STT_LANGUAGE=es-US
  ```
- **Ubicación (PROPUESTA): `us`.** Chirp 3 no se sirve desde `global`; el plugin usa el endpoint regional `us-speech.googleapis.com`.
- **Idioma (PROPUESTA): `es-US`.** El idioma definitivo del producto es **PENDIENTE**. Google lista `es-ES` y `es-US` como GA para Chirp 3 y `es-MX` como Preview. La detección automática de idioma está desactivada.
- Contrato: entrada = frames de audio de LiveKit; salida = `SpeechEvent` de LiveKit (`INTERIM_TRANSCRIPT` parcial y `FINAL_TRANSCRIPT` final), consumibles por `AgentSession(stt=...)`. Chirp 3 no entrega timestamps por palabra (el plugin los desactiva).
- Errores: sin `GOOGLE_CLOUD_PROJECT` → `MissingConfigurationError`; sin ADC → `MissingCredentialsError` (con las instrucciones de arriba). Permisos IAM, API deshabilitada o ubicación/idioma no soportados aparecen al abrir el stream (`APIConnectionError`/`APIStatusError` de LiveKit).

### Validar la integración Google Chirp 3

```shell
uv run python scripts/check_google_stt.py ruta/frase.wav
```

Requiere ADC y `GOOGLE_CLOUD_PROJECT`. El WAV debe ser PCM 16-bit, mono, 16 kHz, con una frase **no sensible**. Hace **una única** transcripción real (consume cuota/crédito de Google; no se ejecuta con `pytest` ni en CI) e imprime modelo, idioma, ubicación, cada evento parcial/final con su tiempo y la latencia aproximada tras el fin del habla. Google no informa el consumo por llamada: se revisa en la consola de facturación. El script termina con código `0` si llegó una transcripción final con texto, `1` si la solicitud falló o no hubo transcripción final, y `2` si el WAV o la configuración son inválidos. Ante errores sólo imprime el tipo de excepción (y su código de estado), nunca el mensaje del proveedor.

**Validación real (2026-10-16, Juan):** audio → Google Chirp 3 → texto **funciona de forma aislada** con `chirp_3`, `es-US`, ubicación `us`, proyecto `alloxentric-real-time-agent` y ADC de usuario. Frase sintética (voz local es-MX de Windows, 4,24 s): se transcribió correctamente como "Hola, esta es una prueba de transcripción en tiempo real." con puntuación. Observaciones, sobre **una sola ejecución con audio sintético**, por lo que son orientativas y no un benchmark:
- Sólo llegó un `FINAL_TRANSCRIPT`; **no se observaron parciales** en esta prueba, aunque `interim_results` está activo.
- El resultado final llegó ~1,1 s después del fin del habla (esa cifra incluye ~2 s de silencio enviado después de la frase; en una corrida anterior con envío menos preciso fue ~1,3 s).
- El consumo no se pudo medir: Google no lo informa por llamada (el evento `RECOGNITION_USAGE` no trae costo). Revisar en la consola de facturación.
- Al usar ADC de usuario aparece un aviso de "quota project": la cuenta no tiene `serviceusage.services.use`, pero las llamadas funcionaron.
- Esto **no** valida el pipeline de voz E2E, ni voz humana real por micrófono, ni el rendimiento en conversación.

### Integración DeepSeek — detalle técnico (DART_14-1.6)

- Se usa la integración **oficial** de LiveKit Agents para DeepSeek: el plugin `openai` (DeepSeek expone una API compatible con OpenAI) a través de `livekit.plugins.openai.LLM.with_deepseek(...)`. **No** existe ni se agregó un paquete `livekit-plugins-deepseek` separado.
- Configura tu clave en `.env.local`:
  ```
  DEEPSEEK_API_KEY=
  DEEPSEEK_MODEL=deepseek-flash   # opcional; es el default del proyecto
  ```
- **Discrepancia LiveKit vs. DeepSeek (confirmada, resuelta):**
  - `livekit-plugins-openai==1.8.4` (la versión instalada) y la documentación actual de LiveKit siguen mostrando `"deepseek-chat"` como modelo de ejemplo/default de `with_deepseek()`.
  - La documentación oficial **vigente** de DeepSeek (fuente primaria) confirma que `deepseek-chat` y `deepseek-reasoner` **fueron retirados el 2026-07-24**, y que **DeepSeek-V4.1-Flash se publicó el 2026-09-10**, con identificador de API **`deepseek-flash`** (base URL `https://api.deepseek.com`, compatible con OpenAI).
  - Es decir: el ejemplo de LiveKit está desactualizado respecto a DeepSeek. Por eso **este proyecto fija explícitamente `deepseek-flash`** como default (`DEFAULT_DEEPSEEK_MODEL` en `config.py`) y `build_deepseek_llm()` siempre pasa el modelo de forma explícita a `with_deepseek(model=...)`, sin depender nunca del default interno de LiveKit.
  - Se sigue usando la integración directa vía plugin `openai` + `DEEPSEEK_API_KEY` (**no** LiveKit Inference): no cambia el proveedor ni el mecanismo, solo el nombre de modelo.
  - `DEEPSEEK_MODEL` queda disponible para corregir esto en un solo lugar, sin tocar código, si DeepSeek vuelve a renombrar sus modelos.

### Validar la integración DeepSeek

```shell
uv run python scripts/check_deepseek_llm.py
```

Requiere `DEEPSEEK_API_KEY` configurada en `.env.local`. Hace **una única** llamada real a la API de DeepSeek (no se ejecuta con `pytest` ni en CI) e imprime el modelo usado, la latencia aproximada, los tokens informados por la API (si los informa) y la respuesta generada. Nunca imprime la API key.

### Integración Gemini (LLM alternativo) — detalle técnico (DART-14-2.1)

- **Gemini es una alternativa temporal a DeepSeek**, autorizada por Alloxentric. DeepSeek (`llm.py`) sigue disponible y sin cambios. Gemini vive en `src/alloxentric_real_time_agent/llm_gemini.py` (`build_gemini_llm()`), con el mismo contrato (`AgentSession(llm=...)`). Es seleccionable en `pipeline.py` con `LLM_PROVIDER=gemini` (valor por defecto, PROPUESTA); su uso en una conversación de voz real no se ha validado.
- Integración **oficial** de LiveKit: plugin `livekit-plugins-google`, fijado a `==1.8.4` (misma versión que `livekit-agents`; la 1.8.7, más reciente, exige `livekit-agents>=1.8.7`). Se usa la **Gemini Developer API** con `vertexai=False` explícito. Vertex AI queda fuera de esta iteración.
- Configura en `.env.local` (nunca lo commitees):
  ```
  GOOGLE_API_KEY=
  # Opcional:
  # GEMINI_MODEL=gemini-3.1-flash-lite   # cambió de gemini-3.8-flash en DART-14-5.1 (ver más abajo)
  # GEMINI_THINKING_LEVEL=MINIMAL        # "off" si el modelo no lo soporta
  ```
  Obtén la clave en [Google AI Studio](https://aistudio.google.com/apikey) y pégala tú mismo en `.env.local`; no la pegues en el chat, en commits ni en logs.
- **Modelo (PROPUESTA, actualizado en DART-14-5.1): `gemini-3.1-flash-lite`** (antes `gemini-3.8-flash`, que figura como estable pero tardó ~3,6 s al primer token en nuestra medición). Figura como modelo de texto **estable** en la [lista oficial de Google](https://ai.google.dev/gemini-api/docs/models) y sin fecha de retiro en su [página de deprecaciones](https://ai.google.dev/gemini-api/docs/deprecations) (consultadas el 2026-10-14), y aparece en la documentación de LiveKit. El default del plugin instalado (`gemini-2.5-flash`) no se usa: solo se mantiene para usuarios que ya lo usaban. `gemini-3.5-flash-lite` es una opción a evaluar por latencia. La elección final es **PENDIENTE** de mediciones; se cambia con `GEMINI_MODEL`.
- **Prueba real:** Gemini respondió correctamente en una verificación real con `scripts/check_gemini_llm.py`, usando el modelo `gemini-3.8-flash`. La latencia observada fue de 4,25 s en una **única muestra**; no es una medición representativa ni refleja el pipeline completo de voz (STT → LLM → TTS), solo la llamada al LLM. El rendimiento del modelo sigue **PENDIENTE** de evaluación.
- Las pruebas automatizadas (`pytest`) son unitarias y no usan la red.

### Validar la integración Gemini

```shell
py -3.12 -m uv run python scripts/check_gemini_llm.py
```

Requiere `GOOGLE_API_KEY` en `.env.local`. Hace **una única** solicitud real con texto sintético a la Gemini Developer API (puede tener un costo mínimo según el plan de tu cuenta). No se ejecuta con `pytest` ni en CI. Imprime modelo, latencias, tokens (si la API los informa) y la respuesta; nunca la API key.

### Agentes por habilidad, latencia e historial (DART-14-5.1)

La demo web ofrece **7 botones**; cada uno abre una llamada de práctica con un agente distinto. Todo es una **simulación con datos ficticios** (empresas y personas ficticias; ver `docs/VOXENTRA_DEMO.md` para el recorte de la demostración académica):

| Botón | Escenario |
|---|---|
| Ventas de telefonía | Ejecutiva que intenta venderte un plan móvil (precios ficticios) |
| Cobranza retail | Deuda de $4.200.000 de una tarjeta de tienda (cliente ficticio) |
| Clínica dental | Asistente de agendamiento y consultas |
| Cobranza financiera | Deuda de $1.300.000 de una juguera cuyo CAE subió 300 % el último mes |
| Soporte de internet | Técnico (FibraSur, ficticio) que diagnostica fallas de fibra |
| Entrevista laboral | Reclutadora que entrevista para un cargo comercial |
| Atención postventa | Ejecutivo de servicio (Tarjeta Brújula ficticia) que atiende una compra no reconocida y bloquea la tarjeta |

- **Cómo se elige el agente:** el navegador envía solo el identificador (`persona`). El servidor de tokens lo valida contra una lista cerrada y lo pone en el metadato del despacho; el agente lo lee de `ctx.job.metadata`. Los *prompts* viven en `src/alloxentric_real_time_agent/personas.py` y nunca viajan por el cliente. El despacho sigue forzado por el servidor.
- **Cobranza:** el agente es respetuoso, no amenaza ni presiona y no menciona la deuda a terceros (confirma primero la identidad).
- **En la web:** selector de micrófono, botón para silenciarse, transcripción en vivo y un historial de conversaciones guardado **solo en el navegador** (`localStorage`; se puede descargar como `.txt` o borrar). No se graba audio.
- **Latencia — qué se hizo y qué se midió.** Objetivo: respuesta lo más inmediata posible sin recortar el contexto (el historial completo se conserva). Una respuesta de "menos de 2 milisegundos" no es físicamente posible (solo la red toma decenas de ms); el objetivo realista es de **~1–2 s**.
  - Modelo: `gemini-3.1-flash-lite` con thinking mínimo. Medición (misma clave y prompt, mediana de 4 corridas, tiempo al primer token): `gemini-3.8-flash` 3,64 s → `gemini-3.1-flash-lite` 1,55 s.
  - Turnos: *endpointing* dinámico con `min_delay` 0,3 s (antes 0,5 s) y generación preventiva de LLM y TTS (`preemptive_tts`).
  - Chirp 3 con sensibilidad de fin de habla `SHORT`. `SUPERSHORT` se probó y no mejoró de forma apreciable (0,96–1,13 s frente a 1,12–1,19 s), así que no se usa.
  - Respuestas cortas por *prompt* (1–2 frases) y tope de 220 tokens de salida.
  - **Resultado medido** (2 corridas por variante, audio sintético, desde Chile, orientativo): transcripción final ~1,15 s tras terminar de hablar; LLM 1,2–1,45 s hasta el primer token; TTS 0,28 s hasta el primer audio. Es decir, ~2,7 s entre el fin de la frase y el primer audio. **No se alcanzan 2 s**: el cuello de botella es el LLM por red y la espera de la transcripción final de Chirp 3.
  - Próximas palancas (PROPUESTA, sin medir): Gemini por Vertex AI en una región cercana (`southamerica-east1`), una muletilla inmediata ("claro, un momento") generada con TTS directo, y evaluar DeepSeek.

#### Voces chilenas y revisión de la prueba del 2026-10-30 (DART-14-5.1)

- **Voz por agente (PROPUESTA, sin validar de oído):** cada persona usa una voz de la biblioteca de ElevenLabs cuya ficha indica acento chileno. Se eligieron por los metadatos publicados (acento, género, edad, descripción), **no escuchándolas**: falta que el equipo las apruebe. Las voces están en `personas.py` (`voice_id`):

  | Agente | Voz | Ficha de la biblioteca |
  |---|---|---|
  | Ventas de telefonía (y agente por defecto) | Camila | mujer joven, "Native Chilean Spanish for customer service and sales" |
  | Cobranza retail | Rodrigo | hombre adulto, "Soft, Warm and Inviting" |
  | Clínica dental | Angela | mujer adulta, "Warm, Calm and Assured" |
  | Cobranza financiera | Emma | mujer adulta, "Authoritative, Assured and Clear", conversacional |
  | Soporte de internet | Marco | hombre joven, "Warm and Friendly" |
  | Entrevista laboral | Victoria | mujer joven, "Clear, secure, nice" |
  | Atención postventa | Cristian Cornejo | hombre adulto, "Spanish Chilean" |

  Las fichas salen de un directorio de terceros que replica la biblioteca; la API key del equipo no tiene permiso `voices_read`, así que no se pudo consultar la ficha oficial. `ELEVEN_VOICE_ID` en el entorno fuerza una misma voz para todos.
- **Modelo (PROPUESTA): `eleven_v4_turbo`.** Medición con la cuenta del equipo (plugin de LiveKit, streaming): primer audio 0,50–0,52 s frente a 0,48–0,49 s de `eleven_flash_v2_5`, con mayor calidad. `eleven_v3` y `eleven_v4` **no** se usan: la documentación de ElevenLabs indica que no soportan el WebSocket de tiempo real y por HTTP tardaron 0,67 y 0,75 s.
- **Arranque en frío de las voces:** la primera síntesis con cada voz tarda **4–6 s** y las siguientes ~0,3 s. Por eso cada proceso del worker precalienta en segundo plano las 7 voces (`voice_warmup.py`, ~5 caracteres por voz; `ELEVEN_VOICE_WARMUP=off` lo desactiva).
- **Corrección: transcripción duplicada.** LiveKit entrega lo que dice el usuario como dos streams del mismo segmento (`lk.segment_id` igual; uno `final=false` y otro `final=true`). El panel ahora agrupa por segmento.
- **Revisión de la prueba real (4 turnos, voz humana):** latencia total 2,36–2,65 s (tras terminar de hablar): ~1,05–1,14 s esperando la transcripción final de Chirp 3, ~0,9–1,1 s el LLM y ~0,28 s el primer audio. Las respuestas cortadas a media frase son interrupciones del usuario (`interrupted: true`), no un fallo. La respuesta más larga superó el límite pedido; se endureció el *prompt* (máximo 25 palabras).
- **Principal cuello de botella pendiente:** la espera de la transcripción final de Chirp 3 (~1,1 s). Opciones (PROPUESTA, no medidas): otro STT de menor latencia (esa decisión es del equipo/cliente) o un VAD más agresivo con confirmación por transcripción parcial.

### Integración ElevenLabs TTS — detalle técnico (DART_14-1.6)

- Se usa la integración **oficial** de LiveKit Agents: el plugin `livekit-plugins-elevenlabs` (extra `livekit-agents[elevenlabs]`, versión instalada `1.8.4`), clase `livekit.plugins.elevenlabs.TTS`. Soporta streaming vía WebSocket de ElevenLabs (`capabilities.streaming=True`).
- Configura tu clave en `.env.local`:
  ```
  ELEVEN_API_KEY=
  # Opcionales:
  # ELEVEN_TTS_MODEL=eleven_flash_v2_5
  # ELEVEN_VOICE_ID=
  ```
  El nombre `ELEVEN_API_KEY` es el que lee el plugin de LiveKit (verificado en su código y su documentación). **No** es `ELEVENLABS_API_KEY`, el nombre que usa el SDK propio de ElevenLabs.
- **Modelo (PROPUESTA; desde DART-14-5.1 el default es `eleven_v4_turbo`, ver arriba): `eleven_flash_v2_5`.** El default del plugin instalado es `eleven_turbo_v2_5`, que la [documentación vigente de ElevenLabs](https://elevenlabs.io/docs/models) marca como **deprecado**, con `eleven_flash_v2_5` como reemplazo: baja latencia, multilingüe e incluye español. El proyecto pasa siempre el modelo de forma explícita (`DEFAULT_ELEVENLABS_TTS_MODEL` en `config.py`) y nunca depende del default del plugin.
  - `eleven_v4_turbo` (publicado el 2026-09-28 y recomendado por ElevenLabs para agentes) usa el WebSocket *Text-to-Dialogue*, no el de *Text-to-Speech*. El plugin 1.8.4 lo soporta, pero ignora algunas opciones. Queda disponible vía `ELEVEN_TTS_MODEL` para evaluarlo; la elección final del modelo es **PENDIENTE** de requerimientos de latencia, idioma y costo.
- **Voz (histórica, DART_14-1.6; desde DART-14-5.1 cada agente usa una voz chilena, ver arriba): `hpp4J3VqNfWAUOO0d1Us`**, el `DEFAULT_VOICE_ID` del propio plugin. **No** es la voz del producto, que es **PENDIENTE**. Se cambia con `ELEVEN_VOICE_ID`.
- No se fija `language`: el idioma del producto es **PENDIENTE** (`CLAUDE.md`, sección 6).
- Errores: si falta `ELEVEN_API_KEY`, `build_elevenlabs_tts()` lanza `MissingConfigurationError` al construir. Los errores de autenticación, voz o modelo inválidos y de conexión los lanza el plugin al sintetizar (`APIStatusError`, `APIConnectionError`, `APITimeoutError`).

### Validar la integración ElevenLabs

```shell
uv run python scripts/check_elevenlabs_tts.py                  # streaming (WebSocket)
uv run python scripts/check_elevenlabs_tts.py --mode http      # texto completo (HTTP)
uv run python scripts/check_elevenlabs_tts.py --out prueba.wav # guarda el audio
```

Requiere `ELEVEN_API_KEY` en `.env.local`. Hace **una única** síntesis real de una frase breve y consume créditos de ElevenLabs según los caracteres enviados. No se ejecuta con `pytest` ni en CI. Imprime el modelo, la voz, el modo, la latencia aproximada al primer audio y la total, la duración del audio y, si la API key tiene permiso de lectura de usuario, los caracteres consumidos. Nunca imprime la API key.

**Validación real (2026-10-08, David):** texto → ElevenLabs → audio **funciona de forma aislada** con `eleven_flash_v2_5` y la voz de prueba `hpp4J3VqNfWAUOO0d1Us`, tanto en `--mode stream` (WebSocket) como en `--mode http`. Se recibió audio PCM 16-bit, 22 050 Hz, mono, de unos 3,2–3,7 s para una frase de 50 caracteres. La latencia al primer audio fue de ~0,7–0,8 s en una sola ejecución en frío, incluida la conexión: es un valor orientativo, no un benchmark. El consumo de créditos no se pudo medir porque la API key usada no tiene permiso de lectura de usuario. Esto **no** valida STT, LLM ni el pipeline de voz E2E.

## Prerrequisitos

- **Python 3.12 — versión de referencia validada para el desarrollo de este proyecto.** Es la versión con la que este incremento fue implementado y probado, y queda fijada en [.python-version](.python-version). `requires-python` en [pyproject.toml](pyproject.toml) acepta un rango mayor (`>=3.10,<3.15`, el soportado por `livekit-agents` 1.8.x) solo por compatibilidad; para desarrollar y ejecutar pruebas en este repositorio usa **Python 3.12**.
- [`uv`](https://docs.astral.sh/uv/) para gestión de proyecto y dependencias.

### Instalar uv

**Método recomendado — instalador oficial de Astral** (ver la [guía oficial de instalación](https://docs.astral.sh/uv/getting-started/installation/)):

```shell
# Windows (PowerShell)
powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"

# macOS / Linux
curl -LsSf https://astral.sh/uv/install.sh | sh
```

**Alternativa**, solo si ya tienes Python instalado y prefieres no usar el instalador oficial:

```shell
python -m pip install --user uv
```

Verifica la instalación con `uv --version`.

## Instalación y sincronización de dependencias

Desde la raíz del repositorio:

```shell
uv sync
```

Esto crea un entorno virtual en `.venv/` (ignorado por Git) e instala exactamente las versiones fijadas en [uv.lock](uv.lock), incluyendo las dependencias de desarrollo (`pytest`).

## Configuración (variables de entorno)

1. Copia el archivo de ejemplo:

   ```shell
   # Windows (PowerShell)
   Copy-Item .env.example .env.local

   # macOS / Linux
   cp .env.example .env.local
   ```

2. Completa las credenciales de tu proyecto LiveKit en `.env.local`:

   ```
   LIVEKIT_URL=
   LIVEKIT_API_KEY=
   LIVEKIT_API_SECRET=
   ```

3. Para ejecutar el pipeline completo, completa además la configuración de cada componente (ver sus secciones): `GOOGLE_CLOUD_PROJECT` y las ADC (Chirp 3), `ELEVEN_API_KEY` (ElevenLabs) y la credencial del LLM elegido con `LLM_PROVIDER` (`GOOGLE_API_KEY` para `gemini`, `DEEPSEEK_API_KEY` para `deepseek`).

`.env.local` y `.env` están ignorados por Git (ver [.gitignore](.gitignore)) y **nunca deben commitearse** con valores reales (ver `docs/GIT_WORKFLOW.md`, sección "Tratamiento de secretos").

## Ejecución del proyecto

Con la configuración anterior completa:

```shell
uv run alloxentric-agent dev
```

Esto inicia el worker de LiveKit Agents en modo desarrollo. Si falta alguna variable de entorno requerida, el agente lo reporta con un error explícito en cuanto recibe un job, indicando exactamente qué variable falta.

Al recibir un job, el agente construye la `AgentSession` (ver "Pipeline de voz" arriba), la inicia en la sala asignada y se conecta. Requiere las credenciales de LiveKit, del LLM elegido, de ElevenLabs y las ADC de Google para Chirp 3. **Una sesión real consume servicios externos** (Gemini desde el precalentamiento del job, Chirp 3 por el audio enviado, ElevenLabs por los caracteres sintetizados y LiveKit Cloud), con reintentos del SDK por defecto. **Se han completado dos pruebas E2E reales** (2026-10-19 y, reportada por el equipo, 2026-10-26); no hay mediciones de rendimiento verificadas con logs originales (ver "Procedimiento de validación real" y "Métricas de latencia"). Usa `--log-level info` y `--no-reload` en `dev`, y no pases credenciales por línea de comandos.

## Ejecución de pruebas

```shell
uv run pytest
```

Las pruebas actuales (`tests/`) verifican:
- que el paquete del proyecto y el SDK de LiveKit Agents se importan correctamente;
- que el módulo del agente define un `AgentServer` con un entrypoint registrado;
- que la configuración de LiveKit, de cada proveedor y de `LLM_PROVIDER` se valida correctamente cuando está completa;
- que falta de cada variable requerida (o una vacía) produce un error claro y específico;
- que el componente LLM de DeepSeek se construye correctamente (sin red) y es compatible con `AgentSession`;
- que el componente TTS de ElevenLabs se construye correctamente (sin red), con streaming, modelo y voz explícitos, y es compatible con `AgentSession`; y que la falta de `ELEVEN_API_KEY` produce un error claro;
- que el STT de Google se construye con `chirp_3`, ubicación regional e idioma configurables (credenciales simuladas, sin red), y que la falta de proyecto o de ADC produce un error claro;
- que el pipeline compone STT, LLM y TTS en una `AgentSession` (sin red), selecciona Gemini o DeepSeek según `LLM_PROVIDER`, rechaza proveedores inválidos, informa toda la configuración faltante y no filtra credenciales en errores ni en logs;
- que el recolector de métricas registra solo los campos disponibles (sin convertir ausentes en cero), evita duplicados, no registra texto de conversación ni identificadores, y resume la sesión al cerrar, también cuando no hubo turnos.

Ninguna prueba automatizada llama a las APIs reales de DeepSeek, ElevenLabs, Google ni LiveKit: eso se verifica manualmente con `scripts/check_deepseek_llm.py`, `scripts/check_elevenlabs_tts.py` y `scripts/check_google_stt.py` (ver arriba).

## Integración continua (DART-14-5.6)

**Estado:** CI implementada con GitHub Actions; despliegue continuo (CD) **PENDIENTE**. Workflow: [.github/workflows/ci.yml](.github/workflows/ci.yml). Evidencias: [docs/validation/DART-14-5.6-CI-github-actions.md](docs/validation/DART-14-5.6-CI-github-actions.md).

- **Objetivo:** ejecutar automáticamente las verificaciones de calidad de Python y de la Web Demo.
- **Disparadores:** Pull Requests hacia `main`, push a `main` y ejecución manual.
- **Jobs** (independientes, `ubuntu-24.04`):
  - `python-tests`: Python 3.12, uv 0.12.23, `uv sync --frozen` desde `uv.lock` y `pytest`.
  - `web-quality`: Node.js 24.15.0 y pnpm 9.15.9 en `web-demo/`; instalación con lockfile congelado, Vitest, ESLint, TypeScript, build de Next.js y verificación de `out/_headers` y de la CSP.
- **Restricciones:** permisos `contents: read`, acciones fijadas por SHA, sin secretos del proyecto, sin despliegues, sin llamadas a proveedores de IA, sin sesiones LiveKit y sin pruebas E2E reales.
- **Antes del merge:** los dos checks deben estar en verde y el PR requiere revisión de otro integrante (ver [docs/GIT_WORKFLOW.md](docs/GIT_WORKFLOW.md), sección 16).

## Estructura del repositorio

```
alloxentric-real-time-agent/
├── src/
│   └── alloxentric_real_time_agent/
│       ├── __init__.py
│       ├── agent.py       # Entrypoint de LiveKit Agents (inicia la AgentSession, DART-14-2.4)
│       ├── pipeline.py    # Composición STT + LLM + TTS en AgentSession (DART-14-2.4)
│       ├── metrics.py     # Recolector local de métricas de latencia (DART-14-3.1)
│       ├── config.py      # Validación de variables de entorno (LiveKit, proveedores, LLM_PROVIDER)
│       ├── llm.py         # Componente LLM de DeepSeek (DART_14-1.6)
│       ├── stt.py         # Componente STT de Google Chirp 3 (DART_14-2.2)
│       ├── llm_gemini.py  # Componente LLM alternativo de Gemini (DART-14-2.1)
│       └── tts.py         # Componente TTS de ElevenLabs (DART_14-1.6)
├── scripts/
│   ├── check_google_stt.py      # Verificación manual real, no es un test de pytest
│   ├── check_deepseek_llm.py    # Verificación manual real, no es un test de pytest
│   ├── check_gemini_llm.py      # Verificación manual real (Gemini), no es un test de pytest
│   └── check_elevenlabs_tts.py  # Verificación manual real, no es un test de pytest
├── tests/
│   ├── test_config.py
│   ├── test_llm.py
│   ├── test_stt.py
│   ├── test_llm_gemini.py
│   ├── test_metrics.py
│   ├── test_pipeline.py
│   ├── test_tts.py
│   └── test_project_bootstrap.py
├── docs/
│   └── GIT_WORKFLOW.md
├── .env.example
├── .gitignore
├── .python-version
├── pyproject.toml
├── uv.lock
├── README.md
├── CLAUDE.md
└── AGENTS.md
```

## Flujo de trabajo Git

Este repositorio sigue la estrategia documentada en [docs/GIT_WORKFLOW.md](docs/GIT_WORKFLOW.md): ramas por ticket, Pull Requests hacia `main` y revisión por al menos otro integrante del equipo.
