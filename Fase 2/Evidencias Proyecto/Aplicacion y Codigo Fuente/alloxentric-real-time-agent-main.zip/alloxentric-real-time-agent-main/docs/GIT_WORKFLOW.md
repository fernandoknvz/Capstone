# Estrategia Git y Trabajo Colaborativo

**Ticket:** DART_14-1.4 — Definición de estrategia Git y trabajo colaborativo
**Proyecto:** Alloxentric Real Time Agent
**Equipo:** Fernando Olguea (líder del equipo), Juan Díaz, David Sepúlveda
**Estado:** CONFIRMADO — estrategia aprobada por el equipo completo

## Leyenda de clasificación

| Etiqueta | Significado |
|---|---|
| **CONFIRMADO** | Respaldado explícitamente por el equipo o el cliente. |
| **PROPUESTA** | Sugerida, aún no aprobada. |
| **INFERENCIA** | Deducida de información confirmada; requiere validación. |
| **PENDIENTE** | Falta información; no se debe asumir. |

Todo el contenido de este documento corresponde a decisiones **CONFIRMADO** salvo que se indique lo contrario.

## 1. Propósito

Definir el flujo de trabajo Git que el equipo utilizará para desarrollar el Alloxentric Real Time Agent, de manera que los cambios sean trazables, revisables y seguros para el estado integrado del proyecto (`main`), sin introducir procesos innecesarios para el tamaño actual del equipo.

## 2. Alcance

Este documento aplica a todo el trabajo realizado sobre este repositorio de desarrollo del producto (independiente del repositorio académico de evidencias Capstone), para los tres integrantes del equipo: Fernando Olguea, Juan Díaz y David Sepúlveda. Cubre ramas, commits, Pull Requests, revisión por pares, sincronización y manejo de secretos. Cubre además el uso de la integración continua (CI) en el flujo de PR (sección 16). No cubre el despliegue continuo (CD), que sigue **PENDIENTE** y se documentará por separado cuando esté definido.

## 3. Estrategia adoptada

Se adopta un **flujo liviano basado en ramas de trabajo + Pull Requests** (trunk-based, simplificado):

- `main` representa el estado integrado del proyecto.
- El desarrollo normal no se realiza directamente sobre `main`.
- Cada trabajo se realiza en una rama asociada a un ticket o tarea identificable.
- Los cambios se integran a `main` exclusivamente mediante Pull Request.

Explícitamente **no se utiliza GitFlow completo** ni se crean ramas `develop`, `release` o `hotfix` por defecto. Esta decisión responde al tamaño del equipo y a la fase actual del proyecto (configuración inicial del repositorio); podrá revisarse más adelante si el proyecto lo justifica.

## 4. Ciclo de trabajo

1. Sincronizar el repositorio local con `main` antes de iniciar cualquier trabajo nuevo (ver sección 11).
2. Identificar el ticket CoreStream asociado a la tarea.
3. Crear una rama desde `main` siguiendo la convención de nombres (sección 5).
4. Realizar cambios en commits pequeños y descriptivos (sección 6).
5. Sincronizar nuevamente con `main` y resolver conflictos localmente si corresponde (sección 10).
6. Ejecutar las pruebas aplicables, cuando existan, antes de abrir o actualizar el Pull Request (sección 13 de las decisiones del equipo). Al abrir el PR, la integración continua se ejecuta automáticamente (sección 16).
7. Abrir un Pull Request hacia `main` (sección 7).
8. Obtener revisión de al menos otro integrante del equipo (sección 8).
9. Integrar el Pull Request a `main` una vez aprobado y sin conflictos pendientes.

## 5. Convenciones de ramas

Formato: `<tipo>/DART-14-X.X-descripcion`

| Tipo | Uso |
|---|---|
| `feature/DART-14-X.X-descripcion` | Nueva funcionalidad |
| `fix/DART-14-X.X-descripcion` | Corrección de errores |
| `docs/DART-14-X.X-descripcion` | Documentación |
| `chore/DART-14-X.X-descripcion` | Tareas de mantenimiento, configuración, etc. |

Ejemplo aplicado en este mismo ticket: `docs/DART-14-1.4-git-workflow`.

## 6. Convenciones de commits

Los commits deben ser pequeños, descriptivos y preferentemente seguir **Conventional Commits**:

- `feat:` — nueva funcionalidad
- `fix:` — corrección de errores
- `docs:` — cambios de documentación
- `test:` — pruebas
- `refactor:` — cambios de código sin alterar comportamiento
- `chore:` — mantenimiento, configuración, dependencias

Cuando corresponda, el mensaje de commit debe permitir relacionar el cambio con su ticket CoreStream (por ejemplo, mencionando el identificador del ticket en el cuerpo del mensaje).

## 7. Proceso de Pull Request

- Todo cambio se integra a `main` mediante Pull Request, sin excepción.
- El PR debe describir el cambio realizado y, cuando corresponda, relacionarlo con su ticket CoreStream.
- Los conflictos deben resolverse antes de integrar el PR a `main` (ver sección 10).
- Las pruebas aplicables deben ejecutarse antes del merge, cuando estas existan.
- Los checks de CI (`python-tests` y `web-quality`) deben estar en verde antes del merge; no se fusiona con checks fallidos (sección 16).
- El merge se realiza solo después de obtener la revisión requerida (sección 8).

## 8. Revisión por pares

- Como regla general, cada PR debe ser revisado por al menos otro integrante del equipo antes del merge.
- El autor del PR no debe utilizar su propia aprobación como único mecanismo de revisión.
- Dado que el equipo está compuesto por tres integrantes (Fernando Olguea, Juan Díaz, David Sepúlveda), la revisión recae en cualquiera de los otros dos integrantes distintos del autor.

## 9. Relación con CoreStream

- CoreStream se utiliza para épicas, tickets y evidencias del proyecto.
- Cuando corresponda, el commit, la rama o el PR deben permitir relacionar el cambio con su ticket CoreStream, usando el identificador de referencia (formato visto: `DART_14-1.3`, `DART_14-1.4`).
- La cadena de trazabilidad esperada es: **requerimiento → implementación → prueba → evidencia**, según lo definido en `CLAUDE.md`.

## 10. Resolución de conflictos

- Los conflictos deben resolverse antes de integrar cambios a `main`.
- La resolución se realiza localmente en la rama de trabajo, sincronizando primero con el estado actual de `main` y resolviendo los conflictos resultantes antes de continuar con el Pull Request.

## 11. Sincronización con main

- Antes de iniciar nuevo trabajo, cada integrante debe sincronizar su repositorio local con `main`.
- Esto incluye traer los cambios remotos más recientes antes de crear una nueva rama de trabajo, para evitar partir desde una base desactualizada.

## 12. Tratamiento de secretos

- No se deben versionar secretos, credenciales, tokens ni valores sensibles en ningún commit, rama o Pull Request.
- Esto incluye archivos `.env` con valores reales, claves de API y cualquier credencial de proveedores (STT, LLM, TTS, LiveKit u otros) que se definan a futuro.
- La estrategia concreta de gestión de secretos y configuración por entorno está **PENDIENTE** (ver `CLAUDE.md`, sección 6) y se documentará por separado cuando se defina.

## 13. Limitación actual de Rulesets

**CONFIRMADO:** GitHub muestra actualmente que los Rulesets no serán enforced sobre este repositorio privado bajo la configuración/plan actual. Por lo tanto, la protección de `main` **no se aplica mediante un mecanismo automático de GitHub** en este momento.

En consecuencia, la protección de `main` se aplica inicialmente como:

- Un procedimiento acordado y seguido por todo el equipo (no desarrollar directamente sobre `main`, no hacer merge sin PR).
- La revisión de Pull Requests como control humano de facto.

Esta es una limitación de la configuración/plan actual, no una decisión de diseño. Si en el futuro el plan de GitHub permite habilitar Rulesets u otra protección automática de rama, se evaluará su activación y este documento se actualizará en consecuencia.

## 14. Responsabilidades del equipo

| Integrante | Rol |
|---|---|
| Fernando Olguea | Líder del equipo |
| Juan Díaz | Integrante del equipo de desarrollo |
| David Sepúlveda | Integrante del equipo de desarrollo |

Responsabilidades comunes a todo el equipo:

- Sincronizar el repositorio local con `main` antes de iniciar trabajo nuevo.
- Trabajar exclusivamente en ramas asociadas a un ticket identificable.
- Escribir commits pequeños, descriptivos y, preferentemente, alineados con Conventional Commits.
- Revisar los Pull Requests de los demás integrantes cuando se les solicite, sin aprobar su propio trabajo.
- No versionar secretos ni valores sensibles.
- Resolver conflictos antes de integrar cambios a `main`.
- Ejecutar las pruebas aplicables antes del merge, cuando existan.

## 15. Mantenimiento de este documento

Este documento refleja el estado de la estrategia Git acordada a la fecha del ticket DART_14-1.4 y fue ampliado posteriormente mediante DART-14-5.6 para incorporar la integración continua (sección 16). Cambios futuros a esta estrategia deben tramitarse mediante rama y Pull Request, siguiendo el mismo proceso aquí descrito, y clasificarse según la leyenda de la sección "Leyenda de clasificación".

## 16. Integración continua (CI)

Ticket: DART-14-5.6. Informe de evidencias: [docs/validation/DART-14-5.6-CI-github-actions.md](validation/DART-14-5.6-CI-github-actions.md).

| Aspecto | Estado |
|---|---|
| Integración continua (CI) con GitHub Actions | **CONFIRMADO — IMPLEMENTADA** (`.github/workflows/ci.yml`, PR #19) |
| Checks automatizados `python-tests` y `web-quality` | **CONFIRMADO — DISPONIBLES** (PR hacia `main`, push a `main` y ejecución manual) |
| Checks obligatorios para el merge (mecanismo automático) | **PENDIENTE DE CONFIRMACIÓN** (ver sección 13: los Rulesets no se aplican en la configuración/plan actual y no fue posible consultar la protección de rama) |
| Despliegue continuo (CD) | **PENDIENTE** |

Procedimiento para cada Pull Request:

1. **Ejecución automática:** al abrir o actualizar un PR hacia `main`, GitHub Actions ejecuta el workflow `CI`.
2. **Verificación de resultados:** antes de dar la aprobación, el autor y el revisor comprueban que `python-tests` y `web-quality` terminaron en éxito para el último commit del PR.
3. **Revisión independiente:** el PR debe ser revisado por otro integrante distinto del autor (sección 8). Un CI en verde no reemplaza la revisión.
4. **Prohibición de fusionar con checks fallidos:** no se fusiona un PR con algún check en fallo o sin ejecutar. Como ningún mecanismo automático lo impide (sección 13), es una regla de procedimiento que sigue todo el equipo.
5. **Registro de evidencias:** se registran en el PR o en `docs/validation/` el número del PR, el commit, el identificador de cada ejecución de Actions y su resultado, y quién realizó la revisión.

El CI no usa secretos del proyecto, no despliega, no llama a proveedores de IA ni abre sesiones de LiveKit; no sustituye las validaciones E2E manuales.
