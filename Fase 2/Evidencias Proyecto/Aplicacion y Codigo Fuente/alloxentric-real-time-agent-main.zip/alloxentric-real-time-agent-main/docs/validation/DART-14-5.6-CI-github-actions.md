# Validación DART-14-5.6 — Integración continua con GitHub Actions

**Ticket:** DART-14-5.6 — Implementación y validación de integración continua (CI) con GitHub Actions.
**Proyecto:** Alloxentric Real Time Agent
**Rama documental:** `docs/DART-14-5.6-ci-documentation`
**Estado del documento:** borrador para revisión del equipo. Sujeto a revisión independiente (ver sección 11).

## Leyenda de clasificación

| Etiqueta | Significado |
|---|---|
| **CONFIRMADO** | Verificado directamente en el repositorio, en GitHub (PR, ejecuciones) o respaldado por el equipo. |
| **PROPUESTA** | Sugerida, aún no aprobada. |
| **INFERENCIA** | Deducida de información confirmada; requiere validación. |
| **PENDIENTE** | Falta información o acción; no se asume. |

## 1. Contexto

- El flujo Git (`docs/GIT_WORKFLOW.md`) exigía ejecutar las pruebas aplicables antes del merge, pero no existía automatización: no había carpeta `.github` en `d80c419`. **CONFIRMADO**
- El ticket DART-14-5.6 está confirmado en CoreStream. **CONFIRMADO**

## 2. Objetivo

Ejecutar automáticamente las verificaciones técnicas del proyecto (pruebas Python y calidad de la Web Demo) en cada Pull Request hacia `main` y en cada push a `main`. **CONFIRMADO**

## 3. Alcance

**Incluido:** CI con GitHub Actions: pruebas Python, pruebas y análisis de la Web Demo, build y verificación de la CSP generada. **CONFIRMADO**

**Fuera de alcance:** despliegue continuo (CD), secretos del proyecto, llamadas a proveedores de IA, sesiones LiveKit, pruebas E2E reales. **CONFIRMADO**

## 4. Implementación

- Archivo único incorporado: `.github/workflows/ci.yml` (91 líneas). **CONFIRMADO**
- Nombre del workflow: `CI`. Disparadores: `pull_request` hacia `main`, `push` a `main` y `workflow_dispatch`. **CONFIRMADO**
- Concurrencia por workflow y referencia; `cancel-in-progress` solo para eventos `pull_request`, de modo que no se cancelan ejecuciones anteriores de `main`. **CONFIRMADO**
- `timeout-minutes: 15` por job. **CONFIRMADO**

**Job `python-tests`** (`ubuntu-24.04`): checkout, `astral-sh/setup-uv` con uv 0.12.23 y Python 3.12, `uv sync --frozen`, `uv run --frozen pytest`. **CONFIRMADO**

**Job `web-quality`** (`ubuntu-24.04`, directorio `web-demo`): checkout, `pnpm/action-setup` (9.15.9), `actions/setup-node` (24.15.0), `pnpm install --frozen-lockfile`, `pnpm test` (Vitest), `pnpm lint` (ESLint), `pnpm typecheck` (TypeScript), `pnpm build` (Next.js + generación de `_headers`) y verificación de `out/_headers` (archivo no vacío, un único `Content-Security-Policy`, sin `'unsafe-inline'` ni `'unsafe-eval'`, `script-src 'self' 'sha256-…`). **CONFIRMADO**

## 5. Versiones

| Componente | Versión | Fuente |
|---|---|---|
| Runner | `ubuntu-24.04` | workflow |
| Python | 3.12 | workflow; coincide con `.python-version` |
| uv (ejecutable) | 0.12.23 | workflow |
| `uv_build` (backend de build) | `>=0.12.23,<0.13.0` | `pyproject.toml`, sin cambios |
| Node.js | 24.15.0 | workflow; coincide con `netlify.toml` |
| pnpm | 9.15.9 | workflow; coincide con `packageManager` |
| `actions/checkout` | v7.0.1 — `3d3c42e5aac5ba805825da76410c181273ba90b1` | SHA resuelto desde el tag oficial |
| `astral-sh/setup-uv` | v10.3.3 — `68559e99cc807c1eb7e9238fd43a15bba460eec2` | ídem |
| `pnpm/action-setup` | v6.1.1 — `73e46992e05b19abd31f2f3c20e0e7370d762115` | ídem |
| `actions/setup-node` | v7.1.0 — `949feb2413d6458794dcd2491c4babbbce0c15c1` | ídem |

Distinción: la versión del **ejecutable** uv (0.12.23) se fija en el workflow; la restricción de `uv_build` es una dependencia del backend de build declarada en `pyproject.toml`. La versión 0.12.23 del ejecutable cumple ese rango. **CONFIRMADO** (existencia de la versión en PyPI y en GitHub); la compatibilidad se evidenció en las ejecuciones exitosas (sección 7).

## 6. Seguridad

- `permissions: contents: read`. **CONFIRMADO**
- `persist-credentials: false` en ambos checkout. **CONFIRMADO**
- Acciones externas fijadas por SHA. **CONFIRMADO**
- Sin referencias a `secrets.*`, despliegues ni claves en el workflow. **CONFIRMADO**
- No se modificaron código funcional, dependencias, lockfiles ni variables de entorno. **CONFIRMADO** (el PR #19 contiene únicamente el workflow).

## 7. Pull Request, commits y ejecuciones

| Elemento | Valor |
|---|---|
| Pull Request | #19 — `ci(DART-14-5.6): implementar integración continua con GitHub Actions` |
| Rama de trabajo | `chore/DART-14-5.6-github-actions-ci` |
| Commit base | `d80c41989e92df5d4b50a6412afda0242421ab78` |
| Commit de implementación | `6dd42f445285053fc46cad376794a98ee4ff10a8` |
| Merge en `main` | `75689bc2f9cb60bd2c7eb5e8e157ed88570d8f1b` |
| Fecha del merge (UTC) | 2026-11-08 01:17:22 UTC |
| Fecha del merge (Chile continental) | 2026-11-07 22:17:22 UTC-3 |
| Archivos del PR | `.github/workflows/ci.yml` |

| Ejecución | Evento | Commit | `python-tests` | `web-quality` | Enlace |
|---|---|---|---|---|---|
| `42433340255` | `pull_request` | `6dd42f4…` | éxito | éxito | https://github.com/fernandoknvz/alloxentric-real-time-agent/actions/runs/42433340255 |
| `42433603292` | `push` (`main`) | `75689bc…` | éxito | éxito | https://github.com/fernandoknvz/alloxentric-real-time-agent/actions/runs/42433603292 |

**CONFIRMADO** (consulta realizada posteriormente al merge; fecha y hora exactas de consulta no registradas). Todas las marcas temporales de GitHub citadas en este documento están expresadas en UTC (sufijo `Z`) y se conservan tal como las entrega GitHub. Según las marcas `createdAt`/`updatedAt` de GitHub, la ejecución del PR transcurrió entre 01:13:51Z y 01:15:12Z y la de `main` entre 01:17:24Z y 01:18:33Z; son marcas del run completo, no una medición de rendimiento por job.

En el PR se observan además checks con resultado `NEUTRAL` cuyos nombres son de Netlify (reglas de headers, páginas cambiadas y reglas de redirects) y un comentario del bot de Netlify. **CONFIRMADO** (su existencia y su resultado). La interpretación de que corresponden a la vista previa de Netlify y no forman parte de este workflow es una **INFERENCIA**, deducida de sus nombres y del comentario del bot; no fue verificada. Los resultados de `python-tests` y `web-quality` no se ven afectados.

## 8. Resultados

- Ambos jobs terminaron en éxito en la ejecución del PR y en la posterior al merge. **CONFIRMADO**
- No se revisaron los registros paso a paso de cada job; solo el estado de los jobs y de sus pasos. **CONFIRMADO** (limitación).

## 9. Validaciones previas a la publicación

- Sintaxis YAML verificada con `js-yaml`; estructura, disparadores, permisos y versiones revisados. **CONFIRMADO**
- Existencia de Node 24.15.0, pnpm 9.15.9 y uv 0.12.23 verificada en sus fuentes oficiales. **CONFIRMADO**
- Pruebas Python, dos evidencias distintas:
  1. **Inspección estática del código de pruebas** (previa a la publicación): no se encontró dependencia de servicios externos ni de credenciales (configuración por diccionario o `monkeypatch`, ADC simulado, `socket` bloqueado en varias pruebas). **CONFIRMADO** (lectura de código; no es una ejecución).
  2. **Ejecución automatizada de `pytest` en GitHub Actions** (job `python-tests`): los resultados se registran en la sección 7. **CONFIRMADO**

  Esto no implica cobertura adicional ni pruebas E2E.
- `git diff --check` sin observaciones. **CONFIRMADO**

## 10. Limitaciones y riesgos

| Tema | Estado |
|---|---|
| Checks obligatorios para el merge | **PENDIENTE DE CONFIRMACIÓN.** No se pudo consultar la protección de `main` (la API de GitHub responde 403 por el plan del repositorio, coherente con `docs/GIT_WORKFLOW.md`, sección 13). |
| Despliegue continuo (CD) | **PENDIENTE** |
| Cobertura | Solo pruebas unitarias y de calidad estática; sin E2E reales ni integración con proveedores. |
| Mantenimiento de acciones | Los SHA fijados deben actualizarse manualmente. |
| Versión de uv | Subir uv requiere revisar el rango de `uv_build`. |
| Entorno de pruebas Python | Las pruebas no aíslan por completo variables de entorno heredadas; en un runner limpio no afecta. **INFERENCIA** |
| Duraciones | No se dispone de una línea base de tiempos; no se afirman cifras de rendimiento. |

## 11. Incidencia de revisión

El PR #19 fue fusionado sin una aprobación independiente registrada en GitHub (`reviews` vacío y sin decisión de revisión; el autor y quien fusionó es el mismo usuario). `docs/GIT_WORKFLOW.md`, sección 8, exige revisión de al menos otro integrante.

| Control | Estado |
|---|---|
| Revisión previa al merge | **NO CUMPLIDA** |
| Revisión retrospectiva por otro integrante | **PENDIENTE** (si se realiza, deberá registrarse con su fecha real, posterior al merge, sin presentarse como previa) |
| Acción preventiva | Exigir revisión independiente y CI en verde en todos los PR futuros (`docs/GIT_WORKFLOW.md`, sección 16) |

Los registros históricos del PR #19 no se modifican.

## 12. Trazabilidad CoreStream

Requerimiento (DART-14-5.6) → implementación (workflow, PR #19, commit `6dd42f4…`) → prueba (ejecuciones `42433340255` y `42433603292`) → evidencia (este documento). Los identificadores de evidencia en CoreStream: **PENDIENTE**.

## 13. Evidencias académicas Capstone

Evidencias verificables disponibles: PR #19, commit y merge indicados arriba, enlaces a las dos ejecuciones y este informe. Capturas de pantalla de las ejecuciones: **PENDIENTE**. Relación con las competencias del Capstone Duoc UC: **PENDIENTE** (falta la lista oficial de competencias de la asignatura; no se asume).

## 14. Documentación actualizada

`docs/GIT_WORKFLOW.md` (secciones 2, 4, 7 y nueva sección 16) y `README.md` (sección "Integración continua"), mediante rama `docs/DART-14-5.6-ci-documentation` pendiente de PR y revisión.
