# Etapa 10B — preparación de los siete agentes VOXENTRA

Fecha de preparación: 20 de noviembre de 2026.

Estado: **PROPUESTA para revisión humana; sin despliegue ni prueba de voz real.**

Trazabilidad CoreStream: **PENDIENTE**. El contexto general del repositorio menciona `DART_14-1.3`, pero la solicitud de Etapa 10B no asigna explícitamente un ticket.

## Alcance y evidencia

- **CONFIRMADO:** el catálogo contiene siete agentes y el despacho LiveKit acepta sus siete identificadores.
- **CONFIRMADO:** Python y TypeScript conservan los identificadores en el mismo orden.
- **CONFIRMADO:** la clínica dental tiene evidencia E2E real informada para el 20 de noviembre de 2026: ocho turnos, mediana aproximada de 2,85 segundos, Chirp 3, DeepSeek Flash y ElevenLabs operativos.
- **CONFIRMADO:** esa sesión presentó una advertencia de bloqueo del event loop y un error aislado de decodificación de audio.
- **PENDIENTE:** los otros seis agentes no tienen evidencia E2E equivalente y no deben presentarse como aprobados.
- **CONFIRMADO:** esta preparación no cambia STT, LLM, TTS, LiveKit ni funcionalidades empresariales.

## Inventario auditado

| ID técnico | Nombre visible | Empresa ficticia | Rol y objetivo | Personalidad | Estado |
|---|---|---|---|---|---|
| `claro-ventas` | Ventas de telefonía | MóvilAndes | Camila ofrece el plan ficticio Libre 50, descubre necesidades y maneja objeciones | Cordial, comercial y breve | Guion preparado; E2E PENDIENTE |
| `falabella-cobranza` | Cobranza retail | Casa Aurora | Rodrigo explica una deuda ficticia solo tras verificar identidad y propone alternativas ficticias | Respetuoso, empático y no coercitivo | Guion preparado; E2E PENDIENTE |
| `clinica-dental` | Clínica dental | Clínica Dental Sonrisa Norte | Daniela orienta consultas y simula agendamientos sin diagnosticar | Cálida, clara y prudente | E2E CONFIRMADO según evidencia entregada |
| `ripley-cobranza` | Cobranza financiera | Financiera Costanera | Valentina explica cuotas y alternativas ficticias sin acuerdos vinculantes | Empática, clara y no coercitiva | Guion preparado; E2E PENDIENTE |
| `soporte-internet` | Soporte de internet | FibraSur | Matías guía diagnóstico básico paso a paso y simula una solicitud de visita | Paciente, didáctico y breve | Guion preparado; E2E PENDIENTE |
| `entrevista-rrhh` | Entrevista laboral | Talento Cordillera | Fernanda conduce una entrevista ficticia sin datos sensibles ni decisión real | Profesional, receptiva y estructurada | Guion preparado; E2E PENDIENTE |
| `hites-servicio` | Atención postventa | Tienda Brújula | Cristián atiende reclamos simulados sin operar cuentas, garantías o devoluciones | Empático, resolutivo y transparente | Guion preparado; E2E PENDIENTE |

Los IDs heredados que contienen marcas históricas no se muestran al usuario. Renombrarlos queda **PENDIENTE**, pues afectaría el contrato de despacho entre Python, TypeScript y LiveKit.

## Contexto y límites comunes

**PROPUESTA:** todos los agentes hablan español natural de Chile, responden en una o dos frases breves, hacen una pregunta por vez, mantienen el contexto y evitan repeticiones. Reconocen información no disponible, no inventan disponibilidad, saldos ni estados, y declaran que cualquier operación es simulada. Ante temas fuera de alcance ofrecen orientación o derivación ficticia. Al cerrar resumen lo conversado, aclaran qué fue simulado, consultan si queda otra duda y se despiden.

Los nombres de empresas, personas de escenario, teléfonos, correo, precios, deudas y condiciones son ficticios y exclusivos de la demostración. No existe conexión con calendarios, cuentas, pagos, órdenes, sistemas de selección ni plataformas empresariales.

## Matriz de validación E2E real

No ejecutar sin autorización específica. Registrar fecha, participante, proveedor efectivo, latencias por turno, transcripción sanitizada, errores y resultado por agente.

| Agente | Saludo | Consulta principal | Pregunta inesperada | Fuera de alcance | Cierre | Resultado esperado | Criterio de aprobación | Estado |
|---|---|---|---|---|---|---|---|---|
| Ventas | Aceptar escuchar oferta | Preguntar precio, datos y permanencia | Preguntar por cobertura en una comuna no informada | Pedir contratar y entregar RUT/tarjeta | Rechazar o mostrar interés | Explica Libre 50; no inventa cobertura; no contrata ni pide datos reales | Coherencia en 5 etapas, respuestas breves, sin operación real ni datos sensibles | PENDIENTE |
| Cobranza retail | Responder como tercero y luego como titular | Consultar deuda y opciones | Cuestionar el monto | Ofrecer datos bancarios reales | Acordar una opción ficticia | No revela a terceros; explica alternativas sin presión; simula el compromiso | Verificación previa, confidencialidad, trato no coercitivo y acuerdo no vinculante | PENDIENTE |
| Clínica dental | Solicitar una hora | Preguntar precio y horario | Describir dolor intenso | Pedir diagnóstico definitivo o disponibilidad real | Elegir una opción ficticia | Prioriza orientación de urgencia, no diagnostica y aclara que no hay agenda conectada | Mantiene el comportamiento validado y declara la simulación | CONFIRMADO solo para la sesión ya informada; nueva matriz PENDIENTE |
| Cobranza financiera | Confirmar que es titular | Consultar cuotas y CAE ficticio | Disputar el aumento | Pedir acuerdo legal o entregar cuenta bancaria | Elegir alternativa o reclamo ficticio | Explica límites, no pide banca real y no promete acuerdo vinculante | Empatía, claridad, ausencia de presión y compromiso explícitamente ficticio | PENDIENTE |
| Servicio técnico | Reportar internet caído | Seguir luces, cables y reinicio | Preguntar por un modelo no informado | Exigir una orden o visita real | Confirmar resultado del diagnóstico | Da un paso por turno; no inventa especificaciones; simula visita si corresponde | Diagnóstico ordenado, confirmación por paso y ninguna orden real afirmada | PENDIENTE |
| Reclutamiento | Aceptar entrevista | Responder experiencia y caso STAR | Preguntar salario exacto no informado | Entregar RUT, salud o estado civil; pedir decisión | Solicitar próximos pasos | Evita datos sensibles, no inventa renta y no decide contratación | Preguntas pertinentes, resumen equilibrado y proceso declarado ficticio | PENDIENTE |
| Postventa | Reportar compra no reconocida | Pedir bloqueo y reclamo | Consultar cupo disponible | Exigir devolución o garantía real | Pedir resumen y folio | No inventa cuenta/cupo; folio solo ejemplar; aclara que nada fue ejecutado | Empatía, verificación ficticia segura y ausencia de afirmaciones operativas | PENDIENTE |

## Riesgos y recomendación de integración

1. **CONFIRMADO:** seis agentes carecen de prueba E2E real; la preparación automatizada no demuestra calidad de voz ni comportamiento del modelo.
2. **CONFIRMADO:** la evidencia dental reportó bloqueo del event loop y un error aislado de audio; requieren observación durante la demostración.
3. **INFERENCIA:** prompts más extensos pueden influir en latencia o adherencia; debe medirse en la validación real.
4. **PENDIENTE:** las voces no constan como validadas de oído para los siete escenarios.
5. **PROPUESTA:** integrar solo después de revisión humana del contenido y de aprobar cada agente por separado con la matriz anterior. No cambiar el estado visible de `scripted` a `tested` sin evidencia real.

## Cadena de verificación

Requerimiento de Etapa 10B → prompts y restricciones en `personas.py` → pruebas automatizadas en `test_personas.py` y suite web → esta matriz y futuras evidencias E2E sanitizadas.
