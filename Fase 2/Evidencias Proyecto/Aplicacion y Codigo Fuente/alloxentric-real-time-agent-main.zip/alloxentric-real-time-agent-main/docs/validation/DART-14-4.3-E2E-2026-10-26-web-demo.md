# Validación DART-14-4.3 — Conversación de voz desde la Web Demo (2026-10-26)

**Ticket:** DART-14-4.3 — Validación de conversación en navegador.
**Proyecto:** Alloxentric Real Time Agent
**Fecha de la prueba:** 2026-10-26
**Estado del documento:** borrador para revisión del equipo. **No constituye el cierre formal de la prueba** (ver secciones 10 y 12).

> **Advertencia sobre la evidencia.** Los logs originales de esta sesión **no están archivados** en el repositorio ni en otra ubicación conocida por quien redacta. Todas las cifras proceden del reporte del equipo y no han sido verificadas contra archivos originales. No deben usarse como línea base de rendimiento ni como medición verificada.

## Leyenda de clasificación

| Etiqueta | Significado |
|---|---|
| **[CONFIRMADO]** | Verificable directamente en el repositorio (código, documentación, historial Git, `uv.lock`). Describe lo que el código **declara o hace**, no lo que ocurrió en la sesión del 26-oct. |
| **[CONFIRMADO EN DEPENDENCIA]** | Comportamiento verificado leyendo el código de una dependencia instalada (por ejemplo livekit-agents 1.8.4). Describe cómo se comporta el SDK en general; **no es evidencia directa de lo ocurrido en la sesión del 26-oct**. |
| **[REPORTADO POR EL EQUIPO]** | Informado por el equipo sobre la sesión; sin archivo de respaldo en el repositorio. |
| **[INFERENCIA]** | Deducida de información disponible; requiere validación. |
| **[PROPUESTA]** | Sugerida, aún no aprobada. |
| **[PENDIENTE]** | Falta información; no se asume. |

## 1. Identificación del ticket

- Ticket: DART-14-4.3 — Validación funcional de conversación en navegador. **[REPORTADO POR EL EQUIPO]**
- Relación con DART-14-4.4: **[REPORTADO POR EL EQUIPO]** DART-14-4.4 corresponde a la consolidación posterior de documentación y evidencias de demostración. Esta distribución entre tickets es una decisión de organización del equipo, no un requisito empresarial confirmado. Este documento **no** pretende ser la documentación completa de rendimiento ni de las evidencias de demostración.
- Rama documental: `docs/DART-14-4.3-web-demo-e2e-validation`.
- Commit base del repositorio al preparar este documento: `f00d4e8`. **[CONFIRMADO]**
- Tickets relacionados presentes en el historial Git: DART-14-2.4 (pipeline), DART-14-2.5 (grabación desactivada para validación), DART-14-3.1 (métricas de latencia), DART-14-3.4 (ADC en el setup del runner), DART-14-4.1 (Web Demo) y DART-14-4.2 (incidente de empaquetado en Netlify). **[CONFIRMADO]**

## 2. Objetivo de la validación

Validar que una persona puede mantener una conversación de voz con el agente desde el navegador, usando la Web Demo desplegada en Netlify, LiveKit Cloud y un worker Python ejecutado localmente. Es una muestra de validación funcional, no una medición estadística de rendimiento. **[PROPUESTA]** (el objetivo se redacta a partir del contexto reportado; no hay un criterio de aceptación definido, ver sección 12).

## 3. Entorno de pruebas

| Elemento | Detalle | Clasificación |
|---|---|---|
| Frontend | Web Demo estática desplegada en Netlify (`web-demo/`) | [REPORTADO POR EL EQUIPO] |
| Transporte | LiveKit Cloud | [REPORTADO POR EL EQUIPO] |
| Worker | Python, ejecutado localmente | [REPORTADO POR EL EQUIPO] |
| LiveKit Agents | 1.8.4 | `pyproject.toml` declara un **rango** de versiones (`livekit-agents>=1.8,<2`) y `uv.lock` resuelve la 1.8.4 [CONFIRMADO]. La versión usada durante la sesión es [REPORTADO POR EL EQUIPO] y no está acreditada mediante un log archivado |
| STT | Google Chirp 3 (`chirp_3`) | [CONFIRMADO] como configuración del código (`stt.py`); uso en la sesión [INFERENCIA] |
| LLM | Gemini (por defecto, `LLM_PROVIDER`) o DeepSeek | [CONFIRMADO] en código. Proveedor usado en la sesión: [PENDIENTE] |
| TTS | ElevenLabs (modelo por defecto `eleven_flash_v2_5`, voz de prueba) | [CONFIRMADO] en código; configuración efectiva en la sesión [PENDIENTE] |
| Commit del worker | — | [PENDIENTE] |
| Modo de ejecución y nivel de log del worker | — | [PENDIENTE] |
| Sistema operativo y red del equipo de prueba | — | [PENDIENTE] |

## 4. Precondiciones

- Variables de entorno de la Web Demo y de LiveKit registradas en Netlify y en el entorno local del worker, sin incluir sus valores en este documento. **[REPORTADO POR EL EQUIPO]**
- `DEMO_ENABLED` habilitado para la ventana de prueba. **[INFERENCIA]** (necesario para obtener sesión según `web-demo/netlify/functions/session.mts`; la fecha y hora de la habilitación no están registradas: [PENDIENTE]).
- Worker iniciado antes de abrir la demo, según el flujo de uso de `web-demo/README.md`. **[CONFIRMADO]** como procedimiento documentado; que se siguió en esta sesión es [REPORTADO POR EL EQUIPO].
- Autorización explícita para consumir servicios externos. **[PENDIENTE]** (no hay registro en el repositorio).

## 5. Procedimiento ejecutado

Descripción general, según lo reportado. No hay registro paso a paso. **[REPORTADO POR EL EQUIPO]**

1. Se abrió la Web Demo y se ingresó el código de acceso (no se documenta su valor).
2. La autenticación fue correcta.
3. El navegador se conectó a LiveKit Cloud y el worker local recibió el trabajo.
4. Se mantuvo una conversación de voz de varios turnos.
5. La sesión terminó por desconexión del participante (`participant_disconnected`).
6. Posteriormente `DEMO_ENABLED` fue devuelto a `false`, según el responsable. Esto no fue verificado por quien redacta este documento.

El procedimiento previsto está en `web-demo/README.md`, sección "Flujo de uso". **[CONFIRMADO]**

## 6. Resultados observados

Todos **[REPORTADO POR EL EQUIPO]**:

- Autenticación mediante código de acceso correcta.
- Conexión del navegador a LiveKit Cloud.
- Conversación de voz funcional con cuatro turnos contabilizados.
- Finalización de la sesión por desconexión del participante.
- Errores transitorios de ElevenLabs durante el primer turno (ver sección 8).

El equipo compartió capturas durante la validación **[REPORTADO POR EL EQUIPO]**, pero no hay capturas archivadas en el repositorio ni logs originales que acrediten la audibilidad o coherencia de cada turno. Este documento no afirma que las capturas demuestren aspectos que no puedan verificarse con ellas. **[PENDIENTE]**

## 7. Métricas disponibles

Fuente: reporte del equipo. **No verificadas contra logs originales.** Una sola sesión; no es un benchmark.

| Turno | `e2e_latency_s` | Clasificación |
|---|---|---|
| 1 | No disponible (causa no determinada) | [REPORTADO POR EL EQUIPO]; causa [PENDIENTE] |
| 2 | 5,3589 | [REPORTADO POR EL EQUIPO] |
| 3 | 5,4732 | [REPORTADO POR EL EQUIPO] |
| 4 | 4,5016 | [REPORTADO POR EL EQUIPO] |

- Promedio de los tres turnos con dato: 5,11 s. **[CONFIRMADO]** como cálculo aritmético sobre las cifras reportadas (15,3337 / 3 = 5,1112).
- Inicialización del job runner: 11,56 s. **[REPORTADO POR EL EQUIPO]**. No se documenta de qué registro procede esta cifra. Es una magnitud distinta de `startup_s`: según el código, `startup_s` se mide desde justo antes de `session.start` y no incluye la inicialización del proceso del runner (`metrics.py`, `SessionMetrics.on_agent_state_changed` y `attach_metrics`). **[CONFIRMADO]** como definición en código; no se dispone del valor de `startup_s` de la sesión.

**Métricas sin dato [PENDIENTE]:** `startup_s`, `end_of_turn_delay_s`, `transcription_delay_s`, `llm_node_ttft_s`, `tts_node_ttfb_s` y `playback_latency_s`. No se asume ningún valor.

**Cómo interpretar `e2e_latency_s` [CONFIRMADO EN DEPENDENCIA]:** se calcula como el instante en que el agente empieza a hablar menos el instante en que el usuario terminó de hablar según el VAD. Incluye cualquier reintento de TTS y no equivale necesariamente al tiempo percibido por la persona usuaria. Las métricas por etapa pueden solaparse y no deben sumarse (ver `README.md`, "Métricas de latencia").

**Inicialización [INFERENCIA]:** `agent.py` resuelve las ADC de Google de forma síncrona en `setup_process` (`stt.resolve_google_adc`), y un comentario del código indica que esa resolución superó 10 s en una medición previa (DART-14-3.4). Es una explicación posible de los 11,56 s, **no confirmada** sin el log.

## 8. Errores y advertencias

**Errores de ElevenLabs.** **[REPORTADO POR EL EQUIPO]**

- Cuatro eventos `tts_error`, durante el primer turno.
- Tipo `APIConnectionError` asociado a `ClientConnectorDNSError` (`getaddrinfo failed`) hacia `api.elevenlabs.io:443`.
- Los turnos posteriores registraron métricas de generación de audio.
- El indicador `recoverable` de cada evento: **[PENDIENTE]**.

**Interpretación.**

- **[CONFIRMADO]** El proyecto no configura reintentos ni timeouts de TTS en su código.
- **[CONFIRMADO EN DEPENDENCIA]** En livekit-agents 1.8.4 rigen entonces los valores por defecto (`max_retry=3`, `retry_interval=2.0`, `timeout=10.0`). Cada intento fallido emite un `tts_error`: los reintentos con `recoverable=True` y el último con `recoverable=False`. La sesión solo se cierra si los errores no recuperables acumulados superan 3. Es el comportamiento general del SDK, no prueba de lo ocurrido en la sesión.
- **[INFERENCIA]** Los cuatro eventos corresponden a una única síntesis (un intento inicial y tres reintentos). No verificado contra el log.
- **[INFERENCIA]** El fallo de DNS fue transitorio. No se atribuye a credenciales. La recuperación en turnos posteriores es coherente con esto.
- **[CONFIRMADO]** El log de errores del proyecto registra solo la clase de la excepción (`APIConnectionError`), por lo que no distingue DNS de otros fallos de conexión. El contador `errors` del resumen de sesión cuenta errores recuperables y no recuperables juntos (`metrics.py`, `SessionMetrics.on_error`).

**Advertencias al apagado.** **[REPORTADO POR EL EQUIPO]**

- `Attempted to drop unknown FFI handle`, `AssertionError`, `Task was destroyed but it is pending` y `Task exception was never retrieved`.
- No se dispone del traceback. Origen: **[PENDIENTE]**. En los módulos del proyecto revisados (`agent.py`, `pipeline.py`, `metrics.py`, `tts.py`, `stt.py`) no se crean tareas propias ni se usa `rtc` directamente, pero eso no demuestra que las advertencias provengan de una dependencia. No hay evidencia verificable de fuga de recursos.

**Cierre de sesión.** `participant_disconnected` **[REPORTADO POR EL EQUIPO]**; en el SDK, la desconexión del participante cierra la sesión por esa razón. **[CONFIRMADO EN DEPENDENCIA]**

## 9. Limitaciones

- Una sola sesión, un solo participante y un solo equipo de prueba.
- Sin logs originales; cifras no verificables.
- El turno 1 carece de `e2e_latency_s`, y no hay desglose por etapa.
- La latencia depende de la detección de fin de habla del VAD y del cliente de reproducción.
- La prueba no cubre usuarios concurrentes, redes distintas ni sesiones largas.
- El código de acceso es compartido y no identifica evaluadores (`web-demo/README.md`). **[CONFIRMADO]**

## 10. Evidencias disponibles y faltantes

**Disponibles:**

- Reporte del equipo (cifras y observaciones de las secciones 6 a 8). **[REPORTADO POR EL EQUIPO]**
- Capturas de pantalla compartidas por el equipo durante la validación **[REPORTADO POR EL EQUIPO]**. No están archivadas en el repositorio y su contenido no se incorpora ni se interpreta en este documento.
- Código de la instrumentación de métricas y sus pruebas automatizadas sin red. **[CONFIRMADO]**

**Faltantes [PENDIENTE]:**

- Log completo del worker (líneas `metrics startup`, `metrics turn`, `metrics session_summary`, errores y apagado), con secretos retirados.
- Fecha y hora de inicio y fin, y duración.
- Valores de todas las métricas por turno y de `startup_s`.
- Indicador `recoverable` y secuencia de los `tts_error`.
- Traceback de las advertencias de apagado.
- Registro de `DEMO_ENABLED` habilitado y devuelto a `false` (confirmación independiente).
- Confirmación documentada de que el audio fue audible y los turnos fueron coherentes.
- Commit y modo de ejecución del worker.

## 11. Riesgos

- Presentar las cifras como mediciones verificadas. Mitigación: etiquetado y advertencia inicial de este documento.
- Pérdida del log si solo existía en la consola. **[INFERENCIA]**
- Las capturas o logs podrían contener identificadores de sala o participante, o secretos; deben revisarse antes de archivarlos.
- Latencia ~5 s sin requerimiento contra el cual evaluarla.
- Sin reintentos/timeouts decididos, un fallo DNS en el primer turno puede dejar ese turno sin audio. **[INFERENCIA]**
- Los registros de error actuales no permiten distinguir la causa del fallo de conexión (sección 8).
- `DEMO_ENABLED=false` impide nuevas sesiones, pero no finaliza una conexión ya establecida (`web-demo/README.md`). **[CONFIRMADO]**

## 12. Criterios de aceptación pendientes

`CLAUDE.md`, sección 6, marca como **PENDIENTE** los requerimientos funcionales y no funcionales detallados (idioma, latencia, casos de uso) y la estrategia de pruebas. Por tanto **no existen criterios de aceptación definidos** para esta prueba y este documento no propone umbrales numéricos.

Falta que el equipo defina, al menos:

- Qué constituye una conversación aceptable (número mínimo de turnos, claridad del audio).
- Si habrá un objetivo de latencia de voz a voz y cómo se mide.
- Comportamiento exigido ante fallos de un proveedor (reintentos, mensajes al usuario).
- Qué evidencia debe archivarse y dónde (el registro de decisiones y la ubicación de evidencias son PENDIENTES).

## 13. Conclusiones

- **[REPORTADO POR EL EQUIPO]** Se realizó una conversación de voz funcional desde la Web Demo, con autenticación, conexión a LiveKit Cloud y worker local, que terminó por desconexión del participante.
- **[REPORTADO POR EL EQUIPO]** Se registraron tres valores de `e2e_latency_s` (promedio 5,11 s) y un runner que tardó 11,56 s en inicializarse, además de errores transitorios de ElevenLabs que no impidieron los turnos posteriores.
- **Sin logs originales**, estas cifras no sirven aún como línea base y la prueba **no puede cerrarse formalmente**.
- Ningún problema queda declarado como resuelto. Las causas de la inicialización lenta, de la ausencia de `e2e_latency_s` en el turno 1 y de las advertencias de apagado no están determinadas.

## 14. Próximas acciones

Todas **[PROPUESTA]**, sujetas a aprobación del equipo:

1. Archivar, si todavía existe, el log completo de la sesión (sin secretos) en la ubicación de evidencias que el equipo defina, y completar la sección 10.
2. Repetir sesiones autorizadas con `--log-level info` y archivar los logs desde el inicio.
3. Definir los criterios de aceptación de la sección 12.
4. Evaluar, en un ticket aparte, registrar en el log de errores el indicador `recoverable` por tipo y la causa de fondo de `APIConnectionError`.
5. Evaluar, en un ticket aparte, medir de forma aislada la resolución de ADC al inicializar el runner.
6. Evaluar si se ajustan reintentos y timeouts de TTS, solo con datos de varias sesiones.
7. Revisión de este documento por al menos otro integrante, según `docs/GIT_WORKFLOW.md`.
