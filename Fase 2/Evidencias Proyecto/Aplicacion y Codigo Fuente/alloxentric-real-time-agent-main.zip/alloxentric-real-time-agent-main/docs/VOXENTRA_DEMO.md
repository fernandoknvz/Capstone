# Demostración académica VOXENTRA (nombre provisional)

Resumen de cambios para un futuro anexo académico. Rama: `feature/voxentra-demo-academica` (desde `origin/main` en `77ff85c`). **Borrador para revisión humana; no aprobado, no desplegado y sin commits.**

El nombre VOXENTRA es provisional: no está aprobado ni se verificó su disponibilidad como marca o dominio. El recorte no construye una plataforma SaaS: reutiliza el frontend y los agentes existentes.

## 1. Funcionalidades existentes (sin cambios)

- Pipeline de voz: STT Google Chirp 3, LLM Gemini o DeepSeek (variable `LLM_PROVIDER`) y TTS ElevenLabs, sobre LiveKit Agents.
- Siete agentes (personas) con guion, saludo y voz propios; el navegador solo envía el identificador.
- Acceso con código temporal, sesión por cookie, token LiveKit con despacho forzado desde el servidor, transcripción en pantalla e historial solo en el navegador.
- No se graba audio y la CSP no permite `unsafe-inline` ni `unsafe-eval`.

## 2. Cambios visuales

- Nombre visible, eslogan («Agentes de voz inteligentes para tu negocio»), título y descripción del navegador, encabezado principal y textos de bienvenida.
- Paleta azul profundo + turquesa (dirección A): `web-demo/app/globals.css`, solo variables y clases, sin estilos en línea. Texto principal en azul oscuro; el turquesa se usa en fondos, bordes y acentos.
- Aviso visible en todas las pantallas: «Demostración con datos ficticios. No realiza operaciones reales ni está integrada con sistemas empresariales».
- Pie de página actualizado (nombre provisional, escenarios ficticios).
- La navegación no se reconstruyó.

## 3. Escenarios ficticios

Se sustituyeron las marcas reales y el nombre de un integrante en la configuración visible y en los guiones:

| Antes | Ahora (visible) | Empresa o persona ficticia |
|---|---|---|
| Ventas Claro | Ventas de telefonía | MóvilAndes, plan «Libre 50» |
| Cobranza Falabella (deuda «a nombre de Juan Díaz») | Cobranza retail | Casa Aurora; cliente ficticio Andrés Molina |
| Cobranza Ripley | Cobranza financiera | Financiera Costanera |
| Atención Hites | Atención postventa | Tienda Brújula, Tarjeta Brújula |
| Clínica dental, Soporte de internet, Entrevista laboral | Sin cambios de empresa (ya eran ficticias) | Sonrisa Norte, FibraSur, retail ficticio |

La finalidad funcional, los montos y los proveedores no cambian. Los identificadores técnicos (`claro-ventas`, `falabella-cobranza`, `ripley-cobranza`, `hites-servicio`) **se conservaron a propósito**: son la clave de despacho entre `personas.py`, `personas.ts` y el token, y no se muestran al usuario. Renombrarlos es un cambio posterior que exige actualizar ambos archivos y los tests.

## 4. Estado de alcance de cada agente

| Agente | Estado visible |
|---|---|
| Clínica dental | Prueba conversacional real documentada (E2E del 31-oct y del 17-nov) |
| Los otros seis | Guion configurado, sin prueba real documentada |

## 5. Funcionalidades simuladas

Todo lo que ocurre dentro de la conversación es simulado: agenda de la clínica (no hay calendario), pagos y repactaciones, folios de reclamo, bloqueo de tarjeta, visita técnica y entrevista. No hay integración con sistemas empresariales, telefonía ni medios de pago.

## 6. Pruebas ejecutadas (sin proveedores externos)

Ver el informe de entrega para las cifras y la fecha. Las pruebas no contactan Google, ElevenLabs, DeepSeek ni LiveKit.

La revisión visual de Etapa 8 quedó en `docs/validation/ETAPA-8-voxentra-frontend-2026-11-19/`: acceso y catálogo en escritorio/móvil, además de los estados inicial y de error de la pantalla de llamada. La llamada se verificó con respuestas HTTP simuladas; no acredita una conexión LiveKit ni una llamada de voz real.

## 7. Limitaciones

- Seis de los siete agentes no tienen E2E real.
- La latencia objetivo de 1 s no se cumple (mediana de 3,26 s en la única sesión DeepSeek documentada).
- Las voces de ElevenLabs no se validaron de oído.
- La interfaz no muestra métricas de latencia en vivo.
- Los estados conectado, escuchando, pensando, hablando y micrófono silenciado se validaron mediante pruebas de componentes; no se abrió una sesión LiveKit durante esta revisión.
- Los nombres técnicos (`alloxentric-*`) siguen presentes en el código, las variables y la documentación del repositorio.
- No se verificó la disponibilidad de la marca VOXENTRA ni la autorización para reutilizar el código y la identidad visual originales.
