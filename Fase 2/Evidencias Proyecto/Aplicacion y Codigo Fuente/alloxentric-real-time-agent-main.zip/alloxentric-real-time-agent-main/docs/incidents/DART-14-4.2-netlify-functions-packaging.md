# Incidente DART-14-4.2 — Netlify Functions con HTTP 502 por empaquetado pnpm en Windows

**Ticket:** DART-14-4.2
**Proyecto:** Alloxentric Real Time Agent — web demo (`web-demo/`)
**Fecha del incidente HTTP 502 y cierre:** 2026-10-23 (el incidente HTTP 500 es anterior al merge del PR #13; su ubicación temporal es **INFERENCIA**, ver sección 1.1)
**Estado del incidente HTTP 502:** resuelto y validado en producción el 2026-10-23 (deploy `6adb6dfe9c5be068761fc330`). Este estado corresponde a esa fecha y **no describe necesariamente el despliegue actual** de producción (ver sección 1.2).
**Commit desplegado:** `c87f93ce040606cc674201c6aef61803ea5bb914`
**Alcance:** despliegue manual con Netlify CLI desde Windows. El flujo de despliegue/CI general sigue **PENDIENTE** (ver `docs/GIT_WORKFLOW.md`, sección 2).

## Leyenda de clasificación

| Etiqueta | Significado |
|---|---|
| **CONFIRMADO** | Respaldado por evidencia verificable por un tercero: repositorio, historial de Git, PR de GitHub o respuestas HTTP públicas. |
| **REPORTADO POR EL EQUIPO** | Observado o consultado por el equipo (logs, API de Netlify con credenciales, UI de Netlify, pruebas locales) y no reverificable con los recursos de esta revisión. |
| **PROPUESTA** | Sugerida, aún no aprobada. |
| **INFERENCIA** | Deducida de información confirmada o reportada; requiere validación. |
| **PENDIENTE** | Falta información; no se debe asumir. |

Esta leyenda amplía la de `CLAUDE.md` con **REPORTADO POR EL EQUIPO** para separar lo verificable de lo informado, a raíz de la revisión independiente del PR #14.

## 1. Resumen

Un despliegue manual del commit `c87f93c` publicó el frontend y cuatro Functions, pero tres rutas respondían HTTP 502 en lugar del 503 `demo_disabled` esperado. Las Functions fallaban al cargar sus módulos porque `jose` y `livekit-server-sdk` no podían resolverse en el runtime de Netlify (**REPORTADO POR EL EQUIPO**: logs de la sección 3). La corrección fue instalar las dependencias con `node-linker=hoisted` en una copia temporal y volver a desplegar; la validación HTTP posterior (sección 11) es **REPORTADO POR EL EQUIPO**.

### 1.1 Dos incidentes distintos: HTTP 500 y HTTP 502

Ambos ocurrieron en las Functions de Netlify del mismo ticket y pueden confundirse. Son incidentes distintos, con causa y corrección distintas.

| | Incidente HTTP 500 | Incidente HTTP 502 (objeto de este documento) |
|---|---|---|
| Síntoma | `GET /api/demo/session` y `POST /api/demo/login` respondían 500 `{"error":"service_unavailable"}` con `DEMO_ENABLED=false`. **REPORTADO POR EL EQUIPO** (descripción del PR #13). | `session`, `login` y `livekit-token` respondían 502. **REPORTADO POR EL EQUIPO** (sección 2). |
| Causa | Netlify invoca las Functions con `(Request, Context)`; los helpers exportados interpretaban `Context` como `NodeJS.ProcessEnv`, por lo que la configuración aparecía incompleta. **REPORTADO POR EL EQUIPO** (descripción del PR #13; no es una validación independiente del incidente). | Fallo al cargar la dependencia `jose` (y `livekit-server-sdk`) por el empaquetado de Netlify Functions (symlinks con destino absoluto de Windows). **REPORTADO POR EL EQUIPO** (secciones 3 y 4). |
| Corrección | **PR #13** (`b10dcf9`, fusionado como `c87f93c`): handlers por defecto `(Request, Context)` con `process.env` explícito. **CONFIRMADO** (repositorio: el PR, los cambios en `web-demo/netlify/functions/*.mts` y las pruebas de regresión en `web-demo/tests/netlify-runtime.test.ts`). | Instalación `node-linker=hoisted` en copia temporal y nuevo despliegue (secciones 7 a 10). **No** es código del repositorio. |
| Fuente | Descripción del PR #13 (relato del equipo) y su diff (verificable). | Secciones 2 a 4 de este documento. |

**El PR #13 no corrige el incidente HTTP 502 y no debe presentarse como su corrección.** Su diff solo toca tres Functions y una prueba; no cambia dependencias, `.npmrc`, `netlify.toml` ni el empaquetado. El `c87f93c` es únicamente el commit que se desplegó cuando apareció el 502. Que el 502 se detectara al validar en Netlify el resultado del PR #13 (cuya descripción dejaba esa validación pendiente tras el merge) es **INFERENCIA** a partir de la cronología; lo que consta es que se desplegó `c87f93c` (**REPORTADO POR EL EQUIPO**) y que la causa documentada del 502 (secciones 3 y 4) no guarda relación con la lógica modificada por el PR #13.

Este documento se introduce mediante el **PR #14** (solo documentación, sin cambios de código).

Cronología (hora de Chile, UTC-3, según historial de Git y metadatos del PR):

1. 2026-10-22 15:34: se fusiona el PR #12 (`4fe998c`). **CONFIRMADO.**
2. 2026-10-22 20:34: commit `b10dcf9` del PR #13 (corrección del HTTP 500). **CONFIRMADO.**
3. 2026-10-22 23:21 (2026-10-23 02:21 UTC): se fusiona el PR #13 (`c87f93c`). **CONFIRMADO.**
4. 2026-10-23: despliegue manual de `c87f93c` con HTTP 502 (deploy `6adb61ddbc7cd8942f42604b`) y posterior despliegue corregido (`6adb6dfe9c5be068761fc330`, 14:24 UTC). **REPORTADO POR EL EQUIPO** (metadatos de Netlify con credenciales).
5. 2026-10-23 11:33: commit `239118d` con este documento (PR #14). **CONFIRMADO.**

Las fechas exactas de los despliegues que respondían HTTP 500 no constan en el repositorio. Que el incidente HTTP 500 fuera anterior al merge del PR #13 es **INFERENCIA** a partir de que ese PR lo corrige; ubicarlo entre el PR #12 y el PR #13 también es **INFERENCIA** (el PR #13 se creó después del PR #12, según el historial de Git).

### 1.2 Vigencia del estado documentado

El estado de producción documentado (secciones 11 y 13) corresponde al **2026-10-23**. No se afirma que describa el despliegue actual. Observación independiente posterior, sin credenciales y con un único `GET`: el 2026-10-24 (~14:34 UTC) `GET /api/demo/session` respondió 503 `{"error":"demo_disabled"}` en producción, **CONFIRMADO** solo para ese instante y esa ruta. No se ejecutaron peticiones `POST` en esta revisión.

## 2. Síntomas (deploy afectado `6adb61ddbc7cd8942f42604b`)

| Petición | Esperado | Observado |
|---|---|---|
| `GET /` | 200 | 200 |
| `GET /api/demo/session` | 503 `demo_disabled` | **502** |
| `POST /api/demo/login` | 503 `demo_disabled` | **502** |
| `POST /api/livekit-token` | 503 `demo_disabled` | **502** |

No se observaron cookies de sesión ni JWT en las respuestas fallidas. **REPORTADO POR EL EQUIPO** (observación durante el diagnóstico). Los síntomas de esta tabla son **REPORTADO POR EL EQUIPO**, salvo el de `GET /api/demo/session`, que cuenta con la verificación independiente descrita a continuación.

El deploy afectado dejó de ser el despliegue activo de producción (lo reemplazó el deploy corregido `6adb6dfe9c5be068761fc330`), pero su URL permanente histórica sigue accesible y permite reproducir el HTTP 502:

- Fecha y hora: 2026-10-24, 14:51 UTC.
- Petición verificada: `GET /api/demo/session` sobre el deploy `6adb61ddbc7cd8942f42604b`.
- Resultado: HTTP 502, con el mensaje `Cannot find package 'jose'`.
- Clasificación: **CONFIRMADO** por evidencia HTTP pública, verificada de forma independiente por David Sepúlveda (verificación reportada por David; no reejecutada en esta revisión).

Esta confirmación se limita a `GET /api/demo/session`. Los 502 de `POST /api/demo/login` y `POST /api/livekit-token` siguen siendo **REPORTADO POR EL EQUIPO**: no se verificaron de forma independiente.

## 3. Logs sanitizados (Netlify Functions)

Extracto de los logs de Netlify Functions consultados por el equipo durante el diagnóstico (no se volvieron a consultar al redactar este documento). **REPORTADO POR EL EQUIPO:**

```
session        ERR_MODULE_NOT_FOUND: Cannot find package 'jose' imported from /var/task/netlify/functions/session.mjs
login          ERR_MODULE_NOT_FOUND: Cannot find package 'jose' imported from /var/task/netlify/functions/login.mjs
livekit-token  ERR_MODULE_NOT_FOUND: Cannot find package 'livekit-server-sdk' imported from /var/task/netlify/functions/livekit-token.mjs
logout         sin evidencia de ejecución en los logs
```

Los logs reportados muestran un error de importación de módulo (`ERR_MODULE_NOT_FOUND`). Se deduce que el error ocurre al inicializar el módulo, antes de que el handler lea `DEMO_ENABLED`, y que por eso cambiar esa variable no podía resolver el problema: **INFERENCIA** a partir de los logs reportados y del orden de ejecución de ES modules.

## 4. Causa raíz

Las afirmaciones 1 a 4 provienen de pruebas locales del equipo (no reejecutadas en la revisión del PR #14): **REPORTADO POR EL EQUIPO**. Mecanismo propuesto, no verificado de forma independiente:

1. En Windows, pnpm instala cada dependencia directa como *junction* hacia `node_modules/.pnpm/<paquete>@<versión>/node_modules/<paquete>`. **REPORTADO POR EL EQUIPO** (comportamiento conocido de pnpm; no revalidado aquí).
2. `@netlify/zip-it-and-ship-it` (bundler `nft`) copia los archivos reales bajo `.pnpm/` y registra `node_modules/jose` y `node_modules/livekit-server-sdk` como **symlinks** (modo Unix `0o120666`) cuyo destino es una **ruta absoluta de Windows** (`C:/Users/.../node_modules/.pnpm/...`). **REPORTADO POR EL EQUIPO** en ZIP generados localmente con el mismo procedimiento (copia del worktree de despliegue y copia de `HEAD`). Los ZIP efectivamente subidos en el deploy afectado no se inspeccionaron, porque Netlify no los expone.
3. En `/var/task` esas rutas no existen, por lo que los symlinks quedan colgantes y Node no resuelve el paquete. La extracción local de esos ZIP reprodujo el mismo `ERR_MODULE_NOT_FOUND` de producción. **REPORTADO POR EL EQUIPO** (reproducción local). Que el contenido de `/var/task` fuera exactamente ese no se inspeccionó; es **INFERENCIA** coherente con los logs de la sección 3.
4. `logout` también depende de `jose` (importa `lib/server/session`), por lo que estaba afectado por el mismo mecanismo. La dependencia es **CONFIRMADO** por el código; el efecto es **REPORTADO POR EL EQUIPO** (reproducción local). En los logs de producción no hay evidencia de su ejecución.
5. Si el build en Netlify CI empaquetaría estos symlinks con destinos relativos válidos y evitaría el defecto, es **INFERENCIA** no probada; la evidencia disponible se detalla en la sección 4.1. **PENDIENTE** de prueba directa.

### 4.1 Evidencia sobre los despliegues anteriores que respondían HTTP 500

Observación relevante: una respuesta HTTP 500 `service_unavailable` (incidente de la sección 1.1, **REPORTADO POR EL EQUIPO**) corresponde a un error devuelto por el código de la aplicación, lo que sugiere que la Function se cargó y que `jose` se resolvía en esos despliegues: **INFERENCIA** (no se inspeccionaron esos despliegues). Esto no encaja sin más con la explicación del 502 (defecto de empaquetado aplicado a toda Function empaquetada en Windows con pnpm por defecto). La explicación de la diferencia **no está establecida**. Se revisó la evidencia accesible sin credenciales:

- **Repositorio e historial:** no hay `.npmrc` versionado, y el diff entre el PR #12 (`4fe998c`) y el PR #13 (`c87f93c`) solo modifica tres Functions y una prueba (sin cambios en dependencias, lockfile ni `netlify.toml`), por lo que el código no explica una diferencia de empaquetado. `web-demo/netlify.toml` (creado en `00239e6`, última modificación en `5fe2f89`) define `command = "pnpm build"`, `publish = "out"` y `functions = "netlify/functions"`. **CONFIRMADO.** El repositorio no registra cómo se construyó ni quién desplegó cada deploy anterior.
- **Integración con Netlify:** el bot de Netlify comenta Deploy Previews en los PR #13 (commit `b10dcf9`) y #14 (commit `239118d`), por lo que el sitio está conectado al repositorio. **CONFIRMADO.** Si los despliegues de producción de los HTTP 500 los generó esa integración o la CLI desde Windows no consta en ningún recurso accesible: **PENDIENTE.**
- **Previews construidos por Netlify:** el 2026-10-24 (~14:34 UTC) un `GET /api/demo/session` a los Deploy Previews de los PR #13 y #14 respondió 503 `{"error":"demo_disabled"}`. La respuesta es **CONFIRMADO** (observación pública, solo `GET`, mientras los previews existan); que por ello esas Functions cargaron `jose` sin el defecto del 502 es **INFERENCIA** (una respuesta de la aplicación supone que el módulo cargó). Que esos builds corran en Linux no figura en el repositorio ni en los comentarios: **INFERENCIA**. Que los previews usen las mismas variables que producción tampoco se verificó.
- **Metadatos de despliegue accesibles sin credenciales:** los logs de deploy y la API requieren autenticación; no se consultaron. No hay evidencia disponible de la plataforma, la ruta de compilación ni la versión de las herramientas de los deploys que respondían HTTP 500.

Conclusión: **no se afirma** que los despliegues anteriores se compilaran en Linux, en Windows ni por ningún otro medio. La hipótesis de que fueron construidos por la integración de Netlify con el repositorio (y por eso no tuvieron el defecto) es **INFERENCIA** compatible con la evidencia de previews, y la hipótesis de despliegue manual desde Windows con otro layout de `node_modules` es igualmente posible. Causa de la diferencia: **PENDIENTE** (requiere los logs de deploy de Netlify de los deploys con HTTP 500 o el testimonio de quien los ejecutó).

## 5. Dependencias afectadas

| Paquete | Versión | Declarada en |
|---|---|---|
| `jose` | 6.0.12 | `dependencies` |
| `livekit-server-sdk` | 2.18.0 | `dependencies` |
| `@bufbuild/protobuf`, `@livekit/protocol` (1.48.0 anidado), `jose@5.x` anidado | según lockfile | transitivas del SDK |

Las versiones y la declaración de `jose` y `livekit-server-sdk` en `dependencies` constan en `web-demo/package.json` y en el lockfile: **CONFIRMADO** (repositorio). Que el defecto esté en el empaquetado y no en la declaración se deduce de la causa de la sección 4: **INFERENCIA** respaldada por lo reportado por el equipo.

## 6. Alternativas descartadas

- **`node_bundler = "esbuild"` y/o `external_node_modules`:** **REPORTADO POR EL EQUIPO** que zip-it-and-ship-it 16.4.1 lo ignora para estas Functions `.mts` y sigue usando `nft` (prueba local; un diagnóstico previo con la CLI mostró el mismo resultado). No corrige el problema. No se repitió esta prueba con 16.5.0, la versión incluida en la CLI 27.14.1.
- **Cambiar `DEMO_ENABLED`:** no aplica; se deduce que el fallo ocurre antes de ejecutar la lógica que lee esa variable (sección 3). **INFERENCIA.**
- **Subir ZIP pre-empaquetados:** `netlify deploy --functions` re-empaqueta desde las fuentes (`hash-fns.js` en CLI 27.14.1), por lo que no publica los ZIP generados aparte. Variante de ZIP precompilados: **PENDIENTE** (podría perder rutas y `rateLimit`, que se leen del código fuente).

## 7. Solución: `node-linker=hoisted`

Con `node-linker=hoisted` pnpm instala los paquetes como directorios reales en `node_modules/` (sin junctions). Los ZIP resultantes no contienen symlinks ni rutas absolutas, y las cuatro Functions cargan sin `node_modules` fuente. **REPORTADO POR EL EQUIPO** (pruebas locales), con validación HTTP posterior reportada en la sección 11.

El `.npmrc` **no está versionado** en el repositorio; se aplica solo en la copia temporal de despliegue. Versionarlo es una **PROPUESTA** (sección 14).

## 8. Procedimiento reproducible (copia temporal)

Requisitos: Windows, Node.js 24.15.0, pnpm 9.15.9 (por ejemplo vía `corepack`), Netlify CLI 27.14.1 autenticada con la cuenta propietaria del proyecto. No copiar `.env` ni secretos. Estos pasos **solo preparan y validan una copia local; no despliegan nada**.

```powershell
# 1. Copia exacta del commit a desplegar (ejecutar dentro de un clon del repositorio).
#    Usar una ruta corta: el límite de 260 caracteres de Windows rompe la extracción de ZIP con rutas largas.
$R = "$env:TEMP\adh"
New-Item -ItemType Directory $R | Out-Null   # si ya existe, elegir otro directorio; no reutilizar node_modules ajenos
git archive --format=zip -o "$R\src.zip" <COMMIT_SHA> web-demo
Expand-Archive "$R\src.zip" -DestinationPath "$R\src"
$W = "$R\src\web-demo"

# 2. Layout hoisted, solo en la copia temporal
Set-Content "$W\.npmrc" "node-linker=hoisted" -Encoding ascii

# 3. Instalar sin modificar el lockfile ni ejecutar scripts
Push-Location $W
pnpm install --frozen-lockfile --ignore-scripts

# 4. Validaciones y build
pnpm test; pnpm lint; pnpm typecheck; pnpm build
pnpm audit --prod
Pop-Location
```

No definir ni sobrescribir `DEMO_ENABLED` en estos comandos ni en el despliegue: rige el valor configurado en Netlify. Este procedimiento no habilita la demo.

## 9. Validaciones previas al despliegue

- La copia no difiere del commit autorizado salvo `.npmrc` (comparar hashes). **REPORTADO POR EL EQUIPO** para el despliegue de referencia.
- `.npmrc` contiene solo `node-linker=hoisted`; `pnpm-lock.yaml` sin cambios tras instalar.
- `node_modules/jose` y `node_modules/livekit-server-sdk` son directorios reales (sin `LinkType`) y con las versiones esperadas.
- Existen `out/index.html` y `out/_headers`; no hay caché de Functions previa (el despliegue usa `--skip-functions-cache`).
- Empaquetado de prueba con el zip-it-and-ship-it de la CLI e inspección de ZIP: 0 symlinks, 0 rutas `.pnpm`, 0 rutas `C:/Users`. Extraer en un directorio **sin** `node_modules` ancestro y comprobar que las 4 Functions importan.
- Prueba con valores sintéticos y `DEMO_ENABLED=false`: session/login/livekit-token → 503 `demo_disabled`; logout → 204 con cookie de expiración.
- `netlify status`: cuenta y Project ID correctos. El `state.json` solo debe contener `siteId`; copiar únicamente ese archivo.
- Variables de Production verificadas manualmente en la UI de Netlify por el líder del equipo antes del despliegue: `DEMO_ENABLED=false` (exactamente), aplicada a Production con ámbito Functions, y presentes `DEMO_ACCESS_SECRET`, `DEMO_SESSION_SIGNING_SECRET` y `DEMO_ALLOWED_ORIGIN`. **REPORTADO POR EL EQUIPO**; no se verificó por API ni se revelaron valores. No consultar secretos por API.

## 10. Procedimiento de despliegue

> **ADVERTENCIA: este comando publica en producción.** Ejecutar solo con autorización explícita del líder del equipo, una única vez y sin reintentos automáticos. Antes de ejecutarlo, confirmar que `DEMO_ENABLED=false` en Production/Functions, que el proyecto vinculado es el esperado (`netlify status`) y que no se usarán `--context production`, `--site` ni `--build`. La CLI re-empaqueta las Functions desde `netlify/functions` y el `node_modules` del directorio de ejecución, por lo que **debe ejecutarse desde la copia hoisted**, nunca desde un clon con el layout pnpm por defecto. El rollback no está cubierto por este procedimiento.

Comando usado en el despliegue correcto (CLI 27.14.1 instalada de forma local; en el caso documentado se invocó su ejecutable local), desde `%TEMP%\adh\src\web-demo`. El archivo `.netlify/state.json` se copió desde el worktree del despliegue anterior y contenía únicamente el `siteId`:

```powershell
netlify deploy --prod --no-build --dir out --functions netlify/functions --skip-functions-cache --message "DART-14-4.2 c87f93c hoisted"
```

Restricciones conocidas de la CLI 27.14.1: `--no-build` no se puede combinar con `--context production`; `--site <UUID>` produjo antes "Project not found", por eso se usa la vinculación local `.netlify/state.json`. **REPORTADO POR EL EQUIPO** (observado durante el incidente).

## 11. Validaciones posteriores

Resultados del **2026-10-23**, **REPORTADO POR EL EQUIPO** (peticiones hechas durante el cierre del incidente; la única reverificada de forma independiente es `GET /api/demo/session`, ver sección 1.2). No describen necesariamente el despliegue actual.

| Petición | Resultado esperado | Resultado obtenido |
|---|---|---|
| `GET /` | 200 | 200 |
| `GET /api/demo/session` | 503 `{"error":"demo_disabled"}` | 503 `demo_disabled` |
| `POST /api/demo/login` (sin credenciales) | 503 `demo_disabled` | 503 `demo_disabled` |
| `POST /api/livekit-token` | 503 `demo_disabled` | 503 `demo_disabled` |
| `POST /api/demo/logout` | 204 y cookie de expiración | 204, `Cache-Control: no-store`, `Set-Cookie` con valor vacío y `Max-Age=0` |

Ninguna respuesta emitió una cookie de sesión nueva ni un JWT. Las respuestas de `/`, session, login y livekit-token no incluyeron `Set-Cookie`; la única cookie fue la de expiración de `logout` (valor vacío). Las peticiones se hicieron sin credenciales y no se imprimió el contenido de ninguna cookie. **REPORTADO POR EL EQUIPO.** Las respuestas son del 2026-10-23 (login con cuerpo `{}`).

## 12. Riesgos y restricciones

1. **Equivalencia exacta de ZIP:** la CLI re-empaqueta al desplegar. Que lo publicado equivalga a los ZIP validados es **INFERENCIA** (misma versión de empaquetador, mismas fuentes y mismo `node_modules`); la prueba efectiva fue la validación HTTP posterior.
2. **Orden de validación de configuración:** `loadDemoConfig` valida los tres secretos requeridos antes de comprobar `enabled`. Con `DEMO_ENABLED=false` y un secreto ausente o con formato inválido, las Functions responden 500 `service_unavailable` en vez de 503. No habilita la demo. Orden de validación en el código: **CONFIRMADO** (repositorio); efecto observado en prueba local: **REPORTADO POR EL EQUIPO**. Las variables de LiveKit no se leen mientras la demo esté deshabilitada.
3. **Dependencia del equipo local:** el procedimiento depende de Windows, rutas temporales y de la cuenta propietaria del proyecto Netlify, porque Netlify Free restringe colaboradores en repositorios privados (según lo reportado por el equipo durante el incidente). **REPORTADO POR EL EQUIPO.**
4. **Directorios temporales:** pueden quedar copias locales sin limpiar (`%TEMP%\adh`, `adx`, `adh-verify`). No contienen secretos, pero sí un `state.json` con el Project ID.
5. **Despliegue de producción desde CI/Linux:** no probado de forma directa. Los Deploy Previews de Netlify cargan las Functions (sección 4.1), pero que el entorno de producción se comporte igual es **PENDIENTE**.
6. **Despliegue histórico afectado accesible públicamente:** el deploy `6adb61ddbc7cd8942f42604b` permanece accesible mediante su URL permanente, y su respuesta HTTP 502 expone información técnica de diagnóstico: el nombre de la dependencia `jose`, el mensaje de error del runtime y rutas internas `/var/task`. **CONFIRMADO** según la verificación HTTP independiente reportada por David (2026-10-24, 14:51 UTC, `GET /api/demo/session`; sección 2). No hay evidencia de que se hayan expuesto secretos ni de una vulnerabilidad explotable; solo se documenta la divulgación de información de diagnóstico. **PROPUESTA:** evaluar la restricción o eliminación del acceso público a ese despliegue histórico, con autorización del líder del equipo (no se modificó ni eliminó el despliegue).

## 13. Evidencias del despliegue exitoso

Estado al **2026-10-23**; no describe necesariamente el despliegue actual de producción. Los metadatos de Netlify provienen de la API autenticada y no son reverificables sin credenciales.

- Deploy ID: `6adb6dfe9c5be068761fc330`; estado `ready`, contexto `production`, publicado el 2026-10-23 (14:24 UTC), título "DART-14-4.2 c87f93c hoisted" (metadatos del deploy obtenidos de la API de Netlify, sin variables). **REPORTADO POR EL EQUIPO.**
- Commit desplegado: `c87f93ce040606cc674201c6aef61803ea5bb914`, merge del Pull Request #13 en `main` (**CONFIRMADO** en Git). Los archivos de la copia temporal no diferían del commit salvo `.npmrc` (comparación de hashes). **REPORTADO POR EL EQUIPO.** El PR #13 es solo el origen del commit desplegado; no es la corrección del HTTP 502 (sección 1.1).
- Proyecto: `alloxentric-demo-fernando` (`a169c7a9-7910-4dd7-8b58-57e7323ed13d`). URL: `https://alloxentric-demo-fernando.netlify.app`.
- Resumen del deploy: 8 archivos nuevos, 2 reglas de headers, **4 functions deployed**, sin edge functions.
- Validación HTTP de la sección 11.
- Deploy previo afectado (502): `6adb61ddbc7cd8942f42604b`. Deploy corregido: `6adb6dfe9c5be068761fc330`.
- Validaciones locales previas al despliegue (copia temporal hoisted del commit `c87f93c`): tests 42/42 aprobados, lint aprobado, typecheck aprobado, build aprobado y `pnpm audit --prod` sin vulnerabilidades conocidas. **REPORTADO POR EL EQUIPO.** (Los 42 tests del commit coinciden con los declarados en el PR #13.)
- Prueba aislada de los bundles hoisted (valores sintéticos, red bloqueada): 4/4 Functions cargan; con la demo deshabilitada, session/login/livekit-token → 503 `demo_disabled` y logout → 204 con cookie de expiración. **REPORTADO POR EL EQUIPO.**

## 14. Recomendaciones preventivas

1. **PROPUESTA:** incorporar este procedimiento en la documentación del proyecto y, tras revisión del equipo, evaluar versionar `web-demo/.npmrc` con `node-linker=hoisted` (afectaría todas las instalaciones, incluida la CI de Netlify; probar antes).
2. **PROPUESTA:** añadir un script de humo post-despliegue que ejecute las cinco peticiones de la sección 11 sin credenciales.
3. **PROPUESTA:** añadir una verificación previa que inspeccione los ZIP en busca de symlinks con destinos absolutos y que importe cada Function desde un directorio aislado.
4. **PROPUESTA:** evaluar si `loadDemoConfig` debería comprobar `enabled` antes de validar secretos, para que una demo deshabilitada responda 503 de forma consistente. Requiere decisión del equipo y ticket propio; no es parte de este incidente.
5. **PROPUESTA:** definir un despliegue desde CI Linux cuando se resuelva la restricción de colaboradores. **PENDIENTE.**
6. **PROPUESTA:** limpiar los directorios temporales una vez archivado el incidente, con autorización del equipo.
7. **PROPUESTA:** evaluar la restricción o eliminación del acceso público al despliegue histórico afectado (ver sección 12, punto 6).
